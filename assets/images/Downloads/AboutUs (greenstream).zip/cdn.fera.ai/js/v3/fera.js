(() => {
    var Fo = Object.defineProperty,
        qo = Object.defineProperties;
    var Wo = Object.getOwnPropertyDescriptors;
    var ws = Object.getOwnPropertySymbols;
    var _a = Object.prototype.hasOwnProperty,
        ka = Object.prototype.propertyIsEnumerable;
    var Ca = (r, t, e) => t in r ? Fo(r, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: e
        }) : r[t] = e,
        n = (r, t) => {
            for (var e in t || (t = {})) _a.call(t, e) && Ca(r, e, t[e]);
            if (ws)
                for (var e of ws(t)) ka.call(t, e) && Ca(r, e, t[e]);
            return r
        },
        h = (r, t) => qo(r, Wo(t));
    var Sa = (r, t) => {
        var e = {};
        for (var i in r) _a.call(r, i) && t.indexOf(i) < 0 && (e[i] = r[i]);
        if (r != null && ws)
            for (var i of ws(r)) t.indexOf(i) < 0 && ka.call(r, i) && (e[i] = r[i]);
        return e
    };
    var m = (r, t, e) => new Promise((i, s) => {
        var a = d => {
                try {
                    l(e.next(d))
                } catch (u) {
                    s(u)
                }
            },
            o = d => {
                try {
                    l(e.throw(d))
                } catch (u) {
                    s(u)
                }
            },
            l = d => d.done ? i(d.value) : Promise.resolve(d.value).then(a, o);
        l((e = e.apply(r, t)).next())
    });

    function I(r, t, e = !1) {
        var i;
        return function() {
            var s = this,
                a = arguments;
            clearTimeout(i), i = setTimeout(function() {
                i = null, e || r.apply(s, a)
            }, t), e && !i && r.apply(s, a)
        }
    }
    var w = class {
        constructor(t = {}) {
            if (this.e = t || {}, !this.app) throw new Error("Fera app is required");
            this.Xt = !1, this.ko()
        }
        get app() {
            return this.e.app === "this" ? this : this.e.app || window && globalThis.fera
        }
        get store() {
            return this.e.store ? this.e.store : this.app.store
        }
        t(t, e = null) {
            return this.app.t(t, e)
        }
        formatNumber(t, e = {}) {
            return this.app.i18n.formatNumber(t, e)
        }
        B(t) {
            return `${this.app.config.cdnUrl.replace(/\/$/,"").replace(/\/js$/,"/js/v3")}/${t.replace(/^\//,"")}?v=${this.app.version}`
        }
        b() {
            this.So && this.Oe("log", arguments)
        }
        Mo() {
            this.Oe("info", arguments)
        }
        get xi() {
            return this.e.environment || this.app.environment
        }
        get So() {
            return this.app.config.debugMode
        }
        get Ci() {
            return this.app.config.devMode
        }
        get _i() {
            return this.xi === "test"
        }
        ft() {
            this.Oe("warn", arguments)
        }
        get Jt() {
            return ["development", "test", "staging"].includes(this.xi) || this.Ci || this._i
        }
        N() {
            if (this.Oe("error", arguments), this.Jt) {
                let t = arguments[0] instanceof Error ? arguments[0] : new Error(arguments[0]);
                throw globalThis.Kt = globalThis.Kt || [], globalThis.Kt.push({
                    line_number: t.lineno,
                    column_number: t.colno,
                    message: t.message
                }), t
            }
        }
        Oe(t, e) {
            globalThis.console && (typeof e[0] == "string" && (e[0] = `[Fera] ${e[0]}`), console[t].apply(this, e))
        }
        destroy() {
            this.it = [], this._t = []
        }
        on(t, e) {
            return typeof t != "string" && (e = t.callback, t = t.event), (t.indexOf(" ") === -1 ? [t] : t.split(" ")).forEach(s => {
                if (s === "ready" && this.Xt === !0) return e(this);
                this.it[s] = this.it[s] || [], this.it[s].push(e)
            }), this
        }
        once(t, e) {
            var i = t.indexOf(" ") === -1 ? [t] : t.split(" ");
            return i.forEach(s => {
                if (s === "ready" && this.Xt === !0) return e(this);
                this._t[s] = this._t[s] || [], this._t[s].push(e)
            }), this
        }
        clearOnceListeners(t) {
            this._t[t] = []
        }
        clearListeners(t) {
            this.it[t] = []
        }
        trigger(t, e = null) {
            return (t.indexOf(" ") === -1 ? [t] : t.split(" ")).forEach(s => {
                let a = this.it[s];
                a && a.length > 0 && a.forEach(l => l(e));
                let o = this._t[s];
                o && o.length > 0 && (o.forEach(l => l(e)), this.clearOnceListeners(s))
            }), this
        }
        debouncedTrigger(t, e = null) {
            return this.ze = this.ze || {}, this.ze[t] || (this.ze[t] = I(() => this.trigger(t, e), 100)), this.ze[t](), this
        }
        ko() {
            this.it = n({}, this.e.listeners || this.e.on || {}), this.ns(this.it), delete this.e.listeners, delete this.e.on, this._t = n({}, this.e.once), this.ns(this._t), delete this.e.once
        }
        ns(t) {
            Object.keys(t).forEach(e => {
                e.split(" ").forEach(i => {
                    typeof t[i] == "function" && (t[i] = [t[i]])
                })
            })
        }
        ls() {
            this.Xt = !0, this.trigger("ready", this)
        }
        static ki() {
            return globalThis.Si = globalThis.Si || 0, globalThis.Si += 1, globalThis.Si
        }
        ki() {
            return this.constructor.ki()
        }
        k() {
            return this.ds = this.ds || this.ki(), this.ds
        }
    };

    function ge(r, {
        timeout: t = 1e3,
        checkInterval: e = 100,
        timeoutError: i = null
    }) {
        return r() ? Promise.resolve(!0) : new Promise(s => {
            let a = 0,
                o = setInterval(() => {
                    if (r()) clearInterval(o), s(!0);
                    else if (a >= t) {
                        if (clearInterval(o), i) throw typeof i == "string" ? new Error(i) : i;
                        s(!1)
                    }
                    a += e
                }, e)
        })
    }
    var ht = class r extends URL {
        get params() {
            return this.st || (this.st = Object.fromEntries(new URLSearchParams(this.search).entries()))
        }
        toString() {
            return this.search = new URLSearchParams(this.params).toString(), super.toString()
        }
        get ext() {
            return this.pathname.split(".").pop()
        }
        clone() {
            return new r(this.toString())
        }
    };

    function H(r, t = !0) {
        return t === !0 ? [!0, 1, "1", "true", "t", "yes", "y", "on"].indexOf(r) !== -1 : [!1, 0, null, "0", "false", "f", "no", "n", "off", void 0].indexOf(r) === -1
    }
    var Vt = class extends Error {
        constructor({
            response: t,
            app: e
        }) {
            super(t.json.message || t.json.code), this.code = t.json.code, this.response = t, this.app = e
        }
    };
    var ve = class extends w {
        constructor(t) {
            super(t), this.response = this.e.response
        }
        handle(t, e) {
            return this.failed ? (e(new Error(this.json.message || this.json.code)), !0) : (t(), !1)
        }
        get clientOutdated() {
            return H(this.response.headers.get("Api-Client-Outdated"))
        }
        checkForErrors() {
            if (this.failed) throw new Vt({
                app: this.app,
                response: this
            })
        }
        get failed() {
            return this.status >= 400
        }
        get json() {
            return this.e.json
        }
        get errors() {
            return this.json.errors
        }
        get status() {
            return this.response.status
        }
        get headers() {
            return this.response.headers
        }
        static from(i) {
            return m(this, arguments, function*(t, e = {}) {
                let s;
                try {
                    s = t.status < 500 ? yield t.json(): {}
                } catch (a) {
                    a instanceof SyntaxError && t.status >= 400 && t.status < 500 && (s = {
                        message: t.statusText || {
                            400: "Please check your request and try again.",
                            401: "You are not authorized to access this resource.",
                            403: "This request is forbidden.",
                            404: "Request or resource not found. Please check your request and try again.",
                            405: "You're not allowed to perform this action.",
                            406: "Your input was not accepted. Please check it and try again.",
                            415: "The media you tried to upload is not allowed. Please try again with a different file.",
                            429: "You're making too many requests too quickly. Please slow down a bit and try again in a couple minutes."
                        }[t.status]
                    }, s.code = s.message.replace(/ /g, "_").toLowerCase())
                }
                return new this(h(n({}, e), {
                    json: s,
                    response: t
                }))
            })
        }
        get isSuccess() {
            return !this.failed
        }
        get isClientError() {
            return this.status >= 400 && this.status < 500
        }
        get isServerError() {
            return this.status >= 500
        }
    };
    var Dt = class {
        constructor(t, e, i) {
            this.stateValue = t, this.ruleValue = e, this.operator = i
        }
        isTrue() {
            return this[this.operator]()
        }
        equal() {
            return this.stateValue == this.ruleValue
        }
        not_equal() {
            return !this.equal()
        }
        equal_i() {
            return this.equal()
        }
        not_equal_i() {
            return !this.equal_i()
        }
        contains() {
            return this.stateValue == this.ruleValue
        }
        not_contains() {
            return !this.contains()
        }
        less() {
            return this.stateValue < this.ruleValue
        }
        less_or_equal() {
            return this.stateValue <= this.ruleValue
        }
        greater() {
            return this.stateValue > this.ruleValue
        }
        greater_or_equal() {
            return this.stateValue >= this.ruleValue
        }
        between() {
            return this.greater() || this.less()
        }
        not_between() {
            return !this.between()
        }
    };
    var we = class extends Dt {
        constructor(t, e, i) {
            super(String(t).trim(), String(e).trim(), i)
        }
        equal() {
            return this.stateValue == this.ruleValue
        }
        equal_i() {
            return this.stateValue.toLowerCase() == this.ruleValue.toLowerCase()
        }
        contains() {
            return this.stateValue.toLowerCase().indexOf(this.ruleValue.toLowerCase()) !== -1
        }
        less() {
            return parseFloat(this.stateValue) < parseFloat(this.ruleValue)
        }
        less_or_equal() {
            return parseFloat(this.stateValue) <= parseFloat(this.ruleValue)
        }
        greater() {
            return parseFloat(this.stateValue) > parseFloat(this.ruleValue)
        }
        greater_or_equal() {
            return parseFloat(this.stateValue) >= parseFloat(this.ruleValue)
        }
        between() {
            return this.ruleValue.indexOf(this.stateValue) !== -1
        }
        begins_with() {
            return this.stateValue && this.stateValue.indexOf(this.ruleValue || "") === 0
        }
    };
    var wi = class extends we {
        constructor(t, e, i) {
            super(t, e.value, i)
        }
    };
    var bi = class extends Dt {
        constructor(t, e, i) {
            super(t, e, i), typeof this.stateValue != "string" && (this.stateValue = String(this.stateValue).split(",")), this.stateValue = this.stateValue.sort()
        }
        equal() {
            let t = this.ruleValue;
            return typeof this.ruleValue != "object" && (t = String(this.ruleValue).split(",")), this.stateValue.join(",") == t.sort().join(",")
        }
        contains() {
            return this.stateValue.indexOf(this.ruleValue) !== -1
        }
        less() {
            return this.stateValue.length < this.ruleValue
        }
        less_or_equal() {
            return this.stateValue.length <= this.ruleValue
        }
        greater() {
            return this.stateValue.length > this.ruleValue
        }
        greater_or_equal() {
            return this.stateValue.length >= this.ruleValue
        }
        between() {
            return this.ruleValue.every(t => this.stateValue.indexOf(t) !== -1)
        }
    };
    var yi = class extends w {
        constructor(t) {
            super(t), this.rule = this.e.rule, this.atomic = !0, this.comparisonClass = this.Ro()
        }
        match(t) {
            return m(this, null, function*() {
                let e = yield t.fetchValue(this.rule.field, this.rule.value);
                return e == null ? !1 : new this.comparisonClass(e, this.rule.value, this.rule.operator).isTrue()
            })
        }
        Ro() {
            return this.rule.type === "string" ? this.rule.field.match(/_param$/) && typeof this.rule.value == "object" ? wi : we : this.rule.type === "array" ? bi : Dt
        }
    };
    var Nt = class extends w {
        constructor(t) {
            var e;
            super(t), this.conditions = this.e.conditions || {
                rules: []
            }, typeof this.conditions == "string" && (this.conditions = JSON.parse(this.conditions)), Array.isArray(this.conditions) && (this.conditions = {
                rules: this.conditions
            }), this.rules = (e = this.conditions.rules) == null ? void 0 : e.map(i => i.condition ? new this.constructor({
                app: this.app,
                conditions: i
            }) : new yi({
                app: this.app,
                rule: i
            })), this.separator = this.conditions.condition
        }
        get hasRule() {
            return this.rules && this.rules.length > 0
        }
        match(t) {
            return this.hasRule ? new Promise(e => Promise.all(this.rules.map(i => i.match(t))).then(i => {
                this.separator === "AND" ? e(i.every(s => s)) : e(i.some(s => s))
            })) : Promise.resolve(!0)
        }
    };
    var M = class extends w {
        constructor(t = {}, e = {}) {
            super(e), this.data = {}, this.hs = n({}, this.cs()), Object.keys(t || {}).forEach(i => {
                t[i] !== null && t[i] !== void 0 && (this.hs[i] = t[i])
            }), this.resourceName = this.e.resourceName || this.constructor.resourceName, this.resourceTitle = this.e.resourceTitle || this.resourceName.replace(/(^\w{1})|(\s{1}\w{1})/g, i => i.toUpperCase()), this.defaultParams = this.e.defaultParams || {}, this.loadDataFromServer(this.hs, {
                fresh: !0
            }), this.persisted || Object.keys(this.data).forEach(i => {
                this.changes[i] = {
                    to: this.data[i]
                }
            }), this.readOnlyAttributes = ["id", "type", "type_name"], this.Kh = new Date().getTime(), this.us = this.us || [], this.To(), this.ls()
        }
        get persisted() {
            return !!this.id
        }
        get Gt() {
            return {}
        }
        get T() {
            return null
        }
        get Bt() {
            return this.T ? (this.data[this.T] = this.data[this.T] || {}, this.data[this.T]) : {}
        }
        get fs() {
            return {}
        }
        cs() {
            return this.fs
        }
        static get aliasAttributes() {
            return {}
        }
        static get resourceName() {
            throw new Error(`BaseModel static get resourceName not overridden for type ${this.name}. Please override this method in your model class.`)
        }
        static get associations() {
            return {
                hasOne: [],
                hasMany: []
            }
        }
        static get cssClassName() {
            throw new Error("cssClassName must be implemented by subclass")
        }
        get cssClassName() {
            return this.constructor.cssClassName
        }
        To() {
            var t, e;
            (t = this.constructor.associations.hasOne) == null || t.forEach(i => {
                let s = i.key.replace(/[\-_](\w)/g, o => o.charAt(1).toUpperCase()),
                    a = this.e[i.key] || this.e[s] || this.get(i.key) || this.get(s);
                a instanceof this.constructor ? this[s] = a : typeof a == "object" && (this[s] = this.Y(i, a))
            }), (e = this.constructor.associations.hasMany) == null || e.forEach(i => {
                let s = i.key.replace(/[\-_](\w)/g, o => o.charAt(1).toUpperCase()),
                    a = this.e[i.key] || this.e[s] || this.get(i.key) || this.get(s);
                a instanceof Array && (this[s] = a.map(o => o instanceof this.constructor ? o : typeof a == "object" ? this.Y(i, o) : null).filter(o => o !== null))
            }), this.ps()
        }
        ps() {
            this.constructor.allAssociations.forEach(t => {
                t.through && this[t.through] && (this[t.key] || this[t.through][t.key] && (this[t.key] = this[t.through][t.key]))
            })
        }
        get title() {
            return this.getResourceTitle() || this.getResourceName()
        }
        getResourceTitle() {
            return this.resourceTitle
        }
        getResourceName() {
            return this.resourceName
        }
        set(t, e, i) {
            if (typeof t == "object" && typeof e == "undefined") return Object.keys(t).forEach(a => {
                this.set(a, t[a], i)
            }), this;
            let s = this.get(t);
            return JSON.stringify(s) != JSON.stringify(e) && this.X(t, e), this
        }
        v(t) {
            return this.constructor.aliasAttributes[t] ? this.v(this.constructor.aliasAttributes[t]) : t === "id" ? this.id : this.T && Object.keys(this.Gt).includes(t) ? typeof this.Bt[t] != "undefined" ? this.Bt[t] : this.Gt[t] : this.data[t]
        }
        X(t, e) {
            if (this.constructor.aliasAttributes[t]) return this.X(this.constructor.aliasAttributes[t], e);
            if (t === "id") {
                this.id = e;
                return
            }
            if (this.T === t && typeof e == "object") return Object.keys(e).forEach(i => this.X(i, e[i]));
            this.T && Object.keys(this.Gt).includes(t) ? this.Bt[t] = e : this.data[t] = e
        }
        isSet(t) {
            let e = this.v(t);
            return typeof e != "undefined" && e !== null
        }
        get(t, e) {
            if (t === "id") return this.id;
            let i = this.v(t);
            return typeof e != "undefined" && (typeof i == "undefined" || i === null || i === "") ? e : i
        }
        has(t) {
            let e = this.v(t);
            return typeof e == "boolean" ? this.is(t) : !(typeof e == "undefined" || e === null || e === "")
        }
        can(t) {
            return this.is(t)
        }
        is(t) {
            let e = this.v(t);
            if (typeof e == "undefined") {
                if (typeof this.v(`is_${t}`) != "undefined") return this.is(`is_${t}`);
                if (typeof this.v(`has_${t}`) != "undefined") return this.is(`has_${t}`);
                if (typeof this.v(`can_${t}`) != "undefined") return this.is(`can_${t}`);
                if (typeof this.v(`dont_${t}`) != "undefined") return !this.is(`dont_${t}`)
            }
            return !!e
        }
        getData() {
            return h(n(n(n({}, this.Gt), this.data), this.Bt), {
                id: this.id
            })
        }
        clone() {
            return new this.constructor(h(n({}, JSON.parse(JSON.stringify(this.data))), {
                id: this.id
            }), n({}, this.e))
        }
        $o(t) {
            let e = {},
                i = n({}, this.data);
            return Object.keys(t).concat(Object.keys(i)).filter((a, o, l) => l.indexOf(a) === o).forEach(a => {
                let o = i[a],
                    l = t[a];
                this.us.includes(a) && (o = JSON.stringify(o), l = JSON.stringify(l)), o !== l && (e[a] = {
                    from: o,
                    to: l,
                    attribute: a
                })
            }), e
        }
        Po(t, e, i = {}) {
            let s = t.key.replace(/[\-_](\w)/g, a => a.charAt(1).toUpperCase());
            e === null ? this[s] = null : this[s] ? this[s].loadDataFromServer(e, i) : this[s] = this.Y(t, e)
        }
        Y(t, e) {
            if (Array.isArray(e)) return e.map(a => this.Y(t, a));
            let i = {
                app: this.app
            };
            t.inverseOf && (i[t.inverseOf] = this);
            let s;
            return e instanceof t.klass ? (s = e, t.inverseOf && (s[t.inverseOf] = s[t.inverseOf] || this)) : (t.inverseOf && (i[t.inverseOf] = this), s = new t.klass(e, i)), s
        }
        static get allAssociations() {
            return [...this.associations.hasOne || [], ...this.associations.hasMany || []]
        }
        loadDataFromServer(t, e = {}) {
            let i = e.fresh || Object.keys(this.data).length < 1,
                s = i ? {} : this.$o(t),
                a = n({}, t || {});
            return a.id && !this.id && (this.id = a.id, delete a.id), Object.keys(a).length < 1 && i ? {} : (this.T && a[this.T] && i && (this.data[this.T] = a[this.T], delete a[this.T]), Object.keys(a).forEach(o => this.X(o, a[o])), this.constructor.allAssociations.forEach(o => {
                typeof a[o.key] != "undefined" && this.Po(o, a[o.key], e)
            }), this.ps(), this.changes = this.changes || {}, i ? this.changes = {} : (Object.keys(s).forEach(o => {
                this.changes[o] ? this.changes[o].to = s[o].to : this.changes[o] = s[o]
            }), this.Io(s)), this.trigger("load load:after"), s)
        }
        setData(t) {
            Object.keys(t).forEach(e => this.set(e, t[e]))
        }
        Io(t) {
            if (!t) return;
            let e = Object.keys(t);
            e.length < 1 || (e.forEach(i => {
                i != "id" && this.trigger(`${i}.change ${i}.update`, t[i])
            }), this.debouncedTrigger("change update", t))
        }
    };
    var Ma = {
        header: "Product Reviews",
        header_visible: !0,
        layout: "list",
        header_when_showing_other_reviews: "Reviews",
        show_products_for_other_reviews: !0,
        min_cols: 1,
        write_review_visible: !0,
        write_review_style: "primary",
        page_size: null,
        mobile_page_size: null,
        pagination_mode: "show_more",
        show_more_style: "secondary",
        sort_by: "quality:desc",
        when_no_reviews: "show_all_reviews",
        sortable: !0,
        border_visible: !1,
        bg_visible: !1,
        summaries_visible: !0,
        store_replies_visible: !0,
        summary_filters_visible: !0,
        open_summary_filters_by_default: !1,
        summary_filter_collapsible: !0,
        customer_avatars_visible: !0,
        customer_media_visible: !0,
        customer_locations_visible: !0,
        dates_visible: !0,
        products_visible: !1,
        ratings_visible: !0,
        default_customer_image: "https://cdn.fera.ai/img/shoppers/placeholder2.png"
    };

    function bs(r) {
        return r.replace(/([a-z])([A-Z])/g, "$1_$2").replace(/([a-zA-Z])(\d)/g, "$1_$2").replace(/([A-Z])(\d)/g, "$1_$2").replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()
    }

    function ei(r) {
        return r.replace(/[\s_.]/g, "-").replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase().replace(/-{2,}/g, "-")
    }

    function Os(r, t) {
        let e = {};
        return t.forEach(i => {
            i in r && (e[i] = r[i])
        }), e
    }
    var Q = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "widget"
            }, e))
        }
        static get aliasAttributes() {
            return h(n({}, super.aliasAttributes), {
                heading: "header",
                layout_code: "layout",
                theme_code: "theme",
                options: "type_settings"
            })
        }
        static get defaultTypeSettings() {
            return {}
        }
        get Gt() {
            return this.constructor.defaultTypeSettings
        }
        hasValidOptsToRender(t) {
            return this.forProduct ? t.productId || this.productId : !0
        }
        get Qt() {
            return ["header"]
        }
        cs() {
            let t = n({}, this.fs);
            return Object.keys(t).forEach(e => {
                this.Qt.includes(e) && (t[e] = this.t(t[e]))
            }), t
        }
        get cssClassName() {
            return `${this.constructor.cssClassName}-${this.k()}`
        }
        get collectionParams() {
            return Os(this.getData(), ["page_size", "limit", "sort_by"])
        }
        get usePagination() {
            return this.get("pagination_mode", "pagination") === "pagination"
        }
        get options() {
            return this.Bt
        }
        get allowedElementAttributes() {
            return this.at.concat(["layout", "theme", "header", "conditions"]).concat(Object.keys(this.Bt))
        }
        loadDataFromElement(t) {
            Array.from(t.attributes).forEach(e => this.setFromElement(e.name, e.value))
        }
        setFromElement(t, e) {
            if (t.match(/^(data-)?(fera-)?(widget|api-key|type|container|style|rating|class|product([_-]?id|Id)?)$/)) return;
            if (t = bs(t).replace(/^data_/, "").replace(/^fera_/, ""), ["options", "settings", "data-options", "data-settings"].includes(t) && typeof e == "string" && e[0] === "{") {
                this.loadTypeDataFromElement(e);
                return
            }
            this.allowedElementAttributes.includes(t) && this.set(t, e)
        }
        loadTypeDataFromElement(t) {
            let e = JSON.parse(t);
            Object.keys(e).forEach(i => this.set(i, e[i]))
        }
        get at() {
            return []
        }
        X(t, e) {
            return this.at.includes(t) ? this.je(t, e) : super.X(t, e)
        }
        je(t, e) {
            this.designVars[`--${ei(t)}`] = e
        }
        v(t) {
            return this.at.includes(t) ? this.designVars[bs(t)] : super.v(t)
        }
        get T() {
            return "type_settings"
        }
        get targetSection() {
            return this.get("target_section")
        }
        get onlyShowInHomePage() {
            return this.targetSection && !!this.targetSection.match(/^home(_page)?$/i)
        }
        get isVisible() {
            return this.installationMethod ? this.onlyShowInHomePage && !this.app.request.isRoot && this.needsInstall ? !1 : this.app.config.designMode ? !0 : this.needsInstall && !this.is("installed") ? !1 : this.app.request.getFeraParam("widget") ? this.app.request.getFeraParam("widget") == this.id : !this.isDeactivated : !0
        }
        get isDeactivated() {
            return this.canBeDeactivated && !this.is("activated")
        }
        get needsInstall() {
            return ["auto", "selector"].includes(this.installationMethod)
        }
        get canBeDeactivated() {
            return this.is("installed") && ["auto", "selector", "tag"].includes(this.installationMethod)
        }
        get conditions() {
            return new Nt({
                app: this.app,
                conditions: this.get("conditions")
            })
        }
        get designVars() {
            return this.v("design_vars") || this.X("design_vars", {}), this.v("design_vars")
        }
        get autoIntegrationPossibilities() {
            return []
        }
        get installation() {
            return h(n({}, this.installationSettings), {
                method: this.installationMethod
            })
        }
        get installationSettings() {
            return this.get("installation_settings", this.get("integration_settings", {}))
        }
        get installationMethod() {
            return this.get("installation_method", this.get("integration_method", this.canAutoIntegrate ? "auto" : null))
        }
        get canAutoIntegrate() {
            return !0
        }
        get autoIntegrated() {
            return this.installation.method === "auto"
        }
        get selectorIntegrated() {
            return this.installation.method === "selector"
        }
        get tagIntegrated() {
            return this.installation.method === "tag"
        }
        get managedInFera() {
            return this.autoIntegrated || this.selectorIntegrated || this.tagIntegrated
        }
        get type() {
            return this.get("type")
        }
    };
    var Ct = class extends Q {
        get at() {
            return super.at.concat(["star_color", "star_bg_color"])
        }
        get collectionParams() {
            return h(n({}, super.collectionParams), {
                page_size: this.pageSize,
                include_aggregate_rating: !0
            })
        }
        get Qt() {
            return ["header"]
        }
        get minCols() {
            return parseInt(this.get("min_cols", 2)) == 2 ? 2 : 1
        }
        v(t) {
            let e = super.v(t);
            return this.Qt.includes(t) ? this.t(e) : e
        }
        get hideWhenNoReviews() {
            return this.get("when_no_reviews") === "hide"
        }
        get paginationMode() {
            return this.get("pagination_mode", this.Lo)
        }
        get layout() {
            return this.get("layout", this.ms)
        }
        get pageSize() {
            return this.get("page_size", this.te)
        }
        get desktopPageSize() {
            return this.get("page_size", this.Ao)
        }
        get mobilePageSize() {
            return this.get("mobile_page_size", this.ee)
        }
        getData() {
            let t = super.getData();
            return t.layout = this.layout, t.pagination_mode = this.paginationMode, t.page_size = this.pageSize, t
        }
        get te() {
            return this.layout === "masonry" ? Math.max(Math.round(globalThis.innerWidth / 300 * Math.max(Math.round(globalThis.innerHeight / 300), 2)), 6) : Math.max(Math.round(globalThis.outerHeight / 300) * 2, 6)
        }
        get Lo() {
            return this.layout === "masonry" ? "show_more" : "pagination"
        }
        get ms() {
            return "masonry"
        }
        get Ao() {
            return this.layout === "masonry" ? 12 : 6
        }
        get ee() {
            return 6
        }
    };
    var tt = class extends Ct {
        get type() {
            return "product_reviews"
        }
        get forProduct() {
            return !0
        }
        static get defaultTypeSettings() {
            return Ma
        }
        get Qt() {
            return [...super.Qt, "header_when_showing_other_reviews"]
        }
        static get cssClassName() {
            return "fera-productReviews-widget"
        }
        get ms() {
            return "list"
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["after product section"], ...this.app.config.autoIntegrationSelectors["product content"], ...this.app.config.autoIntegrationSelectors["bottom of product content"], ...this.app.config.autoIntegrationSelectors.page]
        }
        get productId() {
            return this.autoIntegrated || this.selectorIntegrated ? this.app.currentProductId : null
        }
    };
    var Ra = {
        header: "Reviews",
        header_visible: !0,
        layout: "masonry",
        min_cols: 1,
        review_ids: [],
        write_review_visible: !0,
        write_review_style: "primary",
        page_size: null,
        mobile_page_size: null,
        sort_by: "quality:desc",
        pagination_mode: "show_more",
        show_more_style: "secondary",
        sortable: !1,
        types_to_show: "both",
        border_visible: !1,
        bg_visible: !1,
        summaries_visible: !0,
        store_replies_visible: !0,
        summary_filters_visible: !0,
        open_summary_filters_by_default: !1,
        summary_filter_collapsible: !0,
        customer_avatars_visible: !0,
        customer_media_visible: !0,
        customer_locations_visible: !0,
        products_visible: !0,
        dates_visible: !0,
        ratings_visible: !0,
        when_no_reviews: "show",
        default_customer_image: "https://cdn.fera.ai/img/shoppers/placeholder2.png"
    };
    var et = class extends Ct {
        get type() {
            return "all_reviews"
        }
        static get defaultTypeSettings() {
            return Ra
        }
        get forProduct() {
            return !1
        }
        get collectionParams() {
            let t = n({}, super.collectionParams);
            return this.get("types_to_show", "both") !== "both" && (t.subject = this.get("types_to_show")), t
        }
        static get cssClassName() {
            return "fera-allReviews-widget"
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["before footer"], ...this.app.config.autoIntegrationSelectors.page]
        }
    };
    var ys = {
        when_no_reviews: "hide",
        count_num_visible: !0,
        avg_num_visible: !1
    };
    var st = class extends Q {
        static get defaultTypeSettings() {
            return ys
        }
        static parseTransientRating(t) {
            if (!t || !t.dataset) return null;
            let e = t.dataset.rating || t.dataset.feraRating || t.dataset.ratingAverage || t.dataset.averageRating;
            t.attributes.rating && (e = t.attributes.rating.value);
            let i = t.dataset.count || t.dataset.feraCount || t.dataset.ratingCount || t.dataset.reviewCount || t.dataset.reviewsCount;
            return t.attributes.count && (i = t.attributes.count.value), e && e.indexOf("{") === 0 && e.indexOf("{{") !== 0 ? JSON.parse(e) : e && i ? {
                average: e,
                count: i
            } : null
        }
        hasValidOptsToRender(t) {
            return this.constructor.parseTransientRating(t.el || t.container) || super.hasValidOptsToRender(t)
        }
        static get aliasAttributes() {
            return h(n({}, super.aliasAttributes), {
                show_avg_rating: "avg_num_visible",
                count_visible: "count_num_visible",
                show_count: "count_num_visible"
            })
        }
        X(t, e) {
            t === "hide_when_no_reviews" ? super.X("when_no_reviews", e === !0 || e === "true" ? "hide" : "show") : super.X(t, e)
        }
        je(t, e) {
            return t === "size" && typeof e == "number" ? this.je(t, `${e}px`) : super.je(t, e)
        }
        get showWhenNoReviews() {
            return this.get("when_no_reviews") === "show"
        }
        get allowedElementAttributes() {
            return super.allowedElementAttributes.concat(["rating", "count", "rating_average", "rating_count"])
        }
        v(t) {
            return t === "hide_when_no_reviews" ? this.v("when_no_reviews") === "hide" : super.v(t)
        }
        get at() {
            return super.at.concat(["star_color", "star_bg_color", "size", "star_spacing", "alignment", "vertical_margin"])
        }
        get forProduct() {
            return !0
        }
        static get cssClassName() {
            return "fera-productRating-widget"
        }
    };
    var Ta = {
        header: "Customer Photos & Videos",
        header_visible: !0,
        min_rating: 4,
        min_cols: 2,
        sort_by: "created_at:desc",
        page_size: 8,
        mobile_page_size: 4,
        border_visible: !1,
        bg_visible: !1,
        pagination_mode: "show_more"
    };
    var Lt = class extends Q {
        get type() {
            return "media_gallery"
        }
        static get defaultTypeSettings() {
            return Ta
        }
        get forProduct() {
            return !1
        }
        static get cssClassName() {
            return "fera-mediaGallery-widget"
        }
        get collectionParams() {
            return h(n({}, super.collectionParams), {
                "review.min_rating": this.get("min_rating", 4)
            })
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["before footer"], ...this.app.config.autoIntegrationSelectors.page]
        }
    };
    var $a = {
        header: "Customer Photos & Videos",
        header_visible: !0,
        min_rating: 4,
        min_cols: 2,
        sort_by: "created_at:desc",
        page_size: 8,
        mobile_page_size: 4,
        border_visible: !1,
        bg_visible: !1,
        pagination_mode: "show_more",
        when_no_media: "hide"
    };
    var At = class extends Q {
        static get defaultTypeSettings() {
            return $a
        }
        static get cssClassName() {
            return "fera-productMediaGallery-widget"
        }
        get type() {
            return "product_media_gallery"
        }
        get forProduct() {
            return !0
        }
        get collectionParams() {
            return h(n({}, super.collectionParams), {
                "review.min_rating": this.get("min_rating", 4)
            })
        }
        get productId() {
            return this.autoIntegrated || this.selectorIntegrated ? this.app.currentProductId : null
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["after product section"], ...this.app.config.autoIntegrationSelectors["product content"], ...this.app.config.autoIntegrationSelectors["bottom of product content"], ...this.app.config.autoIntegrationSelectors.page]
        }
        get hideWhenNoMedia() {
            return this.get("when_no_media") == "hide"
        }
    };
    var Pa = {
        header: "Testimonials",
        header_visible: !0,
        types_to_show: "store",
        min_rating: 4,
        autoplay_enabled: !0,
        autoplay_speed: 5e3,
        only_with_content: !0,
        customer_media_visible: !1,
        ratings_visible: !0,
        summaries_visible: !0,
        dates_visible: !0,
        customer_avatars_visible: !1,
        customer_locations_visible: !0,
        store_replies_visible: !1,
        products_visible: !0,
        border_visible: !1,
        bg_visible: !1,
        page_size: 12,
        sort_by: "created_at:desc"
    };
    var Et = class extends Ct {
        get type() {
            return "testimonial_carousel"
        }
        static get defaultTypeSettings() {
            return Pa
        }
        get forProduct() {
            return !1
        }
        static get cssClassName() {
            return "fera-testimonialCarousel-widget"
        }
        get collectionParams() {
            let t = h(n({}, super.collectionParams), {
                ratings: this.Eo
            });
            return t.sort_by = this.is("customer_media_visible") ? "quality:desc" : "created_at:desc", t
        }
        get Eo() {
            let t = Math.max(this.get("min_rating", 5), 1),
                e = [];
            for (let i = 1; i <= 5; i++) i >= t && e.push(i);
            return e
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["before footer"], ...this.app.config.autoIntegrationSelectors.page]
        }
    };
    var xi = class extends st {
        get type() {
            return "product_detail_rating"
        }
        static get defaultTypeSettings() {
            return ys
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["after product detail price"], ...this.app.config.autoIntegrationSelectors["after product detail title"], ...this.app.config.autoIntegrationSelectors["add to cart button"]]
        }
        static get cssClassName() {
            return "fera-productDetailRating-widget"
        }
        get productId() {
            return this.autoIntegrated || this.selectorIntegrated ? this.app.currentProductId : null
        }
    };
    var Ia = {
        when_no_reviews: "hide",
        count_num_visible: !0,
        avg_num_visible: !1
    };
    var Ci = class extends st {
        get type() {
            return "product_collection_rating"
        }
        static get defaultTypeSettings() {
            return Ia
        }
        static get cssClassName() {
            return "fera-productCollectionRating-widget"
        }
        get canAutoIntegrate() {
            return !1
        }
    };
    var La = {
        stars_visible: !0,
        bg_visible: !1
    };
    var Ft = class extends Q {
        get type() {
            return "overall_rating_banner"
        }
        static get defaultTypeSettings() {
            return La
        }
        static get cssClassName() {
            return "fera-overallRatingBanner-widget"
        }
        get at() {
            return super.at.concat(["star_color", "text_color"])
        }
        get allowedElementAttributes() {
            return super.allowedElementAttributes.concat(["star_color", "text_color"])
        }
        get autoIntegrationPossibilities() {
            return [...this.app.config.autoIntegrationSelectors["before footer"], ...this.app.config.autoIntegrationSelectors.page]
        }
    };
    var be = class extends w {
        static initModel(t, e) {
            let i = t.product || t.productId || t.product_id,
                s = t.type.match(/^(rating|product_rating|product_reviews_summary)$/);
            return t.type.match(/^product_reviews$/) || t.type.match(/^reviews$/) && i ? new tt(t, e) : t.type.match(/^(reviews|all_reviews)$/) ? new et(t, e) : t.type.match(/^(product_(view|detail)_rating)$/) || s && t.editor ? new xi(t, e) : t.type.match(/^(product_(category|collection|list)_rating)$/) ? new Ci(t, e) : s ? new st(t, e) : t.type.match(/^product_media(_gallery)?$/) || t.type.match(/^media(_gallery)?$/) && i ? new At(t, e) : t.type.match(/^(media(_gallery)?|((store|product)_)?(customer_)?media)$/) ? new Lt(t, e) : t.type.match(/^(testimonial_|store_reviews?_)?carousel$/) ? new Et(t, e) : t.type.match(/^(overall_rating(_banner)?|store_reviews_summary)$/) ? new Ft(t, e) : (console.warn(`Unknown widget model class for type '${t.type}'.`), new Q(t, e))
        }
    };

    function ae(r, t, {
        prependArray: e = !1
    } = {}) {
        let i = n({}, r);
        return Object.keys(t).forEach(s => {
            s in i ? Array.isArray(i[s]) ? i[s] = e ? [...t[s], ...i[s]] : [...i[s], ...t[s]] : typeof i[s] == "object" ? i[s] = ae(i[s], t[s], {
                prependArray: e
            }) : i[s] = t[s] : i[s] = t[s]
        }), i
    }
    var Bt = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "store"
            }, e)), this.e.widgets && (this.data.widgets = this.e.widgets)
        }
        static get cssClassName() {
            return "fera"
        }
        get locale() {
            return this.get("supported_language", "en")
        }
        get translations() {
            return ae(this.sourceTranslations, this.customTranslations)
        }
        get sourceTranslations() {
            return this.get("frontend_translations", {})
        }
        get customTranslations() {
            return this.get("translated_strings", {})
        }
        get widgets() {
            return this.F || (this.F = this.get("widgets", []).map(t => be.initModel(t, {
                app: this.app,
                store: this
            })))
        }
        static get resourceName() {
            return "store"
        }
        get theme() {
            return this.get("theme", "neutral")
        }
        get rating() {
            return this.get("rating", {})
        }
        get averageRating() {
            return this.rating.average
        }
        get hasReviewProductExclusions() {
            return this.reviewProductExclusions.hasRule
        }
        get reviewProductExclusions() {
            return this.Bo || (this.Bo = new Nt({
                app: this.app,
                conditions: this.get("review_product_exclusions")
            }))
        }
        get counts() {
            return this.get("counts", this.get("cached_counts", {}))
        }
        getCount(t, e = 0) {
            return this.counts[t] || e
        }
    };
    var ye = class extends M {
        constructor(t, e = {}) {
            super(t, h(n({}, e), {
                resourceName: "channel"
            }))
        }
        get url() {
            return this.get("url")
        }
        get code() {
            return this.get("code")
        }
    };
    var xe = class extends w {
        constructor(t) {
            super(t), this.e.models && (this.models = this.e.models), this.e.meta && (this.meta = this.e.meta), this.Ve = this.e.params || {}, this.pt = {}, this.gs()
        }
        Mi() {
            return this.ie(this.e.models, {
                offset: 0,
                limit: this.e.models.length,
                total_count: this.e.models.length,
                page: 1
            }), this.models
        }
        forEach(t) {
            return this.models.forEach(t)
        }
        every(t) {
            return this.models.every(t)
        }
        get length() {
            return this.models.length
        }
        sort(t) {
            return m(this, null, function*() {
                this.vs !== t && (this.vs = t, this.trigger("sort:before", {
                    sortBy: t
                }), yield this.reload(), this.trigger("sort:after", {
                    sortBy: t
                }))
            })
        }
        filter(t = null) {
            return m(this, null, function*() {
                t !== null && (this.pt = n(n({}, this.pt), t)), this.trigger("filter:before", this.pt), yield this.reload(), this.trigger("filter:after", this.pt)
            })
        }
        removeFilters(t) {
            return Array.isArray(t) || (t = [t]), t.forEach(e => delete this.pt[e]), this.filter()
        }
        clearFilters() {
            return this.pt = {}, this.filter()
        }
        load() {
            return m(this, arguments, function*(t = {}) {
                throw new Error("load() method must be implemented in the child class")
            })
        }
        reload() {
            return m(this, null, function*() {
                this.gs(), this.trigger("reload:before"), yield this.load(), this.trigger("reload reload:after", this.models)
            })
        }
        gs() {
            this.models = [], this.meta = {}, this.Ri = null, this.loaded = !1
        }
        loadMore() {
            return this.load().then(t => {
                this.loaded = !0, t.length && t.length > 0 && this.trigger("load:more load", t)
            })
        }
        loadPage(t) {
            return this.trigger("load.page:before"), this.load({
                page: t
            }).then(e => {
                this.loaded = !0, e.length && e.length > 0 && this.trigger("load:page", e)
            })
        }
        loadNextPage() {
            return this.loadPage(this.nextPage)
        }
        loadPrevPage() {
            return this.loadPage(this.currentPage - 1)
        }
        Ti() {
            this.ws = !0, this.trigger("load:before")
        }
        get items() {
            return this.models
        }
        get isLoading() {
            return this.ws
        }
        ie(t, e) {
            this.e.usePagination ? this.models = t : this.models = this.models.concat(t), this.meta = e, this.Ri === null && (this.Ri = e.offset), this.ws = !1, this.trigger("load:after load", t)
        }
        get hasMore() {
            return this.meta ? this.models.length < this.meta.total_count : !0
        }
        get sortBy() {
            return this.vs || this.Ve.sort_by
        }
        get range() {
            let t = {
                total: this.meta.total_count || 0,
                to: 10,
                from: 1
            };
            return this.e.usePagination ? (t.from = this.pageSize * (this.currentPage - 1) + 1, t.to = t.from + this.models.length - 1) : (t.from = this.Ri || 1, t.to = t.from + this.models.length - 1), t
        }
        get nextParams() {
            let t = n(n({}, this.Ve), this.pt);
            return this.sortBy && (t.sort_by = this.sortBy), this.e.usePagination ? (t.page = this.nextPage, t.page_size = this.pageSize) : (t.offset = this.nextOffset, t.limit = this.pageSize), t
        }
        get pageSize() {
            return parseInt(this.Ve.page_size || this.Ve.limit || 12)
        }
        get currentOffset() {
            return parseInt(this.meta && this.meta.offset ? this.meta.offset : 0)
        }
        get currentPage() {
            return parseInt(this.meta && this.meta.page ? this.meta.page : 0)
        }
        get totalCount() {
            return parseInt(this.meta && this.meta.total_count ? this.meta.total_count : 0)
        }
        get nextPage() {
            return this.currentPage + 1
        }
        get pageCount() {
            return this.meta ? this.meta.page_count : 0
        }
        get nextOffset() {
            return this.models.length === 0 ? 0 : this.currentOffset + this.pageSize
        }
    };
    var _t = class extends xe {
        load() {
            return m(this, arguments, function*(t = {}) {
                if (this.e.models) return this.Mi();
                this.Ti();
                let {
                    reviews: e,
                    rating: i,
                    meta: s
                } = yield this.app.api.listReviews(n(n({}, this.nextParams), t));
                return this.rating = i, this.ie(e, s), e
            })
        }
        toggleRatingFilter(t) {
            return t === this.activeRatingFilter ? this.removeFilters("rating") : this.filter({
                rating: t
            })
        }
        get activeRatingFilter() {
            return this.pt.rating
        }
    };
    var oe = class extends M {
        constructor(t, e = {}) {
            super(t, h(n({}, e), {
                resourceName: "aggregate_rating"
            }))
        }
        get average() {
            return parseFloat(this.get("average", 0) || 0)
        }
        get formattedAverage() {
            return parseFloat(this.average).toFixed(1)
        }
        get count() {
            return this.get("count", 0)
        }
    };
    var ct = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "customer"
            }, e))
        }
        static get associations() {
            return {
                hasOne: [],
                hasMany: [{
                    key: "reviews",
                    klass: O,
                    inverseOf: "customer"
                }]
            }
        }
        get smallAvatarUrl() {
            return this.get("avatar_url", "").replace("width=400,height=400", "width=200,height=200").replace("class=thumb", "class=sthumb")
        }
        get isFromSupplier() {
            return this.channel && this.channel.get("code") === "supplier"
        }
        get channelCode() {
            return this.channel ? this.channel.get("code") : null
        }
        get fromStoreChannel() {
            return this.channel && this.channel.get("type") == "store"
        }
        collectReviews(t = {}) {
            let e = h(n({}, t), {
                app: this.app
            });
            return e.params = h(n({}, e.params || {}), {
                customer_id: this.id || this.get("external_id") || ""
            }), this.reviews && !this.id && (e.models = this.reviews), new _t(e)
        }
        get rating() {
            return this.O || (this.O = new oe(this.get("rating", {
                count: 0,
                average: 0
            }), {
                app: this.app
            }))
        }
        loadDataFromServer(t, e = {}) {
            super.loadDataFromServer(t, e), this.channel = t.channel ? new ye(t.channel, {
                app: this.app
            }) : null
        }
    };
    var at = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "media"
            }, e))
        }
        static get associations() {
            return {
                hasOne: [{
                    key: "customer",
                    klass: ct,
                    through: "review"
                }, {
                    key: "product",
                    klass: R,
                    through: "review"
                }, {
                    key: "review",
                    klass: O
                }]
            }
        }
        get isVideo() {
            return !1
        }
        get isPhoto() {
            return !1
        }
        Y(t, e) {
            return t.klass === ct && e && (e.reviews = [this]), super.Y(t, e)
        }
        get isUploaded() {
            return !0
        }
        loadAssociatedReviewFromServer() {
            let t = this.get("review_id");
            if (t) {
                let e = this.constructor.allAssociations.find(i => i.key === "review");
                return this.app.api.retrieveReview(t).then(i => {
                    let s = e.key.replace(/[\-_](\w)/g, a => a.charAt(1).toUpperCase());
                    return this[s] = this.Y(e, i), this[s]
                }).catch(i => this.Oo(i))
            } else return null
        }
        Oo(t) {
            if (t instanceof Vt && (t.code === "not_found" || t.response && t.response.status === 404)) return this.ft(`Unable to load associated review(#${this.get("review_id")}) for media(#${this.id}). This may be due to the review being deleted.`), null;
            throw t
        }
        get type() {
            return this.get("type", "photo")
        }
        get url() {
            return this.get("url", this.get("thumbnail_url", this.constructor.placeholderUrl))
        }
        get thumbnailUrl() {
            return this.get("thumbnail_url", this.constructor.placeholderUrl)
        }
        get smallThumbnailUrl() {
            return this.get("thumbnail_url", "").replace("width=400,height=400", "width=200,height=200").replace("class=thumb", "class=sthumb")
        }
        static get placeholderUrl() {
            return "https://uploads.fera.ai/placeholders/photo.png"
        }
        static get SOCIAL_URL_REGEXES() {
            return {
                youtube: /^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu\.be))(\/(?:[\w-]+\?v=|embed\/|v\/)?)([\w-]+)(\S+)?$/,
                facebook: /^(?:(?:https?:)?\/\/)?(?:(www|web|m)\.)?(facebook|fb)\.com\/[a-zA-Z0-9.]+\/videos\/(?:[a-zA-Z0-9.]+\/)?([0-9]+)/,
                vimeo: /(http|https)?:\/\/(www\.|player\.)?vimeo\.com\/(?:(channels|video)\/(?:\w+\/)?|groups\/([^/]*)\/videos\/|)(\d+)(?:|\/\?)/,
                instagram: /(https?:\/\/(?:www\.)?instagram\.com\/(reel|p)\/([^/?#&]+)).*/
            }
        }
    };
    var R = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "product"
            }, e))
        }
        static get aliasAttributes() {
            return h(n({}, super.aliasAttributes), {
                product_id: "id"
            })
        }
        static get associations() {
            return {
                hasMany: [{
                    key: "reviews",
                    klass: O,
                    inverseOf: "product"
                }, {
                    key: "media",
                    klass: at,
                    inverseOf: "product"
                }]
            }
        }
        static get resourceName() {
            return "product"
        }
        get isLinkable() {
            return this.is("visible") && this.get("url")
        }
        get name() {
            return this.get("name")
        }
        get rating() {
            return this.get("rating", {
                count: 0,
                average: 0
            })
        }
        get averageRating() {
            return this.rating.average
        }
        get url() {
            return this.get("url")
        }
        get thumbnailUrl() {
            return this.get("thumbnail_url", "")
        }
        get smallThumbnailUrl() {
            return this.thumbnailUrl ? this.thumbnailUrl.includes("class=thumb") ? this.thumbnailUrl.replace("class=thumb", "class=vsthumb") : this.thumbnailUrl.includes("width=") ? this.thumbnailUrl.replace("width=400,height=400", "width=80,height=80") : this.thumbnailUrl.match(/https?:\/\/cdn\.shopify.*/) ? this.thumbnailUrl.replace(/_[0-9]+x[0-9]+\./, "_80x80.") : this.thumbnailUrl.match(/wixstatic.*w_[0-9]+,h_[0-9]+/) ? this.thumbnailUrl.replace(/w_[0-9]+,h_[0-9]+/, "w_80,h_80") : this.thumbnailUrl : this.thumbnailUrl
        }
        get counts() {
            return this.get("counts", this.get("cached_counts", {}))
        }
        getCount(t, e = 0) {
            return this.counts[t] || e
        }
    };
    var _i = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "store_reply",
                resourceTitle: "Store Reply"
            }, e)), this.e.review && (this.review = this.e.review)
        }
        get bodyHtml() {
            return this.get("body", "").toString().replace(/\n/g, `<br/>
`)
        }
    };
    var kt = class extends at {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "video"
            }, e))
        }
        get isVideo() {
            return !0
        }
        get isPhoto() {
            return !1
        }
        static get placeholderUrl() {
            return "https://uploads.fera.ai/placeholders/video.png"
        }
        get importedVideoUrl() {
            return this.videoType === "url" ? this.url : (this.constructor.SOCIAL_URL_REGEXES[this.videoType].test(this.url), this.videoType === "youtube" ? `https://www.youtube.com/embed/${RegExp.$5}?modestbranding=1&autoplay=1` : this.videoType === "vimeo" ? `https://player.vimeo.com/video/${RegExp.$5}` : this.videoType === "instagram" ? `https://www.instagram.com/p/${RegExp.$3}/embed` : this.videoType === "facebook" ? `https://www.facebook.com/plugins/video.php?href=${this.url}` : this.url)
        }
        get videoType() {
            return Object.keys(this.constructor.SOCIAL_URL_REGEXES).find(t => this.constructor.SOCIAL_URL_REGEXES[t].test(this.url)) || "url"
        }
        get isUploaded() {
            return this.videoType === "url"
        }
        get type() {
            return "video"
        }
    };
    var St = class extends at {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "photo"
            }, e))
        }
        get isVideo() {
            return !1
        }
        get isPhoto() {
            return !0
        }
        get thumbnailUrl() {
            return this.get("thumbnail_url", this.get("url") || this.constructor.placeholderUrl)
        }
        get type() {
            return "photo"
        }
    };
    var O = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "review"
            }, e))
        }
        get title() {
            return this.forProduct ? this.t("Product Review") : this.t("Store Review")
        }
        get bodyHtml() {
            return this.body.toString().replace(/\n/g, `<br/>
`)
        }
        get rating() {
            return this.get("rating")
        }
        static get associations() {
            return {
                hasOne: [{
                    key: "customer",
                    klass: ct
                }, {
                    key: "product",
                    klass: R
                }, {
                    key: "channel",
                    klass: ye
                }],
                hasMany: [{
                    key: "media",
                    klass: at,
                    inverseOf: "review"
                }]
            }
        }
        Y(t, e) {
            if (t.klass === ct && e && (e.reviews = [this]), t.klass === at && e) {
                let i = e.type === "video" ? kt : St;
                return super.Y(h(n({}, t), {
                    klass: i
                }), e)
            }
            return super.Y(t, e)
        }
        get body() {
            return this.get("body", this.get("heading", ""))
        }
        get storeReply() {
            return this.get("store_reply") ? new _i(this.get("store_reply"), {
                app: this.app,
                review: this
            }) : null
        }
        get forProduct() {
            return this.get("subject") === "product"
        }
        get forStore() {
            return this.get("subject") === "store"
        }
        get hasLinkableProduct() {
            return this.forProduct && this.product && this.product.get("url")
        }
        get hasDisplayableProduct() {
            return this.forProduct && this.product && this.product.get("name")
        }
    };
    var ki = class extends w {
        constructor(t) {
            super(t), this.api = this.e.api, this.zo = this.e.configs
        }
        retrieveResource(t, e) {
            return new Promise((i, s) => {
                let a = this.zo.find(o => o.route === t);
                if (!a) throw new Error(`${t} combinable config not defined.`);
                a.queue.push({
                    resolve: i,
                    reject: s,
                    id: e
                }), setTimeout(() => this.jo(a), 1)
            })
        }
        jo(t) {
            if (t.queue.length > 0) {
                let e = t.queue;
                t.queue = [];
                let i = [...new Set(e.map(s => s.id.toString()))];
                i.length === 1 ? this.Vo(t, e) : this.Do(t, i, e)
            }
        }
        Do(t, e, i) {
            let s = t.klass,
                o = {
                    limit: Math.min(e.length, 100)
                };
            o[t.request.filter] = e, this.api.listResource({
                path: t.request.path,
                params: o,
                klass: s,
                key: t.listKey,
                cache: !0
            }).then(l => this.No(t, l, i), l => i.forEach(d => d.reject(l)))
        }
        No(t, e, i) {
            i.forEach(s => {
                let a = e[t.listKey].find(o => t.matchAttributes.some(l => o.get(l).toString() === s.id.toString()));
                a ? s.resolve(a) : s.resolve(t.resolveEmpty(s.id))
            })
        }
        Vo(t, e) {
            let i = t.klass,
                s = t.route.replace("{{ id }}", e[0].id);
            this.api.retrieveResource(s, {}, !0).then(a => e.forEach(o => o.resolve(new i(a.json, {
                app: this.app
            }))), a => e.forEach(o => o.reject(a)))
        }
    };
    var Ce = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "content_campaign"
            }, e))
        }
        get mediaTypes() {
            let t = [];
            return this.is("allow_photo") && t.push("image"), this.is("allow_video") && t.push("video"), t
        }
        get requestMedia() {
            return this.is("request_media")
        }
        get requestReview() {
            return !this.requestMedia
        }
    };
    var _e = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "submission"
            }, e))
        }
        static get associations() {
            return {
                hasOne: [{
                    key: "content_campaign",
                    klass: Ce
                }],
                hasMany: [{
                    key: "reviews",
                    klass: O
                }, {
                    key: "media",
                    klass: at
                }]
            }
        }
        get token() {
            return this.get("token")
        }
        get customerId() {
            return this.get("external_customer_id") || this.get("customer_id")
        }
        hasCustomer() {
            return this.isSet("customer_id") || this.isSet("external_customer_id")
        }
    };
    var Si = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "message"
            }, e))
        }
        static get associations() {
            return {
                hasOne: [{
                    key: "content_campaign",
                    klass: Ce
                }, {
                    key: "active_submission",
                    klass: _e
                }],
                hasMany: [{
                    key: "products",
                    klass: R
                }, {
                    key: "reviews",
                    klass: O
                }]
            }
        }
    };
    var Mi = class extends M {
        constructor(t, e = {}) {
            super(t, n({
                resourceName: "order"
            }, e))
        }
        static get associations() {
            return {
                hasMany: [{
                    key: "reviews",
                    klass: O
                }, {
                    key: "products",
                    klass: R
                }]
            }
        }
    };
    var Ri = class extends w {
        constructor(t = {}) {
            super(t), this.$ = {}, this.bs = new ki({
                app: this.app,
                api: this,
                configs: [{
                    route: "products/{{ id }}/rating",
                    klass: oe,
                    queue: [],
                    listKey: "ratings",
                    request: {
                        path: "products/ratings",
                        filter: "product_ids"
                    },
                    matchAttributes: ["product_id", "external_product_id"],
                    resolveEmpty: e => new oe({
                        external_product_id: e,
                        count: 0
                    }, {
                        app: this.app
                    })
                }, {
                    route: "products/{{ id }}",
                    klass: R,
                    queue: [],
                    listKey: "products",
                    request: {
                        path: "products",
                        filter: "external_ids"
                    },
                    matchAttributes: ["id", "external_id"],
                    resolveEmpty: e => new R({
                        external_id: e
                    }, {
                        app: this.app
                    })
                }]
            })
        }
        clearCache() {
            return this.$ = {}, this
        }
        retrieveStore() {
            return new Promise((t, e) => {
                this.retrieveResource("store", {}, !0).then(i => {
                    if (i.headers.get("X-Loc")) {
                        let s = i.headers.get("X-Loc").split("|");
                        this.app.geoService.setLocation({
                            region_name: s[0],
                            country_code: s[1],
                            latitude: s[3],
                            longitude: s[4],
                            continent: s[5],
                            ip: i.headers.get("X-Ip")
                        })
                    } else i.headers.get("cdn-RequestCountryCode") && this.app.geoService.setLocation({
                        country_code: i.headers.get("Cdn-RequestCountryCode")
                    });
                    t(new Bt(i.json, {
                        app: this.app
                    }))
                }, e)
            })
        }
        retrieveSubmissionOrder(t, e) {
            return new Promise((i, s) => {
                this.retrieveResource(`submissions/orders/${t}`, {
                    email: e
                }).then(a => {
                    a.handle(() => i(new Mi(a.json, {
                        app: this.app
                    })), s)
                }, s)
            })
        }
        retrieveMessage(t) {
            return new Promise((e, i) => {
                this.retrieveResource(`messages/${t}`).then(s => {
                    e(new Si(s.json, {
                        app: this.app
                    }))
                }, i)
            })
        }
        createSubmission(t = {}) {
            return new Promise((e, i) => {
                this.re("submissions", t).then(s => {
                    s.handle(() => e(new _e(s.json, {
                        app: this.app
                    })), i)
                }, i)
            })
        }
        finalizeSubmission(t, e = {}) {
            return new Promise((i, s) => {
                this.re(`submissions/${t}/finalize`, e).then(a => {
                    a.handle(() => i(a.json), s)
                }, s)
            })
        }
        deleteSubmission(t) {
            return new Promise((e, i) => {
                this.De({
                    path: `submissions/${t}`,
                    method: "DELETE"
                }).then(s => {
                    s.handle(() => e(s.json), i)
                }, i)
            })
        }
        listMedia(t = {}) {
            return this.listResource({
                path: "media",
                params: t,
                klassFunc: e => e.type === "video" ? kt : St,
                cache: !0
            })
        }
        listProductMedia(t, e = {}) {
            return this.ys({
                productId: t,
                params: e,
                subPath: "media",
                klassFunc: i => i.type === "video" ? kt : St,
                cache: !0
            })
        }
        listReviews(t = {}) {
            return this.xs({
                params: t,
                cache: !0
            })
        }
        listProductReviews(t, e = {}) {
            return this.ys({
                productId: t,
                params: e,
                subPath: "reviews",
                klass: O,
                cache: !0
            })
        }
        retrievePrivateReview(t) {
            return new Promise((e, i) => {
                this.retrieveResource(`submissions/reviews/${t}`).then(s => {
                    s.handle(() => e(new O(s.json, {
                        app: this.app
                    })), i)
                }, i)
            })
        }
        retrieveReview(t) {
            return m(this, null, function*() {
                let e = yield this.retrieveResource(`reviews/${t}`, {}, !0);
                return new O(e.json, {
                    app: this.app
                })
            })
        }
        retrieveMedia(t) {
            return m(this, null, function*() {
                let e = yield this.retrieveResource(`media/${t}`, {}, !0), i = e.json.type === "video" ? kt : St;
                return new i(e.json, {
                    app: this.app
                })
            })
        }
        listStoreReviews(t = {}) {
            return this.xs({
                params: h(n({}, t), {
                    subject: "store"
                }),
                cache: !0
            })
        }
        createReview(t, e = {}, i = {}) {
            return this.re(`submissions/${t}/reviews`, e, i)
        }
        createMedia(t, e = {}, i = {}) {
            return this.re(`submissions/${t}/batch_media`, e, i)
        }
        createCustomer(t, e = {}, i = {}) {
            return new Promise((s, a) => {
                this.re(`submissions/${t}/customers`, e, i).then(o => {
                    o.handle(() => s(o.json), a)
                }, a)
            })
        }
        retrieveTranslations(t, e = !0) {
            return m(this, null, function*() {
                let i = `/i18n/${t}.json`,
                    s = this.B(i),
                    a = yield this.De({
                        url: s,
                        cache: e
                    });
                return a.checkForErrors(), {
                    [t]: a.json
                }
            })
        }
        retrieveCustomer(t) {
            return m(this, null, function*() {
                let e = yield this.retrieveResource(`customers/${t}`, {}, !0);
                return new ct(e.json, {
                    app: this.app
                })
            })
        }
        retrieveProductRating(t) {
            return this.bs.retrieveResource("products/{{ id }}/rating", t)
        }
        retrieveProduct(t) {
            return this.bs.retrieveResource("products/{{ id }}", t)
        }
        listProducts(t = {}) {
            return this.listResource({
                path: "products",
                params: t,
                klass: R,
                cache: !0
            })
        }
        ys({
            productId: t,
            params: e = {},
            subPath: i,
            klassFunc: s = null,
            klass: a = null,
            cache: o = !0
        }) {
            return s = s || (() => a), new Promise((l, d) => {
                this.retrieveResource(`products/${t}/${i}`, e, o).then(u => {
                    let c = new R(u.json.product, {
                            app: this.app
                        }),
                        p = u.json.data.map(v => {
                            let y = s(v);
                            return new y(v, {
                                app: this.app,
                                product: c
                            })
                        });
                    c[i] = p;
                    let g = {
                        product: c,
                        meta: u.json.meta
                    };
                    u.json.rating && (g.rating = u.json.rating), g[i] = p, l(g)
                }, d)
            })
        }
        listResource(l) {
            return m(this, arguments, function*({
                path: t,
                params: e,
                klass: i = null,
                klassFunc: s = null,
                key: a = null,
                cache: o = !1
            }) {
                a = a || t, s = s || (() => i), this.app.config.useSampleData && (e = h(n({}, e), {
                    samples: !0
                }));
                let d = yield this.retrieveResource(t, e, o);
                d.checkForErrors();
                let u = {
                    meta: d.json.meta
                };
                return u[a] = d.json.data.map(c => {
                    let p = s(c);
                    return new p(c, {
                        app: this.app
                    })
                }), u
            })
        }
        xs({
            params: t,
            cache: e = !1
        }) {
            return this.app.config.useSampleData && (t = h(n({}, t), {
                samples: !0
            })), new Promise((i, s) => {
                this.retrieveResource("reviews", t, e).then(a => {
                    a.checkForErrors();
                    let o = {
                        meta: a.json.meta
                    };
                    o.reviews = a.json.data.map(l => new O(l, {
                        app: this.app
                    })), a.json.rating && (o.rating = a.json.rating), i(o)
                }, s)
            })
        }
        retrieveResource(s) {
            return m(this, arguments, function*(t, e = {}, i = !1) {
                this.app.config.useSampleData && (e = h(n({}, e), {
                    samples: !0
                }));
                let a = yield this.De({
                    path: t,
                    params: e,
                    method: "GET",
                    cache: i
                });
                return a.checkForErrors(), a
            })
        }
        re(t, e = {}, i = {}) {
            return this.De({
                path: t,
                params: i,
                method: "POST",
                body: e
            })
        }
        get isConfigured() {
            return this.app.config && (this.app.config.apiKey || this.app.config.appInstanceId)
        }
        De(d) {
            return m(this, arguments, function*({
                url: t,
                path: e,
                params: i = {},
                method: s = "GET",
                headers: a = {},
                body: o = null,
                cache: l = !1
            }) {
                let u = this.e.mock || fetch;
                this.app.config.cacheDisabled && (l = !1, s === "GET" && (i.cache = !1)), l && (u !== fetch || typeof caches == "undefined") && (l = !1), yield this.Fo();
                let c = l ? this.app.config.baseApiCdnUrl : this.app.config.baseApiUrl;
                if (t = t || new ht(`${c}/${e}.json?${this.qo(i)}`), ["POST", "PUT"].includes(s)) {
                    this.app.request.isHttps && this.app.request.url.protocol != t.protocol ? (o = this.Wo(o), delete a["Content-Type"]) : (a["Content-Type"] = "application/json", o = JSON.stringify(o));
                    let g = yield u(t.toString(), {
                        method: s,
                        body: o,
                        headers: a
                    });
                    return ve.from(g, {
                        app: this.app
                    })
                }
                let p = `${s} ${t}${JSON.stringify(a)} | ${JSON.stringify(o)}`;
                if (!l) {
                    let g = yield u(t.toString(), {
                        method: s,
                        body: o,
                        headers: a
                    });
                    return ve.from(g, {
                        app: this.app
                    })
                }
                return new Promise((g, v) => {
                    this.$[p] ? this.$[p].resolved ? g(this.$[p].resolved) : this.$[p].queue.push({
                        resolve: g,
                        reject: v
                    }) : (this.$[p] = {
                        queue: []
                    }, this.Ho(t.toString(), {
                        resolve: g,
                        reject: v,
                        method: s,
                        body: o,
                        headers: a,
                        cacheKey: p,
                        fetchMethod: u
                    }))
                })
            })
        }
        Ho(u, c) {
            return m(this, arguments, function*(t, {
                resolve: e,
                reject: i,
                method: s,
                body: a,
                headers: o,
                cacheKey: l,
                fetchMethod: d
            }) {
                try {
                    let p, g = yield caches.open("Fera.RequestCache");
                    p = yield g.match(t.toString()), p ? d(t.toString(), {
                        method: s,
                        body: a,
                        headers: o
                    }).then(y => g.put(t.toString(), y.clone())) : (p = yield d(t.toString(), {
                        method: s,
                        body: a,
                        headers: o
                    }), g.put(t.toString(), p.clone()));
                    let v = yield ve.from(p, {
                        app: this.app
                    });
                    for (v.clientOutdated && this.app.assetService.clearCache(), this.$[l].resolved = v, e(v); this.$[l].queue.length > 0;) this.$[l].queue.shift().resolve(v);
                    v.failed && delete this.$[l]
                } catch (p) {
                    for (this.$[l].rejected = p, i(p); this.$[l].queue.length > 0;) this.$[l].queue.shift().reject(p)
                }
            })
        }
        Fo() {
            return m(this, null, function*() {
                let t = this.Jt ? 1e3 : 6e4;
                if (!(yield ge(() => this.isConfigured, {
                        timeout: t
                    }))) throw new Error(`Fera API key not configured (waited ${t/1e3}s for config).`)
            })
        }
        qo(t = {}) {
            return new URLSearchParams(n(n({}, this.Uo), t))
        }
        get Uo() {
            let t = {
                client: `fjs-${this.app.version}`
            };
            if (this.app.config.apiKey) t.api_key = this.app.config.apiKey;
            else if (this.app.config.appInstanceId) t.app_instance_id = this.app.config.appInstanceId;
            else throw new Error("Fera API key not configured.");
            return t
        }
        Wo(t) {
            let e = new FormData,
                i = (s, a) => {
                    Array.isArray(s) ? s.forEach((o, l) => {
                        i(o, `${a}[${l}]`)
                    }) : typeof s == "object" && s !== null ? Object.keys(s).forEach(o => {
                        let l = s[o],
                            d = a ? `${a}[${o}]` : o;
                        i(l, d)
                    }) : e.append(a, s)
                };
            return i(t), e
        }
    };

    function Aa(r, t) {
        for (var e = 0; e < t.length; e++) {
            var i = t[e];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, i.key, i)
        }
    }

    function xs(r) {
        return function(t) {
            if (Array.isArray(t)) return zs(t)
        }(r) || function(t) {
            if (typeof Symbol != "undefined" && Symbol.iterator in Object(t)) return Array.from(t)
        }(r) || function(t, e) {
            if (t) {
                if (typeof t == "string") return zs(t, e);
                var i = Object.prototype.toString.call(t).slice(8, -1);
                if (i === "Object" && t.constructor && (i = t.constructor.name), i === "Map" || i === "Set") return Array.from(t);
                if (i === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return zs(t, e)
            }
        }(r) || function() {
            throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
        }()
    }

    function zs(r, t) {
        (t == null || t > r.length) && (t = r.length);
        for (var e = 0, i = new Array(t); e < t; e++) i[e] = r[e];
        return i
    }
    var Ea, js, ke, Vs, Ba, Oa = (Ea = ["a[href]", "area[href]", 'input:not([disabled]):not([type="hidden"]):not([aria-hidden])', "select:not([disabled]):not([aria-hidden])", "textarea:not([disabled]):not([aria-hidden])", "button:not([disabled]):not([aria-hidden])", "iframe", "object", "embed", "[contenteditable]", '[tabindex]:not([tabindex^="-"])'], js = function() {
        function r(s) {
            var a = s.targetModal,
                o = s.triggers,
                l = o === void 0 ? [] : o,
                d = s.onShow,
                u = d === void 0 ? function() {} : d,
                c = s.onClose,
                p = c === void 0 ? function() {} : c,
                g = s.openTrigger,
                v = g === void 0 ? "data-micromodal-trigger" : g,
                y = s.closeTrigger,
                b = y === void 0 ? "data-micromodal-close" : y,
                C = s.openClass,
                k = C === void 0 ? "is-open" : C,
                $ = s.disableScroll,
                P = $ !== void 0 && $,
                x = s.disableFocus,
                T = x !== void 0 && x,
                S = s.awaitCloseAnimation,
                L = S !== void 0 && S,
                V = s.awaitOpenAnimation,
                D = V !== void 0 && V,
                B = s.debugMode,
                W = B !== void 0 && B;
            (function(lt, Y) {
                if (!(lt instanceof Y)) throw new TypeError("Cannot call a class as a function")
            })(this, r), this.modal = document.getElementById(a), this.config = {
                debugMode: W,
                disableScroll: P,
                openTrigger: v,
                closeTrigger: b,
                openClass: k,
                onShow: u,
                onClose: p,
                awaitCloseAnimation: L,
                awaitOpenAnimation: D,
                disableFocus: T
            }, l.length > 0 && this.registerTriggers.apply(this, xs(l)), this.onClick = this.onClick.bind(this), this.onKeydown = this.onKeydown.bind(this)
        }
        var t, e, i;
        return t = r, (e = [{
            key: "registerTriggers",
            value: function() {
                for (var s = this, a = arguments.length, o = new Array(a), l = 0; l < a; l++) o[l] = arguments[l];
                o.filter(Boolean).forEach(function(d) {
                    d.addEventListener("click", function(u) {
                        return s.showModal(u)
                    })
                })
            }
        }, {
            key: "showModal",
            value: function() {
                var s = this,
                    a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
                if (this.activeElement = document.activeElement, this.modal.setAttribute("aria-hidden", "false"), this.modal.classList.add(this.config.openClass), this.scrollBehaviour("disable"), this.addEventListeners(), this.config.awaitOpenAnimation) {
                    var o = function l() {
                        s.modal.removeEventListener("animationend", l, !1), s.setFocusToFirstNode()
                    };
                    this.modal.addEventListener("animationend", o, !1)
                } else this.setFocusToFirstNode();
                this.config.onShow(this.modal, this.activeElement, a)
            }
        }, {
            key: "closeModal",
            value: function() {
                var s = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null,
                    a = this.modal;
                if (this.modal.setAttribute("aria-hidden", "true"), this.removeEventListeners(), this.scrollBehaviour("enable"), this.activeElement && this.activeElement.focus && this.activeElement.focus(), this.config.onClose(this.modal, this.activeElement, s), this.config.awaitCloseAnimation) {
                    var o = this.config.openClass;
                    this.modal.addEventListener("animationend", function l() {
                        a.classList.remove(o), a.removeEventListener("animationend", l, !1)
                    }, !1)
                } else a.classList.remove(this.config.openClass)
            }
        }, {
            key: "closeModalById",
            value: function(s) {
                this.modal = document.getElementById(s), this.modal && this.closeModal()
            }
        }, {
            key: "scrollBehaviour",
            value: function(s) {
                if (this.config.disableScroll) {
                    var a = document.querySelector("body");
                    switch (s) {
                        case "enable":
                            Object.assign(a.style, {
                                overflow: ""
                            });
                            break;
                        case "disable":
                            Object.assign(a.style, {
                                overflow: "hidden"
                            })
                    }
                }
            }
        }, {
            key: "addEventListeners",
            value: function() {
                this.modal.addEventListener("touchstart", this.onClick), this.modal.addEventListener("click", this.onClick), document.addEventListener("keydown", this.onKeydown)
            }
        }, {
            key: "removeEventListeners",
            value: function() {
                this.modal.removeEventListener("touchstart", this.onClick), this.modal.removeEventListener("click", this.onClick), document.removeEventListener("keydown", this.onKeydown)
            }
        }, {
            key: "onClick",
            value: function(s) {
                (s.target.hasAttribute(this.config.closeTrigger) || s.target.parentNode.hasAttribute(this.config.closeTrigger)) && (s.preventDefault(), s.stopPropagation(), this.closeModal(s))
            }
        }, {
            key: "onKeydown",
            value: function(s) {
                s.keyCode === 27 && this.closeModal(s), s.keyCode === 9 && this.retainFocus(s)
            }
        }, {
            key: "getFocusableNodes",
            value: function() {
                var s = this.modal.querySelectorAll(Ea);
                return Array.apply(void 0, xs(s))
            }
        }, {
            key: "setFocusToFirstNode",
            value: function() {
                var s = this;
                if (!this.config.disableFocus) {
                    var a = this.getFocusableNodes();
                    if (a.length !== 0) {
                        var o = a.filter(function(l) {
                            return !l.hasAttribute(s.config.closeTrigger)
                        });
                        o.length > 0 && o[0].focus(), o.length === 0 && a[0].focus()
                    }
                }
            }
        }, {
            key: "retainFocus",
            value: function(s) {
                var a = this.getFocusableNodes();
                if (a.length !== 0)
                    if (a = a.filter(function(l) {
                            return l.offsetParent !== null
                        }), this.modal.contains(document.activeElement)) {
                        var o = a.indexOf(document.activeElement);
                        s.shiftKey && o === 0 && (a[a.length - 1].focus(), s.preventDefault()), !s.shiftKey && a.length > 0 && o === a.length - 1 && (a[0].focus(), s.preventDefault())
                    } else a[0].focus()
            }
        }]) && Aa(t.prototype, e), i && Aa(t, i), r
    }(), ke = null, Vs = function(r) {
        if (!document.getElementById(r)) return console.warn("MicroModal: \u2757Seems like you have missed %c'".concat(r, "'"), "background-color: #f8f9fa;color: #50596c;font-weight: bold;", "ID somewhere in your code. Refer example below to resolve it."), console.warn("%cExample:", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", '<div class="modal" id="'.concat(r, '"></div>')), !1
    }, Ba = function(r, t) {
        if (function(i) {
                i.length <= 0 && (console.warn("MicroModal: \u2757Please specify at least one %c'micromodal-trigger'", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", "data attribute."), console.warn("%cExample:", "background-color: #f8f9fa;color: #50596c;font-weight: bold;", '<a href="#" data-micromodal-trigger="my-modal"></a>'))
            }(r), !t) return !0;
        for (var e in t) Vs(e);
        return !0
    }, {
        init: function(r) {
            var t = Object.assign({}, {
                    openTrigger: "data-micromodal-trigger"
                }, r),
                e = xs(document.querySelectorAll("[".concat(t.openTrigger, "]"))),
                i = function(o, l) {
                    var d = [];
                    return o.forEach(function(u) {
                        var c = u.attributes[l].value;
                        d[c] === void 0 && (d[c] = []), d[c].push(u)
                    }), d
                }(e, t.openTrigger);
            if (t.debugMode !== !0 || Ba(e, i) !== !1)
                for (var s in i) {
                    var a = i[s];
                    t.targetModal = s, t.triggers = xs(a), ke = new js(t)
                }
        },
        show: function(r, t) {
            var e = t || {};
            e.targetModal = r, e.debugMode === !0 && Vs(r) === !1 || (ke && ke.removeEventListeners(), (ke = new js(e)).showModal())
        },
        close: function(r) {
            r ? ke.closeModalById(r) : ke.closeModal()
        }
    });
    typeof window != "undefined" && (window.MicroModal = Oa);
    var Ds = Oa;
    var f = class r extends w {
        constructor(t = {}) {
            super(typeof t == "string" ? {
                content: t
            } : t), this.e.el && this.e.el.dataset && (this.e = n(n({}, this.e.el.dataset), this.e), this.el = this.e.el), this.Ot = [], this.z = this.e.children || this.e.contents || [], this.$i = [], this.content = this.e.content, this.e.c && this.addClass(this.e.c)
        }
        get isVisible() {
            if (!this.el || !this.rendered) return !1;
            let t = globalThis.getComputedStyle(this.el);
            return t.width !== "0" && t.height !== "0" && t.opacity !== "0" && t.display !== "none" && t.visibility !== "hidden"
        }
        get i() {
            return {
                app: this.app
            }
        }
        renderAsync() {
            return m(this, null, function*() {
                return this.se = "queued", this.render(), this
            })
        }
        render() {
            return this.l() === !1 ? this.el : (this.se = "during", this.Zo(), this.Yo(), this.Xo(), this.Ot.forEach(t => this.el.classList.add(t)), this.Jo(), this.Ko(), this.se = "after", this.r(), this.a(), this.rendered = !0, setTimeout(() => this.h(), 1), this.trigger("render"), this.el)
        }
        h() {
            this.Gh = !0, this.se = "complete", this.trigger("render:complete")
        }
        get Go() {
            return globalThis.innerWidth <= 550
        }
        Zo() {
            let t = this.Cs(this.s);
            this.el && this.s ? (Array.from(t.attributes).forEach(e => {
                this.el.getAttribute(e.name) === null && this.el.setAttribute(e.name, e.value)
            }), t.classList.forEach(e => this.el.classList.add(e)), this.el.innerHTML = t.innerHTML) : this.el = t
        }
        Pi() {
            this.trigger("resize", null, {
                bubbleUp: !0
            })
        }
        trigger(t, e = null, {
            bubbleUp: i = !1
        } = {}) {
            super.trigger(t, e), i && this.parent && this.parent.trigger(t, e, {
                bubbleUp: i
            })
        }
        debouncedTrigger(t, e = null, {
            bubbleUp: i = !1
        } = {}) {
            super.debouncedTrigger(t, e), i && this.parent && this.parent.debouncedTrigger(t, e, {
                bubbleUp: i
            })
        }
        Yo() {
            this.q("a[data-fera-action],button[data-fera-action]", t => {
                if (typeof this[t.dataset.feraAction] != "function") {
                    this.N(`${this.constructor.name}#${t.dataset.feraAction} referenced in component template but not defined.`, {
                        component: this,
                        el: t
                    });
                    return
                }
                t.addEventListener("click", e => {
                    e.preventDefault(), e.stopPropagation(), this[t.dataset.feraAction](e)
                })
            })
        }
        Xo() {
            this.q("[data-fera-component],[data-fera-component-container]", t => {
                let e = this[t.dataset.feraComponent || t.dataset.feraComponentContainer];
                if (!e) {
                    this.N(`Couldn't find child component object instance ${this.constructor.name}.${t.dataset.feraComponent} referenced in component template.`, {
                        container: t
                    });
                    return
                }
                e.rendered ? e.refreshView() : (t.dataset.feraComponent && (e.el = t), e.parent = this, e.render(), t.dataset.feraComponentContainer && t.appendChild(e.el)), this.$i.includes(e) || this.$i.push(e)
            })
        }
        w(t, e, {
            replace: i = !0
        } = {}) {
            i && (this.o(t).innerHTML = ""), this.Qo(t, e)
        }
        Qo(t, e) {
            return this.o(t).appendChild(e.renderOnce()), this
        }
        Jo() {
            this.Ne = this.o("[data-fera-child-container]") || this, this.z && this.z.forEach(t => {
                t instanceof r ? (t.parent = this, this.Ne.append(t.render())) : Object.keys(t).forEach(e => {
                    typeof e == "string" && (t[e] instanceof r && (t[e].parent = this), this.w(e, t[e]))
                })
            })
        }
        addChild(t, e = null) {
            if (t instanceof r) {
                if (e) return this.addChild({
                    [e]: t
                });
                if (this.z.includes(t)) return t.refreshView();
                t.parent = this, this.z.push(t), this.rendered && this.Ne.append(t.render())
            } else {
                if (Array.isArray(t)) return t.forEach(i => this.addChild(i, e));
                Object.keys(t).forEach(i => {
                    if (typeof i == "string") {
                        let s = this.z.find(a => !(a instanceof r) && a[i] === t[i]);
                        s ? s.refreshView() : (this.z.push({
                            [i]: t[i]
                        }), this.rendered && this.w(i, t[i]))
                    }
                })
            }
        }
        addChildren(t, e = null) {
            return this.addChild(t, e)
        }
        Cs(t) {
            if (!t) throw new Error(`${this.constructor.name} is missing a template.`);
            let e = document.createElement("template");
            return t = t.trim(), e.innerHTML = t, e.content.childNodes.length > 1 && this.N(`${this.constructor.name} has ${e.content.childNodes.length} root elements (max: 1).`, {
                template: e
            }), e.content.firstChild
        }
        addClass(t) {
            return t ? (t.indexOf(" ") !== -1 ? t.split(" ").forEach(e => this.addClass(e)) : (this.Ot.includes(t) || this.Ot.push(t), this.el && !this.el.classList.contains(t) && this.el.classList.add(t)), this) : this
        }
        removeClass(t) {
            return t ? (t.indexOf(" ") !== -1 ? t.split(" ").forEach(e => this.removeClass(e)) : (this.Ot = this.Ot.filter(e => e !== t.trim()), this.el && this.el.classList.contains(t) && this.el.classList.remove(t)), this) : this
        }
        contains(t) {
            return this.el ? (t = t instanceof this.constructor ? t.el : t, this === t || this.el.contains(t)) : !1
        }
        toggleClass(t, e = null) {
            e ? this.addClass(t) : e === null ? this.toggleClass(t, !this.hasClass(t)) : this.removeClass(t)
        }
        hasClass(t) {
            return this.el ? this.el.classList.contains(t) : this.Ot.includes(t)
        }
        renderOnce() {
            return this.rendered ? this.el : this.render()
        }
        toString() {
            return this.el.outerHTML
        }
        tn(t) {
            return this.el.querySelectorAll(t)
        }
        q(t, e) {
            this.tn(t).forEach(e)
        }
        o(t) {
            return this.el.querySelector(t)
        }
        Ii(t, e, i) {
            this.q(t, s => s.addEventListener(e, i))
        }
        hide() {
            this.addClass("fera-hidden"), this.trigger("hide")
        }
        show() {
            this.removeClass("fera-hidden"), this.trigger("show")
        }
        toggleVisible(t) {
            this.toggleClass("fera-hidden", !t)
        }
        get isShowing() {
            return this.rendered && !this.el.classList.contains("fera-hidden")
        }
        Fe(t) {
            this.q(t, e => e.classList.add("fera-hidden"))
        }
        Li(t) {
            this.q(t, e => e.classList.remove("fera-hidden"))
        }
        Ai(t, e) {
            e ? this.Li(t) : this.Fe(t)
        }
        Qh(t, e, i) {
            this.q(t, s => s.classList.toggle(e, i))
        }
        append(t) {
            return t = t && typeof t.renderOnce == "function" ? t.renderOnce() : t, this.el.append(t)
        }
        prepend(t) {
            return t = t && typeof t.renderOnce == "function" ? t.renderOnce() : t, this.el.prepend(t)
        }
        insertBefore(t, e) {
            return t = t && typeof t.renderOnce == "function" ? t.renderOnce() : t, e = e && e instanceof r ? e.el : e, this.el.insertBefore(t, e)
        }
        remove() {
            this.el && this.el.remove()
        }
        destroy() {
            this.remove(), this.rendered = !1, this.destroyed = !0, delete this.el, super.destroy()
        }
        clearChildren() {
            this.z.forEach(t => t.remove()), this.z = []
        }
        clear() {
            return this.el && (this.el.innerHTML = ""), this.z = [], this
        }
        tc(t, e, i) {
            if (typeof e == "function") {
                this.el.addEventListener(t, e);
                return
            }
            document.addEventListener(t, function(s) {
                for (var a = s.target; a && a != this; a = a.parentNode)
                    if (a.matches(e)) {
                        i.call(a, s);
                        break
                    }
            }, !1)
        }
        en(t) {
            return t.replace(/-./g, e => e[1].toUpperCase())
        }
        attr(t, e = void 0) {
            return e === void 0 ? this.el.getAttribute(t) : (e === null ? this.el.removeAttribute(t) : this.el.setAttribute(t, e), this)
        }
        data(t = void 0, e = void 0) {
            return t === void 0 ? this.el.dataset : (t = t.indexOf("-") === -1 ? t : this.en(t), e === void 0 ? this.el.dataset[t] || this.el[t] : (e === null ? delete this.el.dataset[t] : typeof e == "object" ? this.el[t] = e : this.el.dataset[t] = e, this))
        }
        Ko() {
            this.el.fera || (this.el.fera = this)
        }
        l() {
            this.se = "before"
        }
        r() {
            (this.e.onClick || Object.keys(this.it).some(e => e == "click")) && this.rn(), (this.e.onSwipe !== void 0 || Object.keys(this.it).some(e => e.startsWith("swipe"))) && this.Ei()
        }
        P(t = null) {
            if (this.addClass("fera-loading"), !this.rendered) return;
            this.zt = this.zt || this.Cs(this.sn);
            let e = this.zt.querySelector("[data-fera-text-container]");
            t ? (e.innerText = t, e.classList.remove("fera-hidden")) : e.classList.add("fera-hidden"), this.ae && this.o(this.ae) ? this.o(this.ae).append(this.zt) : this.append(this.zt)
        }
        C() {
            this.removeClass("fera-loading"), this.rendered && this.zt && this.zt.remove()
        }
        get ae() {
            return null
        }
        get sn() {
            return `<div class="fera-loadMask">
            <div class="fera-loadMask-visual fera-spinner">
                <svg width="49" height="49" viewBox="0 0 49 49" xmlns="http://www.w3.org/2000/svg"><g> <path d="M24.5 6.5V12.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /><path d="M42.5 24.5H36.5" stroke="#000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" /><path d="M37.227 37.228L32.9844 32.9854" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /><path d="M24.5 42.5V36.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /><path d="M11.7715 37.228L16.0141 32.9854" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /><path d="M6.5 24.5H12.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /><path d="M11.7715 11.7725L16.0141 16.0151" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></g></svg>
            </div>
            <span class="fera-loadMask-text" data-fera-text-container></span>
        </div>`
        }
        Ei() {
            this.an || (this.el.addEventListener("touchstart", t => this.nn(t), {
                passive: !0
            }), this.el.addEventListener("touchend", t => this.ln(t), {
                passive: !0
            }), this.an = !0)
        }
        nn(t) {
            if (t.targetTouches && t.targetTouches.length && t.targetTouches.length > 1) {
                this.qe = null;
                return
            }
            globalThis.visualViewport && globalThis.visualViewport.scale && globalThis.visualViewport.scale > 1.1 || (this._s = new Date, this.ks = t.changedTouches[0].screenX, this.qe = t.changedTouches[0].screenY)
        }
        ln(t) {
            this.qe && this._s && (new Date().getTime() - this._s.getTime() > 1e3 || (this.Ss = t.changedTouches[0].screenX, this.Ms = t.changedTouches[0].screenY, this.dn()))
        }
        dn() {
            this.Ss + 50 <= this.ks && this.trigger("swipe:left"), this.Ss - 50 >= this.ks && this.trigger("swipe:right"), this.Ms + 50 <= this.qe && this.trigger("swipe:up"), this.Ms - 50 >= this.qe && this.trigger("swipe:down")
        }
        rn() {
            this.hn || (this.addClass("fera--clickable"), this.el.addEventListener("click", t => {
                t.preventDefault(), t.stopPropagation(), this.Bi(t), this.hn = !0
            }))
        }
        onElement(t, e) {
            this.el ? this.el.addEventListener(t, i => e(i)) : this.once("render", () => this.el.addEventListener(t, i => e(i)))
        }
        addEventListener(t, e) {
            this.onElement(t, e)
        }
        Bi(t) {
            this.e.onClick && this.e.onClick(t), this.trigger("click", t, {
                bubbleUp: !0
            })
        }
        a() {}
        refreshView() {
            return this.rendered && this.a(), this.cn.forEach(t => t.refreshView()), this.$i.forEach(t => t.refreshView()), this
        }
        get cn() {
            return this.z.map(t => t instanceof r ? t : Object.values(t)).flat()
        }
        get s() {
            return this.e.tpl || ""
        }
    };
    var qt = class extends f {
        get ae() {
            return "[data-fera-content]"
        }
        get Rs() {
            return "[data-fera-content]"
        }
        show(t = null) {
            if (t && (this.content = t), !this.content) {
                this.N(`${this.constructor.name} has no content`, {
                    component: this,
                    opts: this.e
                });
                return
            }
            this.rendered ? this.refreshView() : this.render(), this.un(), super.show()
        }
        hide() {
            super.hide(), this.Oi && (this.el.remove(), this.Oi = !1)
        }
        un() {
            this.Oi || (document.querySelector("body").append(this.el), this.Oi = !0)
        }
        kt() {
            this.w(this.Rs, this.content)
        }
        r() {
            super.r(), this.Ts = this.el.querySelector(this.Rs), this.kt(), this.pn()
        }
        pn() {
            document.addEventListener("keydown", t => {
                this.isShowing && this.zi(t)
            })
        }
        zi(t) {
            t.code === "Escape" && this.hide()
        }
    };
    var Ti = class extends f {
        get s() {
            return `<svg class="fera-icon-close" xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 16 16" fill="#000">
    <path d="M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z"/>
</svg>`
        }
    };
    var it = class extends qt {
        constructor(t) {
            super(t), this.content = this.e.content
        }
        l() {
            super.l(), this.app.trigger("modal.render:before", this)
        }
        get M() {
            return this.e.title
        }
        get ae() {
            return "[data-fera-modal-dialog]"
        }
        r() {
            super.r(), this.w(".fera-modal-close-btn", new Ti({
                app: this.app
            })), this.app.on("page:change", () => this.hide(!0)), this.mn = this.o(".fera-modal-close-btn"), this.Ii("[data-fera-close-btn]", "click", () => this.hide()), this.ji = this.o("[data-fera-modal-dialog]"), setInterval(() => this.Vi(), 500), setInterval(() => this.Vi(), 1e3), this.$s = this.o("[data-fera-modal-overlay]"), this.e.allowOutsideClick && this.$s.addEventListener("click", t => t.target == this.$s && this.hide()), this.J && globalThis.addEventListener("popstate", t => {
                !this.rendered || this.destroyed || t.state && Object.keys(this.J).every(e => t.state[e] == this.J[e]) && this.app[t.state.fera]()
            })
        }
        Vi() {
            this.isShowing && this.gn && this.toggleClass("fera-modal--overflow-y", this.vn > globalThis.innerHeight)
        }
        get vn() {
            let t = this.ji.offsetHeight;
            return t += parseInt(globalThis.getComputedStyle(this.ji).getPropertyValue("margin-top")), t += parseInt(globalThis.getComputedStyle(this.ji).getPropertyValue("margin-bottom")), t
        }
        show() {
            var t;
            super.show(this.content);
            try {
                Ds.show(`modal-${this.k()}`, {
                    disableFocus: !0
                }), this.gn = !0, (t = document == null ? void 0 : document.body) == null || t.classList.add("fera-modal--open")
            } catch (e) {}
            return this.Vi(), this.wn(), this
        }
        wn() {
            this.J && this.app.request.addParams(this.J)
        }
        Di() {
            return this.e.beforeHide ? this.e.beforeHide() : !0
        }
        bn() {
            this.J && this.app.request.removeParams(this.J)
        }
        hide(t = !1) {
            var e;
            return (t || this.Di()) && (Ds.close(`modal-${this.k()}`), (e = document == null ? void 0 : document.body) == null || e.classList.remove("fera-modal--open"), super.hide(), this.bn()), this
        }
        startLoading(t = null) {
            this.P(t)
        }
        stopLoading() {
            this.C()
        }
        get s() {
            return `<div class="fera fera-modal" id="modal-${this.k()}" aria-hidden="true">
  <div tabindex="-1" class="fera-modal-overlay" data-fera-modal-overlay>
    <div class="fera-modal-dialog" role="dialog" aria-modal="true" data-fera-modal-dialog data-fera-child-container aria-labelledby="modal-${this.k()}-title">
      <div>
        <div class="fera-modal-header">
          <h1 id="modal-${this.k()}-title" class="fera-modal-title" data-fera-title>${this.M||""}</h1>
          <span aria-label="${this.t("Close modal")}" class="fera-modal-close-btn" data-fera-close-btn></span>
        </div>
        <div id="modal-${this.k()}-content" class="fera-modal-body" data-fera-content></div>
      </div>
    </div>
  </div>
</div>`
        }
    };
    var Mt = class extends it {
        constructor(t) {
            super(t), this.addClass("fera-submitter-modal")
        }
    };
    var Se = class extends f {
        constructor(t) {
            super(t), this.oe = this.e.value || this.e.initialValue, this.yn = this.e.required || !1, this.p = this.e.disabled || !1
        }
        r() {
            super.r(), this.I = this.o("[data-fera-input]")
        }
        get xn() {
            return this.e.name
        }
        get Ps() {
            let t = `data-fera-input class="fera-input" name="${this.xn}"`;
            return this.yn && (t += " required"), this.p && (t += " disabled"), t += Object.keys(this.e.inputAttr || {}).map(e => ` ${e}="${this.e.inputAttr[e]}"`).join(""), t
        }
        get disabled() {
            return this.p
        }
        disable() {
            this.p || (this.p = !0, this.refreshView())
        }
        enable() {
            this.p && (this.p = !1, this.refreshView())
        }
    };
    var $i = class extends Se {
        constructor(t) {
            super(t), this.Is = null
        }
        get disabled() {
            return this.p
        }
        set value(t) {
            this.setValue(t)
        }
        get value() {
            return this.oe
        }
        val() {
            return this.value
        }
        setValue(t) {
            this.oe = t, this.I.value = t, this.a();
            let e = new Event("input", {
                bubbles: !0
            });
            this.I.dispatchEvent(e), this.trigger("change", this.oe)
        }
        disable() {
            this.p || (this.p = !0, this.a())
        }
        enable() {
            this.p && (this.p = !1, this.a())
        }
        setHoverValue(t) {
            this.Is = t, this.Ls()
        }
        a() {
            super.a(), this.Ls(), this.toggleClass("fera-rating-input--disabled", this.p)
        }
        r() {
            super.r(), this.Ni()
        }
        As(t) {
            let e = parseInt(t.dataset.rating);
            this.setValue(e)
        }
        Ni() {
            this.q("[data-rating-star]", t => {
                t.addEventListener("click", e => {
                    e.preventDefault(), e.stopPropagation(), this.As(t)
                }), t.addEventListener("keyup", e => {
                    ["Enter", "Space"].includes(e.code) && this.As(t)
                }), t.addEventListener("mouseover", () => {
                    let e = parseInt(t.dataset.rating);
                    this.setHoverValue(e)
                }), t.addEventListener("mouseout", () => {
                    this.setHoverValue(null)
                })
            })
        }
        Ls() {
            this.q("[data-rating-star]", t => {
                parseInt(t.dataset.rating) <= (this.Is || this.value) ? t.classList.add("fera-rating-input-star--starred") : t.classList.remove("fera-rating-input-star--starred")
            })
        }
        Cn(t) {
            return `<span tabindex="0" aria-label="${this.t("{{ num_stars }}-star rating",{num_stars:this.formatNumber(t)})}" class="fera-rating-input-star ${t<=this.value?"fera-rating-input-star--starred":""}"
    data-rating="${t}" data-rating-star><b>\u2605</b></span>`
        }
        get s() {
            return `<div class="fera-rating-input" data-fera-rating-input>
  ${[1,2,3,4,5].map(t=>this.Cn(t)).join("")}
  <input type="hidden" data-fera-rating-value ${this.value?`value="${this.value}"`:""} ${this.Ps}>
</div>`
        }
    };
    var Pi = class extends f {
        get s() {
            return `<img class="fera-icon fera-icon-image" width="20" height="20" src="${this.B("fera/components/icons/image/image.svg")}" alt="${this.t("Image")}"/>`
        }
    };
    var Ii = class extends f {
        get s() {
            return `<img class="fera-icon fera-icon-play" width="89" height="88" src="${this.B("fera/components/icons/play/image.svg")}" alt="${this.t("Play Video")}"/>`
        }
    };
    var Wt = class extends f {
        constructor(t) {
            super(t), this.media = this.e.media, this.addClass(`fera-media fera-media--${this.media.type}`)
        }
        r() {
            super.r(), this.thumbnailImg = this.o(`[data-fera-${this.media.type}-item-thumbnail]`), this.thumbnailImg && this.media.thumbnailUrl && this.thumbnailImg.addEventListener("error", () => this.trigger("error", this.media.thumbnailUrl))
        }
        usePlaceholderAsThumbnailUrl() {
            this.media.set("thumbnail_url", this.media.constructor.placeholderUrl), this.thumbnailImg.src = this.thumbnailImgUrl, this.refreshView()
        }
        h() {
            super.h(), this.toggleClass("fera-media--placeholder", this.isPlaceholder)
        }
        get url() {
            return this.media.url
        }
        get isPlaceholder() {
            return this.media.isUploaded && !!this.url.match(/uploads\.fera\..+\/placeholders?(\/|[a-z-_]*\.[a-z]+)/)
        }
    };
    var Me = class extends Wt {
        constructor(t) {
            super(t), this.addClass(`fera-media-thumbnail fera-media-thumbnail--${this.media.type}`), this.e.size && this.addClass(`fera-media-thumbnail--${this.e.size}`)
        }
        get url() {
            return this.media.thumbnailUrl
        }
        get thumbnailImgUrl() {
            return this.e.size === "small" ? this.media.smallThumbnailUrl || "" : this.media.thumbnailUrl || ""
        }
        get _n() {
            return `<img class="fera-media-thumbnail-image" ${this.e.lazyLoad?"data-":""}src="${this.thumbnailImgUrl}"
          data-fera-${this.media.type}-item-thumbnail width="100" height="100" loading="lazy" data-url="${this.Es}" ${this.Bs||""} />`
        }
        get Es() {
            return this.media.url || ""
        }
        get kn() {
            return this._n
        }
        get s() {
            return `<div data-id="${this.media.id||""}">${this.kn}</div>`
        }
    };

    function za() {
        if (globalThis.fera && globalThis.fera.Os) return globalThis.fera.Os;
        let r = globalThis.navigator.userAgent,
            t = null;
        return r.match(/Firefox/) ? t = "firefox" : r.match(/Chrome\/[0-9]+/) ? r.match(/Edg\/[0-9]+/) ? t = "edge" : t = "chrome" : r.match(/Safari\/[0-9]+/) && (t = "safari"), globalThis.fera.Os = t, t
    }

    function ja(r) {
        return Array.isArray(r) || (r = [r]), r.includes(za())
    }
    var Re = class extends Wt {
        r() {
            super.r(), this.addClass("fera-media--video"), ja(["chrome", "edge"]) && this.el.addEventListener("click", () => this.togglePlay())
        }
        get imgForLightboxBg() {
            return this.errored ? null : this.media.thumbnailUrl
        }
        togglePlay() {
            this.paused ? this.play() : this.stop()
        }
        get paused() {
            return this.el && this.el.paused
        }
        play() {
            return this.el && this.el.play && this.paused && this.el.play()
        }
        stop() {
            return this.el && this.el.pause && !this.paused && this.el.pause()
        }
        Sn() {
            let t = this.media.importedVideoUrl;
            return ["youtube", "vimeo", "instagram", "facebook"].includes(this.media.videoType) ? `<iframe src="${t}" width="640" height="480" frameborder="0" ${this.e.autoplay?"autoplay":""}  data-id="${this.media.id}"
                    ${this.e.showControls?'allow="accelerometer; autoplay; picture-in-picture" allowfullscreen':""}></iframe>` : this.zs(t)
        }
        zs(t) {
            return `<video src="${t}" data-id="${this.media.id}" disablePictureInPicture="true" ${this.e.showControls?"controls":""} ${this.e.autoplay?"autoplay":""}>`
        }
        get s() {
            return this.media.isUploaded ? this.zs(this.url) : this.Sn()
        }
    };
    var ut = class extends Me {
        constructor(t) {
            super(t), this.playBtn = new Ii({
                app: this.app,
                onClick: e => this.Bi(e),
                c: "fera-video-play-btn"
            })
        }
        r() {
            super.r(), this.append(this.playBtn), this.thumbnailImg = this.o("[data-fera-video-item-thumbnail]"), this.thumbnailImg && !this.media.get("thumbnail_url") && this.media.url ? (this.video = new Re({
                app: this.app,
                media: this.media,
                c: "fera-media-thumbnail-video",
                onClick: () => {
                    this.e.onClick(this.media)
                },
                showControls: !1,
                autoplay: !1
            }), this.thumbnailImg.remove(), this.prepend(this.video)) : this.thumbnailImg.src = this.media.thumbnailUrl
        }
        get Es() {
            return `${this.media.url||""}#t=0.001`
        }
        get Bs() {
            return `alt="${this.t("Video thumbnail")}" itemprop="reviewVideo" itemscope itemtype="https://schema.org/VideoObject"`
        }
    };
    var ft = class extends Me {
        get Bs() {
            return `alt="${this.t("Photo thumbnail")}" itemprop="reviewPhoto" itemscope itemtype="https://schema.org/Photograph"`
        }
    };
    var Li = class extends qt {
        r() {
            super.r(), this.el.addEventListener("click", t => {
                t.target === this.Ts && this.hide()
            })
        }
        show(t = null) {
            var e;
            super.show(t), (e = document == null ? void 0 : document.body) == null || e.classList.add("fera-lightbox--open")
        }
        hide() {
            var t;
            super.hide(), (t = document == null ? void 0 : document.body) == null || t.classList.remove("fera-lightbox--open")
        }
        get s() {
            return `<div class="fera fera-lightbox">
    <a href="#" class="fera-lightbox-close-btn" data-fera-action="hide">&times;</a>
    <div class="fera-lightbox-content" data-fera-content></div>
</div>`
        }
    };
    var ii = class extends f {
        constructor(t) {
            super(t), this.direction = this.e.direction === "left" ? "left" : "right"
        }
        l() {
            super.l(), this.toggleClass("fera-media-nav-caret-icon--left", this.direction === "left"), this.toggleClass("fera-media-nav-caret-icon--right", this.direction === "right")
        }
        get s() {
            return `<svg class="fera-media-nav-caret-icon" width="96" height="96" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_mediaNavBtn_${this.k()})">
        <g filter="url(#filter0_d_mediaNavBtn_${this.k()})">
            <path d="M68 48C68 36.9543 59.0457 28 48 28C36.9543 28 28 36.9543 28 48C28 59.0457 36.9543 68 48 68C59.0457 68 68 59.0457 68 48Z" fill="black" fill-opacity="0.3"/>
            <path class="fera-icon-caret-line" d="M50.25 53.25L45 48L50.25 42.75" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
    </g>
    <defs>
        <filter id="filter0_d_mediaNavBtn_${this.k()}" x="0" y="4" width="96" height="96" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix"/>
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
            <feOffset dy="4"/>
            <feGaussianBlur stdDeviation="14"/>
            <feComposite in2="hardAlpha" operator="out"/>
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0"/>
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_mediaNavBtn_${this.k()}"/>
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_mediaNavBtn_${this.k()}" result="shape"/>
        </filter>
        <clipPath id="clip0_mediaNavBtn_${this.k()}">
            <rect width="96" height="96" fill="white"/>
        </clipPath>
    </defs>
</svg>`
        }
    };
    var Ai = class extends f {
        constructor(t) {
            super(t), this.prevBtn = new ii({
                app: this.app,
                c: "fera-media-nav-btn",
                direction: "left",
                onClick: () => this.e.onPrev()
            }), this.nextBtn = new ii({
                app: this.app,
                c: "fera-media-nav-btn",
                direction: "right",
                onClick: () => this.e.onNext()
            })
        }
        get s() {
            return `<div class="fera-media-nav">
    <svg data-fera-component="prevBtn" data-fera-action="showPrev"></svg>
    <svg data-fera-component="nextBtn" data-fera-action="showNext"></svg>
</div>`
        }
    };
    var Te = class extends f {
        constructor(t) {
            super(n({
                videoMediaItem: ut,
                photoMediaItem: ft
            }, t)), this.media = this.e.media, this.items = this.e.media.map(e => this.js(e)), this.collection = this.e.collection, this.collection && this.collection.on("load:more", e => this.addMedia(e)), this.currentItemIndex = 0, this.on("swipe:left", () => this.showNext()), this.on("swipe:right", () => this.showPrev()), this.nav = new Ai({
                app: this.app,
                c: "fera-media-carousel-nav",
                onPrev: () => this.showPrev(),
                onNext: () => this.showNext()
            })
        }
        js(t) {
            let e = this.Mn(t),
                i = new e(this.ne(t));
            return i.onElement("click", () => this.trigger("media.click", {
                media: t,
                component: i
            })), i
        }
        ne(t) {
            return {
                app: this.app,
                c: "fera-media-carousel-item",
                media: t
            }
        }
        Mn(t) {
            return t.isVideo ? this.e.videoMediaItem : this.e.photoMediaItem
        }
        l() {
            super.l(), this.items.length <= 1 && this.nav.hide()
        }
        r() {
            super.r(), this.itemsContainer = this.o("[data-fera-items-container]"), this.currentItem && this.currentItem.media && this.showMedia(this.currentItem.media)
        }
        a() {
            super.a(), this.items.forEach((t, e) => {
                let i = e === this.currentItemIndex;
                t.toggleClass("fera-media-carousel-item--current", i), i ? this.itemsContainer.append(t.renderOnce()) : (typeof t.stop == "function" && t.stop(), t.remove())
            })
        }
        get currentItem() {
            return this.items[this.currentItemIndex]
        }
        set currentItem(t) {
            let e = this.items.indexOf(t);
            e !== -1 && (this.currentItemIndex = e)
        }
        showMedia(t) {
            let e = this.items.find(i => i.media.id === t.id);
            e && (this.currentItem = e, this.refreshView()), this.trigger("media.show")
        }
        addMedia(t) {
            let e = t.map(i => this.js(i));
            this.items.push(...e), this.refreshView()
        }
        Rn() {
            return this.currentItemIndex === this.items.length - 1 && this.collection && this.collection.totalCount > this.items.length
        }
        Tn() {
            return m(this, null, function*() {
                this.P(), this.collection && (yield this.collection.loadMore()), this.C()
            })
        }
        showNext() {
            return m(this, null, function*() {
                this.Rn() && (yield this.Tn());
                let t = this.items[this.currentItemIndex + 1];
                t || (t = this.items[0]), this.showMedia(t.media)
            })
        }
        showPrev() {
            let t = this.items[this.currentItemIndex - 1];
            t || (t = this.items[this.items.length - 1]), this.showMedia(t.media)
        }
        get s() {
            return `<div class="fera-media-carousel">
    <div class="fera-media-carousel-items" data-fera-items-container></div>
    <div data-fera-component="nav"></div>
</div>`
        }
    };
    var Ei = class extends Wt {
        r() {
            super.r(), this.$n(), this.el.addEventListener("click", t => {
                t.offsetX < this.el.outerWidth * .25 && this.trigger("click:left"), t.offsetX > this.el.outerWidth * .75 && this.trigger("click:right")
            })
        }
        get imgForLightboxBg() {
            return this.loaded ? this.media.url : this.errored ? null : this.media.thumbnailUrl
        }
        $n() {
            if (this.media.thumbnailUrl === this.media.url) return;
            let t = new Image;
            t.src = this.media.url, t.src && (this.addClass("fera-media--loading"), t.addEventListener("error", () => {
                this.errored = !0, this.removeClass("fera-media--loading"), this.addClass("fera-media--error"), this.trigger("error")
            }), t.addEventListener("load", () => {
                this.loaded = !0, this.el.src === this.media.thumbnailUrl && (this.el.src = this.media.url, this.removeClass("fera-media--loading")), this.trigger("load")
            }))
        }
        get s() {
            return `<img src="${this.media.thumbnailUrl}"  alt="Customer photo" data-id="${this.media.id}" />`
        }
    };
    var Bi = class extends Te {
        constructor(t) {
            super(n({
                videoMediaItem: Re,
                photoMediaItem: Ei
            }, t))
        }
        ne(t) {
            return h(n({}, super.ne(t)), {
                autoplay: !0,
                showControls: !0
            })
        }
        showMedia(t) {
            super.showMedia(t), this.Vs(this.currentItem.imgForLightboxBg), this.currentItem.loaded || this.currentItem.once("load", () => this.Vs(this.currentItem.imgForLightboxBg))
        }
        Vs(t) {
            this.el && (t && this.Fi == t || (this.Fi = t, this.Fi ? this.el.style.setProperty("--current-media-gallery-bg-img", `url(${this.Fi})`) : this.el.style.removeProperty("--current-media-gallery-bg-img")))
        }
    };
    var $e = class extends f {
        constructor(t) {
            super(t), this.e.value && this.setValue(this.e.value)
        }
        l() {
            super.l(), this.el && this.el.dataset && this.el.dataset.value && (this.value = parseFloat(this.el.dataset.value))
        }
        get Pn() {
            return this.e.showRatingDesc || !1
        }
        get jt() {
            return this.e.includeSeoAttributes
        }
        get percent() {
            return this.value && this.value > 0 ? this.value / .05 : 0
        }
        setValue(t) {
            this.value = parseFloat(t), this.refreshView()
        }
        a() {
            super.a(), this.We()
        }
        r() {
            super.r(), this.le = this.o(".fera-star-rating")
        }
        In() {
            this.We(), [10, 100, 200, 300, 400, 500].forEach(t => setTimeout(() => this.We(), t)), setInterval(() => this.We(), 1e3)
        }
        h() {
            super.h(), this.In()
        }
        We() {
            if (!this.le) return;
            let t = Array.from(this.le.querySelectorAll("b"));
            if (!this.value) return;
            let e = Math.floor(this.value),
                i = t.reduce((s, a) => {
                    let o = 0,
                        l = t.indexOf(a) >= e,
                        d = getComputedStyle(a);
                    d.letterSpacing.match(/px$/) && (o = parseFloat(d.letterSpacing.replace(/px$/, "") || 0)), d.marginRight.match(/px$/) && (o += parseFloat(d.marginRight.replace(/px$/, "") || 0));
                    let u = a.offsetWidth,
                        c = u + o;
                    return l ? s + u * (this.value - e) : s + c
                }, 0);
            this.le.style.width !== `${i}px` && (this.le.style.width = `${i}px`)
        }
        get s() {
            return `<div class="fera-star" data-rating="${this.value}" style="position: relative;">
    <span class="fera-star-bg"><b>\u2605</b></span>
    <span class="fera-star-rating" style="position: absolute; top:0; left: 0; width: 100%;" data-fera-star><b>\u2605</b></span>
    ${this.Pn?`<span class="fera-stars-desc">${this.value}</span>`:""}
</div>`
        }
    };
    var Ht = class extends $e {
        r() {
            super.r(), this.le = this.o(".fera-stars-rating")
        }
        get s() {
            return `<div class="fera-stars" data-rating="${this.value}" style="position: relative;">
    <span class="fera--srOnly" style="position: absolute; top: 0; opacity: 0;" ${this.jt?'itemprop="ratingValue"':""}>${this.value}</span>
    <span class="fera-stars-bg"><b>\u2605</b><b>\u2605</b><b>\u2605</b><b>\u2605</b><b>\u2605</b></span>
    <span class="fera-stars-rating" style="position: absolute; top:0; left: 0; width: ${this.percent}%;" data-fera-stars><b>\u2605</b><b>${this.value>1?"\u2605":""}</b><b>${this.value>2?"\u2605":""}</b><b>${this.value>3?"\u2605":""}</b><b>${this.value>4?"\u2605":""}</b></span>
</div>`
        }
    };
    var Ut = class extends f {
        constructor(t) {
            super(t), this.content = this.e.content || "", this.maxLength = this.e.maxLength || 100
        }
        l() {
            super.l(), this.maxLength = this.el && this.el.dataset.maxLength || this.maxLength, typeof this.maxLength == "string" && this.maxLength.indexOf("xs") !== -1 && (this.maxLength = parseInt(this.maxLength.split("/")[globalThis.innerWidth < 575 ? 0 : 1]))
        }
        r() {
            super.r(), this.Ii(".fera-truncatedText-showMore", "click", t => {
                t.preventDefault(), t.stopPropagation(), this.showMore()
            }), this.e.expandOn === "hover" && (this.el.addEventListener("mouseenter", () => this.showMore()), this.el.addEventListener("mouseleave", () => this.showLess()), this.Fe(".fera-truncatedText-showMore"))
        }
        showMore() {
            this.isTruncated && (this.Fe(".fera-truncatedText--truncated"), this.Li(".fera-truncatedText--full"), this.Pi())
        }
        showLess() {
            this.isTruncated && (this.Li(".fera-truncatedText--truncated"), this.Fe(".fera-truncatedText--full"), this.Pi())
        }
        get isTruncated() {
            return this.content.length > this.maxLength
        }
        get truncatedContent() {
            return this.content.slice(0, this.maxLength) || ""
        }
        get s() {
            return this.isTruncated ? `<div class="fera-truncatedText">
    <div class="fera-truncatedText--truncated">${this.truncatedContent.replace(/(\n\r?|\r\n?)/g,"<br>")}...<a href="#" class="fera-link fera-truncatedText-showMore">${this.t("Show More")}</a></div>
    <div class="fera-truncatedText--full fera-hidden">${this.content.replace(/(\n\r?|\r\n?)/g,"<br>")}</div>
</div>` : `<div class="fera-truncatedText fera-truncatedText--full">${this.content.replace(/(\n\r?|\r\n?)/g,"<br>")}</div>`
        }
    };
    var Ot = class extends f {
        constructor(t) {
            super(t), this.I = this.e.time || this.e.date, this.de = this.Ln(), this.An = new Intl.RelativeTimeFormat(this.e.language || this.e.locale || this.app.locale || "en")
        }
        Ln() {
            if (typeof this.I == "string") {
                let t = Date.parse(this.I);
                return typeof t == "number" ? new Date(t) : null
            } else return this.I
        }
        toString() {
            if (this.de === null) return this.ft("Invalid date input", this.I), typeof this.I == "string" ? this.I.split("T")[0] : "";
            let t = this.toSeconds(),
                e = {
                    year: 31536e3,
                    month: 2628e3,
                    week: 604800,
                    day: 86400,
                    hour: 3600,
                    minute: 60,
                    second: 0
                },
                i = Object.keys(e).find(a => e[a] <= t);
            if (!i) return this.ft("Invalid TimeAgo value: ", this.de), "";
            let s = this.En(t, e[i]);
            return this.An.format(-s, i)
        }
        toSeconds() {
            return Math.floor((new Date().getTime() - this.de.getTime()) / 1e3)
        }
        En(t, e) {
            return isNaN(t) || t <= 1 ? 1 : e <= 0 ? t : Math.max(Math.floor(t / e), 1)
        }
        a() {
            super.a(), this.el.innerHTML = this.toString()
        }
        get s() {
            return `<span class="fera-timeAgo" data-timestamp="${this.de?this.de.getTime():this.I}"></span>`
        }
    };
    var Oi = class extends f {
        constructor(t) {
            super(t), this.widgetModel = this.e.widgetModel, this.review = this.e.review, this.body = new Ut({
                app: this.app,
                content: this.review.storeReply.get("body")
            }), this.timeAgo = new Ot({
                app: this.app,
                date: this.review.storeReply.get("created_at")
            })
        }
        l() {
            super.l(), this.el && typeof this.el.dataset.feraInitialState != "undefined" ? this.toggle(this.el.dataset.feraInitialState === "expanded") : this.toggle(this.e.initialState === "expanded"), this.el && this.el.dataset.maxLength && (this.body.maxLength = this.el.dataset.maxLength)
        }
        get options() {
            return n(n({}, this.L), this.e.options || (this.widgetModel ? this.widgetModel.getData() : {}))
        }
        get L() {
            return this.review.forStore ? et.defaultTypeSettings : tt.defaultTypeSettings
        }
        collapse() {
            this.toggle(!1)
        }
        expand() {
            this.toggle(!0)
        }
        toggle(t) {
            this.toggleClass("fera-review-reply--expanded", !!t), this.toggleClass("fera-review-reply--collapsed", !t), this.rendered && !this.destroyed && this.Pi()
        }
        get s() {
            return `<div class="fera-review-reply">
    <svg class="fera-review-reply-triangle" width="20" height="20" viewBox="0 0 20 20" fill="none"
         xmlns="http://www.w3.org/2000/svg">
        <mask id="path-1-inside-1_2533_410165" fill="white">
            <path d="M0 9.92871L9.92871 -2.45768e-08L19.8574 9.92871L9.92871 19.8574L0 9.92871Z"></path>
        </mask>
        <path d="M0 9.92871L9.92871 -2.45768e-08L19.8574 9.92871L9.92871 19.8574L0 9.92871Z" fill="#FAFAFA" class="fera-review-reply-triangle-inside"></path>
        <path
                d="M9.92871 -2.45768e-08L10.6358 -0.707107L9.92871 -1.41421L9.2216 -0.707107L9.92871 -2.45768e-08ZM0.707107 10.6358L10.6358 0.707107L9.2216 -0.707107L-0.707107 9.2216L0.707107 10.6358ZM9.2216 0.707107L19.1503 10.6358L20.5645 9.2216L10.6358 -0.707107L9.2216 0.707107Z"
                fill="#F2F2F2" mask="url(#path-1-inside-1_2533_410165)" class="fera-review-reply-triangle-outside"></path>
    </svg>
    <div class="fera-review-reply-dateAndActions">
        <div class="fera-review-reply-actions">
            <a href="#" data-fera-action="expand"
               class="fera-review-reply-action fera-review-reply-action-expand">${this.t("Show Reply (1)")}</a>
            <a href="#" data-fera-action="collapse"
               class="fera-review-reply-action fera-review-reply-action-collapse">${this.t("Hide Reply")}</a>
        </div>
        <div class="fera-review-reply-date">
            <meta itemprop="date" content="${this.review.storeReply.get("created_at")}">
            <span class="fera-review-date-val" data-fera-component="timeAgo" data-value="${this.review.storeReply.get("created_at")}">${this.review.storeReply.get("created_at")}</span>
        </div>
    </div>
    <div class="fera-review-reply-body" data-fera-component="body">${this.review.storeReply.bodyHtml}</div>
    <div class="fera-review-reply-store">
        <span><span class="fera-review-reply-store-name" data-value="${this.store.get("reply_to_reviews_as")}">${this.store.get("reply_to_reviews_as")}</span></span>
    </div>
</div>`
        }
    };
    var zi = class extends Ut {
        constructor(t) {
            super(t), this.addClass("fera-review-body")
        }
        showMore() {
            this.e.onShowMore ? this.e.onShowMore() : super.showMore()
        }
    };
    var z = "top",
        F = "bottom",
        N = "right",
        j = "left",
        Cs = "auto",
        ne = [z, F, N, j],
        Zt = "start",
        Pe = "end",
        Va = "clippingParents",
        _s = "viewport",
        ri = "popper",
        Da = "reference",
        Ns = ne.reduce(function(r, t) {
            return r.concat([t + "-" + Zt, t + "-" + Pe])
        }, []),
        ks = [].concat(ne, [Cs]).reduce(function(r, t) {
            return r.concat([t, t + "-" + Zt, t + "-" + Pe])
        }, []),
        Qo = "beforeRead",
        tn = "read",
        en = "afterRead",
        rn = "beforeMain",
        sn = "main",
        an = "afterMain",
        on = "beforeWrite",
        nn = "write",
        ln = "afterWrite",
        Na = [Qo, tn, en, rn, sn, an, on, nn, ln];

    function U(r) {
        return r ? (r.nodeName || "").toLowerCase() : null
    }

    function A(r) {
        if (r == null) return window;
        if (r.toString() !== "[object Window]") {
            var t = r.ownerDocument;
            return t && t.defaultView || window
        }
        return r
    }

    function wt(r) {
        var t = A(r).Element;
        return r instanceof t || r instanceof Element
    }

    function q(r) {
        var t = A(r).HTMLElement;
        return r instanceof t || r instanceof HTMLElement
    }

    function si(r) {
        if (typeof ShadowRoot == "undefined") return !1;
        var t = A(r).ShadowRoot;
        return r instanceof t || r instanceof ShadowRoot
    }

    function dn(r) {
        var t = r.state;
        Object.keys(t.elements).forEach(function(e) {
            var i = t.styles[e] || {},
                s = t.attributes[e] || {},
                a = t.elements[e];
            !q(a) || !U(a) || (Object.assign(a.style, i), Object.keys(s).forEach(function(o) {
                var l = s[o];
                l === !1 ? a.removeAttribute(o) : a.setAttribute(o, l === !0 ? "" : l)
            }))
        })
    }

    function hn(r) {
        var t = r.state,
            e = {
                popper: {
                    position: t.options.strategy,
                    left: "0",
                    top: "0",
                    margin: "0"
                },
                arrow: {
                    position: "absolute"
                },
                reference: {}
            };
        return Object.assign(t.elements.popper.style, e.popper), t.styles = e, t.elements.arrow && Object.assign(t.elements.arrow.style, e.arrow),
            function() {
                Object.keys(t.elements).forEach(function(i) {
                    var s = t.elements[i],
                        a = t.attributes[i] || {},
                        o = Object.keys(t.styles.hasOwnProperty(i) ? t.styles[i] : e[i]),
                        l = o.reduce(function(d, u) {
                            return d[u] = "", d
                        }, {});
                    !q(s) || !U(s) || (Object.assign(s.style, l), Object.keys(a).forEach(function(d) {
                        s.removeAttribute(d)
                    }))
                })
            }
    }
    var Fa = {
        name: "applyStyles",
        enabled: !0,
        phase: "write",
        fn: dn,
        effect: hn,
        requires: ["computeStyles"]
    };

    function Z(r) {
        return r.split("-")[0]
    }
    var Rt = Math.max,
        Ie = Math.min,
        Yt = Math.round;

    function ai() {
        var r = navigator.userAgentData;
        return r != null && r.brands && Array.isArray(r.brands) ? r.brands.map(function(t) {
            return t.brand + "/" + t.version
        }).join(" ") : navigator.userAgent
    }

    function ji() {
        return !/^((?!chrome|android).)*safari/i.test(ai())
    }

    function bt(r, t, e) {
        t === void 0 && (t = !1), e === void 0 && (e = !1);
        var i = r.getBoundingClientRect(),
            s = 1,
            a = 1;
        t && q(r) && (s = r.offsetWidth > 0 && Yt(i.width) / r.offsetWidth || 1, a = r.offsetHeight > 0 && Yt(i.height) / r.offsetHeight || 1);
        var o = wt(r) ? A(r) : window,
            l = o.visualViewport,
            d = !ji() && e,
            u = (i.left + (d && l ? l.offsetLeft : 0)) / s,
            c = (i.top + (d && l ? l.offsetTop : 0)) / a,
            p = i.width / s,
            g = i.height / a;
        return {
            width: p,
            height: g,
            top: c,
            right: u + p,
            bottom: c + g,
            left: u,
            x: u,
            y: c
        }
    }

    function Le(r) {
        var t = bt(r),
            e = r.offsetWidth,
            i = r.offsetHeight;
        return Math.abs(t.width - e) <= 1 && (e = t.width), Math.abs(t.height - i) <= 1 && (i = t.height), {
            x: r.offsetLeft,
            y: r.offsetTop,
            width: e,
            height: i
        }
    }

    function Vi(r, t) {
        var e = t.getRootNode && t.getRootNode();
        if (r.contains(t)) return !0;
        if (e && si(e)) {
            var i = t;
            do {
                if (i && r.isSameNode(i)) return !0;
                i = i.parentNode || i.host
            } while (i)
        }
        return !1
    }

    function rt(r) {
        return A(r).getComputedStyle(r)
    }

    function Fs(r) {
        return ["table", "td", "th"].indexOf(U(r)) >= 0
    }

    function X(r) {
        return ((wt(r) ? r.ownerDocument : r.document) || window.document).documentElement
    }

    function Xt(r) {
        return U(r) === "html" ? r : r.assignedSlot || r.parentNode || (si(r) ? r.host : null) || X(r)
    }

    function qa(r) {
        return !q(r) || rt(r).position === "fixed" ? null : r.offsetParent
    }

    function cn(r) {
        var t = /firefox/i.test(ai()),
            e = /Trident/i.test(ai());
        if (e && q(r)) {
            var i = rt(r);
            if (i.position === "fixed") return null
        }
        var s = Xt(r);
        for (si(s) && (s = s.host); q(s) && ["html", "body"].indexOf(U(s)) < 0;) {
            var a = rt(s);
            if (a.transform !== "none" || a.perspective !== "none" || a.contain === "paint" || ["transform", "perspective"].indexOf(a.willChange) !== -1 || t && a.willChange === "filter" || t && a.filter && a.filter !== "none") return s;
            s = s.parentNode
        }
        return null
    }

    function Tt(r) {
        for (var t = A(r), e = qa(r); e && Fs(e) && rt(e).position === "static";) e = qa(e);
        return e && (U(e) === "html" || U(e) === "body" && rt(e).position === "static") ? t : e || cn(r) || t
    }

    function Ae(r) {
        return ["top", "bottom"].indexOf(r) >= 0 ? "x" : "y"
    }

    function Ee(r, t, e) {
        return Rt(r, Ie(t, e))
    }

    function Wa(r, t, e) {
        var i = Ee(r, t, e);
        return i > e ? e : i
    }

    function Di() {
        return {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }
    }

    function Ni(r) {
        return Object.assign({}, Di(), r)
    }

    function Fi(r, t) {
        return t.reduce(function(e, i) {
            return e[i] = r, e
        }, {})
    }
    var un = function(t, e) {
        return t = typeof t == "function" ? t(Object.assign({}, e.rects, {
            placement: e.placement
        })) : t, Ni(typeof t != "number" ? t : Fi(t, ne))
    };

    function fn(r) {
        var t, e = r.state,
            i = r.name,
            s = r.options,
            a = e.elements.arrow,
            o = e.modifiersData.popperOffsets,
            l = Z(e.placement),
            d = Ae(l),
            u = [j, N].indexOf(l) >= 0,
            c = u ? "height" : "width";
        if (!(!a || !o)) {
            var p = un(s.padding, e),
                g = Le(a),
                v = d === "y" ? z : j,
                y = d === "y" ? F : N,
                b = e.rects.reference[c] + e.rects.reference[d] - o[d] - e.rects.popper[c],
                C = o[d] - e.rects.reference[d],
                k = Tt(a),
                $ = k ? d === "y" ? k.clientHeight || 0 : k.clientWidth || 0 : 0,
                P = b / 2 - C / 2,
                x = p[v],
                T = $ - g[c] - p[y],
                S = $ / 2 - g[c] / 2 + P,
                L = Ee(x, S, T),
                V = d;
            e.modifiersData[i] = (t = {}, t[V] = L, t.centerOffset = L - S, t)
        }
    }

    function pn(r) {
        var t = r.state,
            e = r.options,
            i = e.element,
            s = i === void 0 ? "[data-popper-arrow]" : i;
        s != null && (typeof s == "string" && (s = t.elements.popper.querySelector(s), !s) || Vi(t.elements.popper, s) && (t.elements.arrow = s))
    }
    var Ha = {
        name: "arrow",
        enabled: !0,
        phase: "main",
        fn,
        effect: pn,
        requires: ["popperOffsets"],
        requiresIfExists: ["preventOverflow"]
    };

    function yt(r) {
        return r.split("-")[1]
    }
    var mn = {
        top: "auto",
        right: "auto",
        bottom: "auto",
        left: "auto"
    };

    function gn(r, t) {
        var e = r.x,
            i = r.y,
            s = t.devicePixelRatio || 1;
        return {
            x: Yt(e * s) / s || 0,
            y: Yt(i * s) / s || 0
        }
    }

    function Ua(r) {
        var t, e = r.popper,
            i = r.popperRect,
            s = r.placement,
            a = r.variation,
            o = r.offsets,
            l = r.position,
            d = r.gpuAcceleration,
            u = r.adaptive,
            c = r.roundOffsets,
            p = r.isFixed,
            g = o.x,
            v = g === void 0 ? 0 : g,
            y = o.y,
            b = y === void 0 ? 0 : y,
            C = typeof c == "function" ? c({
                x: v,
                y: b
            }) : {
                x: v,
                y: b
            };
        v = C.x, b = C.y;
        var k = o.hasOwnProperty("x"),
            $ = o.hasOwnProperty("y"),
            P = j,
            x = z,
            T = window;
        if (u) {
            var S = Tt(e),
                L = "clientHeight",
                V = "clientWidth";
            if (S === A(e) && (S = X(e), rt(S).position !== "static" && l === "absolute" && (L = "scrollHeight", V = "scrollWidth")), S = S, s === z || (s === j || s === N) && a === Pe) {
                x = F;
                var D = p && S === T && T.visualViewport ? T.visualViewport.height : S[L];
                b -= D - i.height, b *= d ? 1 : -1
            }
            if (s === j || (s === z || s === F) && a === Pe) {
                P = N;
                var B = p && S === T && T.visualViewport ? T.visualViewport.width : S[V];
                v -= B - i.width, v *= d ? 1 : -1
            }
        }
        var W = Object.assign({
                position: l
            }, u && mn),
            lt = c === !0 ? gn({
                x: v,
                y: b
            }, A(e)) : {
                x: v,
                y: b
            };
        if (v = lt.x, b = lt.y, d) {
            var Y;
            return Object.assign({}, W, (Y = {}, Y[x] = $ ? "0" : "", Y[P] = k ? "0" : "", Y.transform = (T.devicePixelRatio || 1) <= 1 ? "translate(" + v + "px, " + b + "px)" : "translate3d(" + v + "px, " + b + "px, 0)", Y))
        }
        return Object.assign({}, W, (t = {}, t[x] = $ ? b + "px" : "", t[P] = k ? v + "px" : "", t.transform = "", t))
    }

    function vn(r) {
        var t = r.state,
            e = r.options,
            i = e.gpuAcceleration,
            s = i === void 0 ? !0 : i,
            a = e.adaptive,
            o = a === void 0 ? !0 : a,
            l = e.roundOffsets,
            d = l === void 0 ? !0 : l,
            u = {
                placement: Z(t.placement),
                variation: yt(t.placement),
                popper: t.elements.popper,
                popperRect: t.rects.popper,
                gpuAcceleration: s,
                isFixed: t.options.strategy === "fixed"
            };
        t.modifiersData.popperOffsets != null && (t.styles.popper = Object.assign({}, t.styles.popper, Ua(Object.assign({}, u, {
            offsets: t.modifiersData.popperOffsets,
            position: t.options.strategy,
            adaptive: o,
            roundOffsets: d
        })))), t.modifiersData.arrow != null && (t.styles.arrow = Object.assign({}, t.styles.arrow, Ua(Object.assign({}, u, {
            offsets: t.modifiersData.arrow,
            position: "absolute",
            adaptive: !1,
            roundOffsets: d
        })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
            "data-popper-placement": t.placement
        })
    }
    var Za = {
        name: "computeStyles",
        enabled: !0,
        phase: "beforeWrite",
        fn: vn,
        data: {}
    };
    var Ss = {
        passive: !0
    };

    function wn(r) {
        var t = r.state,
            e = r.instance,
            i = r.options,
            s = i.scroll,
            a = s === void 0 ? !0 : s,
            o = i.resize,
            l = o === void 0 ? !0 : o,
            d = A(t.elements.popper),
            u = [].concat(t.scrollParents.reference, t.scrollParents.popper);
        return a && u.forEach(function(c) {
                c.addEventListener("scroll", e.update, Ss)
            }), l && d.addEventListener("resize", e.update, Ss),
            function() {
                a && u.forEach(function(c) {
                    c.removeEventListener("scroll", e.update, Ss)
                }), l && d.removeEventListener("resize", e.update, Ss)
            }
    }
    var Ya = {
        name: "eventListeners",
        enabled: !0,
        phase: "write",
        fn: function() {},
        effect: wn,
        data: {}
    };
    var bn = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };

    function oi(r) {
        return r.replace(/left|right|bottom|top/g, function(t) {
            return bn[t]
        })
    }
    var yn = {
        start: "end",
        end: "start"
    };

    function Ms(r) {
        return r.replace(/start|end/g, function(t) {
            return yn[t]
        })
    }

    function Be(r) {
        var t = A(r),
            e = t.pageXOffset,
            i = t.pageYOffset;
        return {
            scrollLeft: e,
            scrollTop: i
        }
    }

    function Oe(r) {
        return bt(X(r)).left + Be(r).scrollLeft
    }

    function qs(r, t) {
        var e = A(r),
            i = X(r),
            s = e.visualViewport,
            a = i.clientWidth,
            o = i.clientHeight,
            l = 0,
            d = 0;
        if (s) {
            a = s.width, o = s.height;
            var u = ji();
            (u || !u && t === "fixed") && (l = s.offsetLeft, d = s.offsetTop)
        }
        return {
            width: a,
            height: o,
            x: l + Oe(r),
            y: d
        }
    }

    function Ws(r) {
        var t, e = X(r),
            i = Be(r),
            s = (t = r.ownerDocument) == null ? void 0 : t.body,
            a = Rt(e.scrollWidth, e.clientWidth, s ? s.scrollWidth : 0, s ? s.clientWidth : 0),
            o = Rt(e.scrollHeight, e.clientHeight, s ? s.scrollHeight : 0, s ? s.clientHeight : 0),
            l = -i.scrollLeft + Oe(r),
            d = -i.scrollTop;
        return rt(s || e).direction === "rtl" && (l += Rt(e.clientWidth, s ? s.clientWidth : 0) - a), {
            width: a,
            height: o,
            x: l,
            y: d
        }
    }

    function ze(r) {
        var t = rt(r),
            e = t.overflow,
            i = t.overflowX,
            s = t.overflowY;
        return /auto|scroll|overlay|hidden/.test(e + s + i)
    }

    function Rs(r) {
        return ["html", "body", "#document"].indexOf(U(r)) >= 0 ? r.ownerDocument.body : q(r) && ze(r) ? r : Rs(Xt(r))
    }

    function le(r, t) {
        var e;
        t === void 0 && (t = []);
        var i = Rs(r),
            s = i === ((e = r.ownerDocument) == null ? void 0 : e.body),
            a = A(i),
            o = s ? [a].concat(a.visualViewport || [], ze(i) ? i : []) : i,
            l = t.concat(o);
        return s ? l : l.concat(le(Xt(o)))
    }

    function ni(r) {
        return Object.assign({}, r, {
            left: r.x,
            top: r.y,
            right: r.x + r.width,
            bottom: r.y + r.height
        })
    }

    function xn(r, t) {
        var e = bt(r, !1, t === "fixed");
        return e.top = e.top + r.clientTop, e.left = e.left + r.clientLeft, e.bottom = e.top + r.clientHeight, e.right = e.left + r.clientWidth, e.width = r.clientWidth, e.height = r.clientHeight, e.x = e.left, e.y = e.top, e
    }

    function Xa(r, t, e) {
        return t === _s ? ni(qs(r, e)) : wt(t) ? xn(t, e) : ni(Ws(X(r)))
    }

    function Cn(r) {
        var t = le(Xt(r)),
            e = ["absolute", "fixed"].indexOf(rt(r).position) >= 0,
            i = e && q(r) ? Tt(r) : r;
        return wt(i) ? t.filter(function(s) {
            return wt(s) && Vi(s, i) && U(s) !== "body"
        }) : []
    }

    function Hs(r, t, e, i) {
        var s = t === "clippingParents" ? Cn(r) : [].concat(t),
            a = [].concat(s, [e]),
            o = a[0],
            l = a.reduce(function(d, u) {
                var c = Xa(r, u, i);
                return d.top = Rt(c.top, d.top), d.right = Ie(c.right, d.right), d.bottom = Ie(c.bottom, d.bottom), d.left = Rt(c.left, d.left), d
            }, Xa(r, o, i));
        return l.width = l.right - l.left, l.height = l.bottom - l.top, l.x = l.left, l.y = l.top, l
    }

    function qi(r) {
        var t = r.reference,
            e = r.element,
            i = r.placement,
            s = i ? Z(i) : null,
            a = i ? yt(i) : null,
            o = t.x + t.width / 2 - e.width / 2,
            l = t.y + t.height / 2 - e.height / 2,
            d;
        switch (s) {
            case z:
                d = {
                    x: o,
                    y: t.y - e.height
                };
                break;
            case F:
                d = {
                    x: o,
                    y: t.y + t.height
                };
                break;
            case N:
                d = {
                    x: t.x + t.width,
                    y: l
                };
                break;
            case j:
                d = {
                    x: t.x - e.width,
                    y: l
                };
                break;
            default:
                d = {
                    x: t.x,
                    y: t.y
                }
        }
        var u = s ? Ae(s) : null;
        if (u != null) {
            var c = u === "y" ? "height" : "width";
            switch (a) {
                case Zt:
                    d[u] = d[u] - (t[c] / 2 - e[c] / 2);
                    break;
                case Pe:
                    d[u] = d[u] + (t[c] / 2 - e[c] / 2);
                    break;
                default:
            }
        }
        return d
    }

    function $t(r, t) {
        t === void 0 && (t = {});
        var e = t,
            i = e.placement,
            s = i === void 0 ? r.placement : i,
            a = e.strategy,
            o = a === void 0 ? r.strategy : a,
            l = e.boundary,
            d = l === void 0 ? Va : l,
            u = e.rootBoundary,
            c = u === void 0 ? _s : u,
            p = e.elementContext,
            g = p === void 0 ? ri : p,
            v = e.altBoundary,
            y = v === void 0 ? !1 : v,
            b = e.padding,
            C = b === void 0 ? 0 : b,
            k = Ni(typeof C != "number" ? C : Fi(C, ne)),
            $ = g === ri ? Da : ri,
            P = r.rects.popper,
            x = r.elements[y ? $ : g],
            T = Hs(wt(x) ? x : x.contextElement || X(r.elements.popper), d, c, o),
            S = bt(r.elements.reference),
            L = qi({
                reference: S,
                element: P,
                strategy: "absolute",
                placement: s
            }),
            V = ni(Object.assign({}, P, L)),
            D = g === ri ? V : S,
            B = {
                top: T.top - D.top + k.top,
                bottom: D.bottom - T.bottom + k.bottom,
                left: T.left - D.left + k.left,
                right: D.right - T.right + k.right
            },
            W = r.modifiersData.offset;
        if (g === ri && W) {
            var lt = W[s];
            Object.keys(B).forEach(function(Y) {
                var ce = [N, F].indexOf(Y) >= 0 ? 1 : -1,
                    ue = [z, F].indexOf(Y) >= 0 ? "y" : "x";
                B[Y] += lt[ue] * ce
            })
        }
        return B
    }

    function Us(r, t) {
        t === void 0 && (t = {});
        var e = t,
            i = e.placement,
            s = e.boundary,
            a = e.rootBoundary,
            o = e.padding,
            l = e.flipVariations,
            d = e.allowedAutoPlacements,
            u = d === void 0 ? ks : d,
            c = yt(i),
            p = c ? l ? Ns : Ns.filter(function(y) {
                return yt(y) === c
            }) : ne,
            g = p.filter(function(y) {
                return u.indexOf(y) >= 0
            });
        g.length === 0 && (g = p);
        var v = g.reduce(function(y, b) {
            return y[b] = $t(r, {
                placement: b,
                boundary: s,
                rootBoundary: a,
                padding: o
            })[Z(b)], y
        }, {});
        return Object.keys(v).sort(function(y, b) {
            return v[y] - v[b]
        })
    }

    function _n(r) {
        if (Z(r) === Cs) return [];
        var t = oi(r);
        return [Ms(r), t, Ms(t)]
    }

    function kn(r) {
        var t = r.state,
            e = r.options,
            i = r.name;
        if (!t.modifiersData[i].Ds) {
            for (var s = e.mainAxis, a = s === void 0 ? !0 : s, o = e.altAxis, l = o === void 0 ? !0 : o, d = e.fallbackPlacements, u = e.padding, c = e.boundary, p = e.rootBoundary, g = e.altBoundary, v = e.flipVariations, y = v === void 0 ? !0 : v, b = e.allowedAutoPlacements, C = t.options.placement, k = Z(C), $ = k === C, P = d || ($ || !y ? [oi(C)] : _n(C)), x = [C].concat(P).reduce(function(ti, se) {
                    return ti.concat(Z(se) === Cs ? Us(t, {
                        placement: se,
                        boundary: c,
                        rootBoundary: p,
                        padding: u,
                        flipVariations: y,
                        allowedAutoPlacements: b
                    }) : se)
                }, []), T = t.rects.reference, S = t.rects.popper, L = new Map, V = !0, D = x[0], B = 0; B < x.length; B++) {
                var W = x[B],
                    lt = Z(W),
                    Y = yt(W) === Zt,
                    ce = [z, F].indexOf(lt) >= 0,
                    ue = ce ? "width" : "height",
                    dt = $t(t, {
                        placement: W,
                        boundary: c,
                        rootBoundary: p,
                        altBoundary: g,
                        padding: u
                    }),
                    xt = ce ? Y ? N : j : Y ? F : z;
                T[ue] > S[ue] && (xt = oi(xt));
                var fs = oi(xt),
                    fe = [];
                if (a && fe.push(dt[lt] <= 0), l && fe.push(dt[xt] <= 0, dt[fs] <= 0), fe.every(function(ti) {
                        return ti
                    })) {
                    D = W, V = !1;
                    break
                }
                L.set(W, fe)
            }
            if (V)
                for (var ps = y ? 3 : 1, Ls = function(se) {
                        var vi = x.find(function(gs) {
                            var pe = L.get(gs);
                            if (pe) return pe.slice(0, se).every(function(As) {
                                return As
                            })
                        });
                        if (vi) return D = vi, "break"
                    }, gi = ps; gi > 0; gi--) {
                    var ms = Ls(gi);
                    if (ms === "break") break
                }
            t.placement !== D && (t.modifiersData[i].Ds = !0, t.placement = D, t.reset = !0)
        }
    }
    var Ja = {
        name: "flip",
        enabled: !0,
        phase: "main",
        fn: kn,
        requiresIfExists: ["offset"],
        data: {
            Ds: !1
        }
    };

    function Ka(r, t, e) {
        return e === void 0 && (e = {
            x: 0,
            y: 0
        }), {
            top: r.top - t.height - e.y,
            right: r.right - t.width + e.x,
            bottom: r.bottom - t.height + e.y,
            left: r.left - t.width - e.x
        }
    }

    function Ga(r) {
        return [z, N, F, j].some(function(t) {
            return r[t] >= 0
        })
    }

    function Sn(r) {
        var t = r.state,
            e = r.name,
            i = t.rects.reference,
            s = t.rects.popper,
            a = t.modifiersData.preventOverflow,
            o = $t(t, {
                elementContext: "reference"
            }),
            l = $t(t, {
                altBoundary: !0
            }),
            d = Ka(o, i),
            u = Ka(l, s, a),
            c = Ga(d),
            p = Ga(u);
        t.modifiersData[e] = {
            referenceClippingOffsets: d,
            popperEscapeOffsets: u,
            isReferenceHidden: c,
            hasPopperEscaped: p
        }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
            "data-popper-reference-hidden": c,
            "data-popper-escaped": p
        })
    }
    var Qa = {
        name: "hide",
        enabled: !0,
        phase: "main",
        requiresIfExists: ["preventOverflow"],
        fn: Sn
    };

    function Mn(r, t, e) {
        var i = Z(r),
            s = [j, z].indexOf(i) >= 0 ? -1 : 1,
            a = typeof e == "function" ? e(Object.assign({}, t, {
                placement: r
            })) : e,
            o = a[0],
            l = a[1];
        return o = o || 0, l = (l || 0) * s, [j, N].indexOf(i) >= 0 ? {
            x: l,
            y: o
        } : {
            x: o,
            y: l
        }
    }

    function Rn(r) {
        var t = r.state,
            e = r.options,
            i = r.name,
            s = e.offset,
            a = s === void 0 ? [0, 0] : s,
            o = ks.reduce(function(c, p) {
                return c[p] = Mn(p, t.rects, a), c
            }, {}),
            l = o[t.placement],
            d = l.x,
            u = l.y;
        t.modifiersData.popperOffsets != null && (t.modifiersData.popperOffsets.x += d, t.modifiersData.popperOffsets.y += u), t.modifiersData[i] = o
    }
    var to = {
        name: "offset",
        enabled: !0,
        phase: "main",
        requires: ["popperOffsets"],
        fn: Rn
    };

    function Tn(r) {
        var t = r.state,
            e = r.name;
        t.modifiersData[e] = qi({
            reference: t.rects.reference,
            element: t.rects.popper,
            strategy: "absolute",
            placement: t.placement
        })
    }
    var eo = {
        name: "popperOffsets",
        enabled: !0,
        phase: "read",
        fn: Tn,
        data: {}
    };

    function Zs(r) {
        return r === "x" ? "y" : "x"
    }

    function $n(r) {
        var t = r.state,
            e = r.options,
            i = r.name,
            s = e.mainAxis,
            a = s === void 0 ? !0 : s,
            o = e.altAxis,
            l = o === void 0 ? !1 : o,
            d = e.boundary,
            u = e.rootBoundary,
            c = e.altBoundary,
            p = e.padding,
            g = e.tether,
            v = g === void 0 ? !0 : g,
            y = e.tetherOffset,
            b = y === void 0 ? 0 : y,
            C = $t(t, {
                boundary: d,
                rootBoundary: u,
                padding: p,
                altBoundary: c
            }),
            k = Z(t.placement),
            $ = yt(t.placement),
            P = !$,
            x = Ae(k),
            T = Zs(x),
            S = t.modifiersData.popperOffsets,
            L = t.rects.reference,
            V = t.rects.popper,
            D = typeof b == "function" ? b(Object.assign({}, t.rects, {
                placement: t.placement
            })) : b,
            B = typeof D == "number" ? {
                mainAxis: D,
                altAxis: D
            } : Object.assign({
                mainAxis: 0,
                altAxis: 0
            }, D),
            W = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null,
            lt = {
                x: 0,
                y: 0
            };
        if (S) {
            if (a) {
                var Y, ce = x === "y" ? z : j,
                    ue = x === "y" ? F : N,
                    dt = x === "y" ? "height" : "width",
                    xt = S[x],
                    fs = xt + C[ce],
                    fe = xt - C[ue],
                    ps = v ? -V[dt] / 2 : 0,
                    Ls = $ === Zt ? L[dt] : V[dt],
                    gi = $ === Zt ? -V[dt] : -L[dt],
                    ms = t.elements.arrow,
                    ti = v && ms ? Le(ms) : {
                        width: 0,
                        height: 0
                    },
                    se = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : Di(),
                    vi = se[ce],
                    gs = se[ue],
                    pe = Ee(0, L[dt], ti[dt]),
                    As = P ? L[dt] / 2 - ps - pe - vi - B.mainAxis : Ls - pe - vi - B.mainAxis,
                    Oo = P ? -L[dt] / 2 + ps + pe + gs + B.mainAxis : gi + pe + gs + B.mainAxis,
                    Es = t.elements.arrow && Tt(t.elements.arrow),
                    zo = Es ? x === "y" ? Es.clientTop || 0 : Es.clientLeft || 0 : 0,
                    fa = (Y = W == null ? void 0 : W[x]) != null ? Y : 0,
                    jo = xt + As - fa - zo,
                    Vo = xt + Oo - fa,
                    pa = Ee(v ? Ie(fs, jo) : fs, xt, v ? Rt(fe, Vo) : fe);
                S[x] = pa, lt[x] = pa - xt
            }
            if (l) {
                var ma, Do = x === "x" ? z : j,
                    No = x === "x" ? F : N,
                    me = S[T],
                    vs = T === "y" ? "height" : "width",
                    ga = me + C[Do],
                    va = me - C[No],
                    Bs = [z, j].indexOf(k) !== -1,
                    wa = (ma = W == null ? void 0 : W[T]) != null ? ma : 0,
                    ba = Bs ? ga : me - L[vs] - V[vs] - wa + B.altAxis,
                    ya = Bs ? me + L[vs] + V[vs] - wa - B.altAxis : va,
                    xa = v && Bs ? Wa(ba, me, ya) : Ee(v ? ba : ga, me, v ? ya : va);
                S[T] = xa, lt[T] = xa - me
            }
            t.modifiersData[i] = lt
        }
    }
    var io = {
        name: "preventOverflow",
        enabled: !0,
        phase: "main",
        fn: $n,
        requiresIfExists: ["offset"]
    };

    function Ys(r) {
        return {
            scrollLeft: r.scrollLeft,
            scrollTop: r.scrollTop
        }
    }

    function Xs(r) {
        return r === A(r) || !q(r) ? Be(r) : Ys(r)
    }

    function Pn(r) {
        var t = r.getBoundingClientRect(),
            e = Yt(t.width) / r.offsetWidth || 1,
            i = Yt(t.height) / r.offsetHeight || 1;
        return e !== 1 || i !== 1
    }

    function Js(r, t, e) {
        e === void 0 && (e = !1);
        var i = q(t),
            s = q(t) && Pn(t),
            a = X(t),
            o = bt(r, s, e),
            l = {
                scrollLeft: 0,
                scrollTop: 0
            },
            d = {
                x: 0,
                y: 0
            };
        return (i || !i && !e) && ((U(t) !== "body" || ze(a)) && (l = Xs(t)), q(t) ? (d = bt(t, !0), d.x += t.clientLeft, d.y += t.clientTop) : a && (d.x = Oe(a))), {
            x: o.left + l.scrollLeft - d.x,
            y: o.top + l.scrollTop - d.y,
            width: o.width,
            height: o.height
        }
    }

    function In(r) {
        var t = new Map,
            e = new Set,
            i = [];
        r.forEach(function(a) {
            t.set(a.name, a)
        });

        function s(a) {
            e.add(a.name);
            var o = [].concat(a.requires || [], a.requiresIfExists || []);
            o.forEach(function(l) {
                if (!e.has(l)) {
                    var d = t.get(l);
                    d && s(d)
                }
            }), i.push(a)
        }
        return r.forEach(function(a) {
            e.has(a.name) || s(a)
        }), i
    }

    function Ks(r) {
        var t = In(r);
        return Na.reduce(function(e, i) {
            return e.concat(t.filter(function(s) {
                return s.phase === i
            }))
        }, [])
    }

    function Gs(r) {
        var t;
        return function() {
            return t || (t = new Promise(function(e) {
                Promise.resolve().then(function() {
                    t = void 0, e(r())
                })
            })), t
        }
    }

    function Qs(r) {
        var t = r.reduce(function(e, i) {
            var s = e[i.name];
            return e[i.name] = s ? Object.assign({}, s, i, {
                options: Object.assign({}, s.options, i.options),
                data: Object.assign({}, s.data, i.data)
            }) : i, e
        }, {});
        return Object.keys(t).map(function(e) {
            return t[e]
        })
    }
    var ro = {
        placement: "bottom",
        modifiers: [],
        strategy: "absolute"
    };

    function so() {
        for (var r = arguments.length, t = new Array(r), e = 0; e < r; e++) t[e] = arguments[e];
        return !t.some(function(i) {
            return !(i && typeof i.getBoundingClientRect == "function")
        })
    }

    function ao(r) {
        r === void 0 && (r = {});
        var t = r,
            e = t.defaultModifiers,
            i = e === void 0 ? [] : e,
            s = t.defaultOptions,
            a = s === void 0 ? ro : s;
        return function(l, d, u) {
            u === void 0 && (u = a);
            var c = {
                    placement: "bottom",
                    orderedModifiers: [],
                    options: Object.assign({}, ro, a),
                    modifiersData: {},
                    elements: {
                        reference: l,
                        popper: d
                    },
                    attributes: {},
                    styles: {}
                },
                p = [],
                g = !1,
                v = {
                    state: c,
                    setOptions: function(k) {
                        var $ = typeof k == "function" ? k(c.options) : k;
                        b(), c.options = Object.assign({}, a, c.options, $), c.scrollParents = {
                            reference: wt(l) ? le(l) : l.contextElement ? le(l.contextElement) : [],
                            popper: le(d)
                        };
                        var P = Ks(Qs([].concat(i, c.options.modifiers)));
                        return c.orderedModifiers = P.filter(function(x) {
                            return x.enabled
                        }), y(), v.update()
                    },
                    forceUpdate: function() {
                        if (!g) {
                            var k = c.elements,
                                $ = k.reference,
                                P = k.popper;
                            if (so($, P)) {
                                c.rects = {
                                    reference: Js($, Tt(P), c.options.strategy === "fixed"),
                                    popper: Le(P)
                                }, c.reset = !1, c.placement = c.options.placement, c.orderedModifiers.forEach(function(B) {
                                    return c.modifiersData[B.name] = Object.assign({}, B.data)
                                });
                                for (var x = 0; x < c.orderedModifiers.length; x++) {
                                    if (c.reset === !0) {
                                        c.reset = !1, x = -1;
                                        continue
                                    }
                                    var T = c.orderedModifiers[x],
                                        S = T.fn,
                                        L = T.options,
                                        V = L === void 0 ? {} : L,
                                        D = T.name;
                                    typeof S == "function" && (c = S({
                                        state: c,
                                        options: V,
                                        name: D,
                                        instance: v
                                    }) || c)
                                }
                            }
                        }
                    },
                    update: Gs(function() {
                        return new Promise(function(C) {
                            v.forceUpdate(), C(c)
                        })
                    }),
                    destroy: function() {
                        b(), g = !0
                    }
                };
            if (!so(l, d)) return v;
            v.setOptions(u).then(function(C) {
                !g && u.onFirstUpdate && u.onFirstUpdate(C)
            });

            function y() {
                c.orderedModifiers.forEach(function(C) {
                    var k = C.name,
                        $ = C.options,
                        P = $ === void 0 ? {} : $,
                        x = C.effect;
                    if (typeof x == "function") {
                        var T = x({
                                state: c,
                                name: k,
                                instance: v,
                                options: P
                            }),
                            S = function() {};
                        p.push(T || S)
                    }
                })
            }

            function b() {
                p.forEach(function(C) {
                    return C()
                }), p = []
            }
            return v
        }
    }
    var Ln = [Ya, eo, Za, Fa, to, Ja, io, Ha, Qa],
        ta = ao({
            defaultModifiers: Ln
        });
    var J = class extends qt {
        constructor(t) {
            super(t), this.delay = n({
                show: 500,
                hide: 100
            }, this.e.delay || {}), this.e.target && this.setTarget(this.e.target)
        }
        setTarget(t) {
            this.target = t, this.target instanceof f && (this.target = this.target.el), this.target.addEventListener("mouseenter", () => this.Bn()), this.target.addEventListener("mouseleave", () => this.On()), this.target.addEventListener("focus", () => this.zn()), this.target.addEventListener("blur", () => this.jn());
            let e = this.target.querySelector("title");
            !this.content && (this.target.getAttribute("title") || e) && (this.content = this.target.getAttribute("title") || e.innerHTML, this.target.setAttribute("data-title", this.content), this.target.removeAttribute("title")), e && e.remove()
        }
        get He() {
            return this.Ns || this.Fs || this.qs
        }
        zn() {
            this.qs = !0, this.qi()
        }
        jn() {
            this.qs = !1, this.Wi()
        }
        Bn() {
            this.Ns = !0, this.qi()
        }
        On() {
            this.Ns = !1, this.Wi()
        }
        Vn() {
            this.Fs = !0, this.qi()
        }
        Dn() {
            this.Fs = !1, this.Wi()
        }
        qi() {
            if (this.he && (clearTimeout(this.he), delete this.he), !!this.He) {
                if (this.delay.show === 0) return this.show();
                this.ce || (this.ce = setTimeout(() => {
                    delete this.ce, this.He && this.show()
                }, this.delay.show))
            }
        }
        Wi() {
            if (this.ce && (clearTimeout(this.ce), delete this.ce), !this.He) {
                if (this.delay.hide === 0) return this.hide();
                this.he || (this.he = setTimeout(() => {
                    delete this.he, this.He || this.hide()
                }, this.delay.hide))
            }
        }
        r() {
            super.r(), this.el.addEventListener("mouseenter", () => this.Vn()), this.el.addEventListener("mouseleave", () => this.Dn())
        }
        kt() {
            typeof this.content == "string" ? this.Ts.innerHTML = this.content : super.kt()
        }
        show(t) {
            super.show(t), this.popper = this.popper || ta(this.target, this.el), this.popper.update()
        }
        get s() {
            return `<div class="fera fera-tooltip" role="tooltip">
    <div class="fera-tooltip-content" data-fera-content></div>
    <div class="fera-tooltip-arrow" data-popper-arrow></div>
</div>`
        }
    };
    var Jt = class extends f {
        r() {
            super.r(), this.Nn = this.t("Real customer, verified by Fera.ai"), this.tip = new J({
                app: this.app,
                target: this,
                content: this.Nn
            })
        }
        get s() {
            return `<svg class="fera-verification-icon" height="${this.size||16}" width="${this.size||16}" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
  <title>${this.t("Fera.ai customer verification icon.")}</title>
  <rect class="fera-verification-icon-stroke" width="16" height="16" rx="8" fill="white"/>
  <path class="fera-verification-icon-bg" fill-rule="evenodd" clip-rule="evenodd" d="M14.3169 9.64885L13.9731 9.99262C13.7546 10.2113 13.6318 10.5079 13.6317 10.8171V11.3C13.6317 11.9189 13.3859 12.5123 12.9483 12.9499C12.5107 13.3875 11.9172 13.6333 11.2984 13.6333H10.8154C10.5062 13.6334 10.2097 13.7562 9.99101 13.9748L9.64724 14.3185C9.20974 14.7555 8.6167 15.0009 7.99838 15.0009C7.38006 15.0009 6.78702 14.7555 6.34953 14.3185L6.00576 13.9748C5.78705 13.7562 5.49053 13.6334 5.18133 13.6333H4.69989C4.08107 13.6333 3.48759 13.3875 3.05001 12.9499C2.61244 12.5123 2.36661 11.9189 2.36661 11.3V10.8171C2.36654 10.5079 2.24374 10.2113 2.02517 9.99262L1.6814 9.64885C1.24445 9.21136 0.999023 8.61832 0.999023 8C0.999023 7.38168 1.24445 6.78864 1.6814 6.35114L2.02517 6.00737C2.24374 5.78867 2.36654 5.49214 2.36661 5.18295V4.69996C2.36661 4.08113 2.61244 3.48765 3.05001 3.05007C3.48759 2.6125 4.08107 2.36667 4.69989 2.36667H5.18288C5.49208 2.3666 5.78861 2.2438 6.00731 2.02523L6.35108 1.68146C6.78857 1.24451 7.38161 0.999084 7.99994 0.999084C8.61826 0.999084 9.2113 1.24451 9.64879 1.68146L9.99256 2.02523C10.2113 2.2438 10.5078 2.3666 10.817 2.36667H11.3C11.9188 2.36667 12.5123 2.6125 12.9499 3.05007C13.3874 3.48765 13.6333 4.08113 13.6333 4.69996V5.18295C13.6333 5.49214 13.7561 5.78867 13.9747 6.00737L14.3185 6.35114C14.7552 6.78884 15.0004 7.382 15.0001 8.00032C14.9998 8.61864 14.7541 9.21157 14.3169 9.64885Z" fill="#171717"/>
  <path class="fera-verification-icon-check" fill-rule="evenodd" clip-rule="evenodd" d="M5.14457 8.51451C5.01504 8.37549 4.94452 8.19163 4.94787 8.00165C4.95122 7.81167 5.02818 7.6304 5.16254 7.49605C5.2969 7.36169 5.47816 7.28473 5.66814 7.28138C5.85812 7.27802 6.04198 7.34854 6.181 7.47808L6.18483 7.48165L7.22203 8.51827L9.81856 5.92249C9.95757 5.79295 10.1415 5.7225 10.3315 5.72585C10.5215 5.7292 10.7027 5.80617 10.8371 5.94052C10.9714 6.07488 11.0484 6.25614 11.0518 6.44612C11.0551 6.6361 10.9846 6.81997 10.8551 6.95898L10.8514 6.96286L7.74075 10.0734C7.67285 10.1418 7.59182 10.1963 7.50282 10.2332C7.41383 10.2701 7.3184 10.2891 7.22205 10.2889C7.1257 10.2891 7.03027 10.2701 6.94127 10.2332C6.85227 10.1963 6.77149 10.142 6.70359 10.0737L5.14457 8.51451Z" fill="white"/>
</svg>`
        }
    };
    var Kt = class extends f {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.iconUrl = this.determineIconUrl(), this.verificationIcon = new Jt({
                app: this.app,
                onClick: this.e.onVerificationClick
            })
        }
        static get STANDARD_SOURCES() {
            return ["amazon", "etsy", "facebook", "google", "trustpilot", "shopify", "g2", "bigcommerce", "magento", "wix", "walmart", "yelp", "capterra"]
        }
        get hasFlare() {
            return !!this.customer.channelCode && (!this.customer.fromStoreChannel || this.e.showStoreSource)
        }
        get showVerified() {
            return this.customer.is("verified") && (!this.hasFlare || !this.e.showStoreSource)
        }
        r() {
            super.r(), this.Ws = this.o("[data-fera-source-icon]"), this.Ws && (this.ec = new J({
                app: this.app,
                target: this.Ws
            }))
        }
        determineIconUrl() {
            return this.customer.isFromSupplier ? this.B("fera/components/customer/flare/sources/supplier.svg") : this.customer.channelCode ? this.constructor.STANDARD_SOURCES.includes(this.customer.channel.get("code")) ? this.B(`fera/components/customer/flare/sources/${this.customer.channel.get("code")}.svg`) : this.customer.channel.get("icon_url", this.B("fera/components/customer/flare/sources/other.svg")) : ""
        }
        get Fn() {
            return this.t("{{ channel.name }} icon", {
                channel: {
                    name: this.customer.channel.get("name")
                }
            })
        }
        get Hs() {
            return this.customer.channel.get("description", this.t("Customer originally from another platform."))
        }
        get qn() {
            return `<img data-fera-customer-channel="${this.customer.channel.code}" class="fera-customer-flare-icon fera-customer-flare-icon--channel" src="${this.iconUrl}" data-fera-source-icon
       alt="${this.Fn}" width="16" height="16" title="${this.Hs}">`
        }
        get Wn() {
            return !this.customer.is("from_supplier") && this.iconUrl && this.customer.channel.get("url")
        }
        get Us() {
            return this.customer.is("from_supplier") ? `<svg data-fera-customer-channel="supplier" class="fera-customer-flare-icon fera-customer-flare-icon--supplier" width="16" height="16" viewBox="0 0 21 20"
     fill="none" xmlns="http://www.w3.org/2000/svg" data-fera-source-icon>
    <title>${this.t("Customer originally from merchant's supplier.")}</title>
    <g clip-path="url(#clip0_3671_552818)">
        <path d="M11.1565 0.131415C10.7228 -0.0438603 10.2398 -0.043803 9.80612 0.131576L1.70845 3.40605C1.4544 3.50878 1.45043 3.87402 1.70219 3.98247L4.16888 5.04501L11.8265 1.95075C12.0416 1.86381 12.2811 1.86313 12.4967 1.94883L14.6268 2.79551C14.7294 2.83626 14.7309 2.98366 14.6293 3.02665L6.98763 6.2592L10.3625 7.71295C10.4385 7.74566 10.5241 7.74567 10.6001 7.71298L19.2663 3.9825C19.5182 3.87409 19.5142 3.50872 19.2601 3.40603L11.1565 0.131415Z"
              fill="black"/>
        <path d="M0.5 6.14381V15.1122C0.5 15.6077 0.787986 16.0561 1.23341 16.2542L9.66189 20.0013V10.0212C9.66189 9.77057 9.51458 9.54434 9.28805 9.44711L6.30253 8.16556V11.9013L4.7342 9.5749C4.67775 9.49116 4.55905 9.4841 4.49344 9.56059L3.5542 10.6555L3.55397 6.98573L0.923875 5.85675C0.722582 5.77035 0.5 5.92108 0.5 6.14381Z"
              fill="black"/>
        <path fill-rule="evenodd" clip-rule="evenodd"
              d="M20.4978 15.1122V6.14381C20.4978 5.92108 20.2752 5.77035 20.074 5.85675L11.7098 9.44711C11.4832 9.54434 11.3359 9.77057 11.3359 10.0212V20.0013L19.7644 16.2542C20.2098 16.0561 20.4978 15.6077 20.4978 15.1122Z"
              fill="black"/>
    </g>
    <defs>
        <clipPath id="clip0_3671_552818"><rect width="20" height="20" fill="white" transform="translate(0.5)"/></clipPath>
    </defs>
</svg>` : this.iconUrl ? this.qn : this.customer.channel ? `<svg data-fera-customer-channel="${this.customer.channel.code}" class="fera-customer-flare-icon fera-customer-flare-icon--channel fera-customer-flare-icon--other" width="16"
     height="16" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg" data-fera-source-icon>
    <title>${this.Hs}</title>
    <g clip-path="url(#clip0_3671_552828)">
        <path d="M14.0713 6.12903C13.4865 2.52823 12.1072 0 10.502 0C8.89685 0 7.51754 2.52823 6.93275 6.12903H14.0713ZM6.63027 10C6.63027 10.8952 6.67867 11.754 6.76336 12.5806H14.2366C14.3213 11.754 14.3697 10.8952 14.3697 10C14.3697 9.10484 14.3213 8.24597 14.2366 7.41936H6.76336C6.67867 8.24597 6.63027 9.10484 6.63027 10ZM19.7257 6.12903C18.5722 3.39113 16.237 1.27419 13.3534 0.419355C14.3375 1.78226 15.015 3.83468 15.3699 6.12903H19.7257ZM7.6466 0.419355C4.76699 1.27419 2.42781 3.39113 1.27838 6.12903H5.6341C5.98498 3.83468 6.66253 1.78226 7.6466 0.419355V0.419355ZM20.1572 7.41936H15.5313C15.616 8.26613 15.6643 9.13307 15.6643 10C15.6643 10.8669 15.616 11.7339 15.5313 12.5806H20.1532C20.375 11.754 20.5 10.8952 20.5 10C20.5 9.10484 20.375 8.24597 20.1572 7.41936ZM5.33969 10C5.33969 9.13307 5.38808 8.26613 5.47278 7.41936H0.846844C0.629058 8.24597 0.5 9.10484 0.5 10C0.5 10.8952 0.629058 11.754 0.846844 12.5806H5.46874C5.38808 11.7339 5.33969 10.8669 5.33969 10V10ZM6.93275 13.871C7.51754 17.4718 8.89685 20 10.502 20C12.1072 20 13.4865 17.4718 14.0713 13.871H6.93275ZM13.3574 19.5806C16.237 18.7258 18.5762 16.6089 19.7297 13.871H15.374C15.0191 16.1653 14.3415 18.2177 13.3574 19.5806ZM1.27838 13.871C2.43184 16.6089 4.76699 18.7258 7.65064 19.5806C6.66657 18.2177 5.98901 16.1653 5.6341 13.871H1.27838V13.871Z"
              fill="black"/>
    </g>
    <defs>
        <clipPath id="clip0_3671_552828"><rect width="20" height="20" fill="white" transform="translate(0.5)"/></clipPath>
    </defs>
</svg>` : ""
        }
        get Hn() {
            return this.showVerified ? '<svg class="fera-customer-flare-icon fera-customer-flare-icon--verification" data-fera-component="verificationIcon"></svg>' : this.hasFlare ? this.Wn ? `<a href="${this.customer.channel.url||"#"}" class="fera-customer-flare-icon-container" target="_blank" rel="noopener">${this.Us}</a>` : `<span class="fera-customer-flare-icon-container">${this.Us}</span>` : ""
        }
        get s() {
            return `<div class="fera-customer-flare">${this.Hn}</div>`
        }
    };
    var je = class extends f {
        constructor(t) {
            super(t), this.flare = new Kt({
                app: this.app,
                customer: this.e.customer
            })
        }
        get Hi() {
            return !(!this.e.showCustomerOnClick || this.e.customer.is("anonymous"))
        }
        r() {
            super.r(), this.flare.toggleVisible(this.e.flareVisible !== !1), this.Un = this.o(".fera-customer-display-name-text"), this.Zs = this.o("[data-fera-name-text]"), this.e.flareVisible && this.Un.classList.add("fera-customer-display-name-text--with-flare"), this.Hi && (this.Zs.classList.add("fera--clickable"), this.Zs.addEventListener("click", t => {
                t.preventDefault(), this.app.showCustomer(this.e.customer)
            }))
        }
        get s() {
            return `<div class="fera-customer-display-name">
    <div class="fera-customer-display-name-text" itemprop="author" itemscope itemtype="https://schema.org/Person">
        <span itemprop="name" data-fera-name-text>${this.e.customer.get("display_name")}</span>
    </div>
    <div data-fera-component="flare"></div>
</div>`
        }
    };
    var Pt = class extends f {
        constructor(t) {
            super(t), this.review = this.e.review, this.customer = this.review.customer, this.product = this.review.product, this.widgetModel = this.e.widgetModel
        }
        get i() {
            return h(n({}, super.i), {
                review: this.review,
                widgetModel: this.widgetModel,
                includeSeoAttributes: this.e.includeSeoAttributes,
                subject: this.e.subject,
                forProduct: this.e.forProduct,
                options: this.options
            })
        }
        get options() {
            return n(n({}, this.L), this.e.options || (this.widgetModel ? this.widgetModel.getData() : {}))
        }
        get L() {
            return this.review.forStore ? et.defaultTypeSettings : tt.defaultTypeSettings
        }
    };
    var ea = ["left", "right", "up", "down"],
        An = {
            left: "fera-icon-caret--left",
            right: "fera-icon-caret--right",
            up: "fera-icon-caret--up",
            down: "fera-icon-caret--down"
        },
        zt = class extends f {
            constructor(t) {
                super(t), this.direction = ea.includes(this.e.direction) ? this.e.direction : "right"
            }
            l() {
                super.l(), this.Ys()
            }
            changeCaretDirection(t) {
                if (!ea.includes(t)) {
                    console.warn(`Invalid direction: ${t}`);
                    return
                }
                this.direction = t, this.Ys()
            }
            Ys() {
                ea.forEach(t => {
                    this.toggleClass(An[t], this.direction === t)
                })
            }
            get s() {
                return `<svg class="fera-icon fera-icon-caret" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9 6.75L14.25 12L9 17.25" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`
            }
        };
    var Ve = class extends Pt {
        constructor(t) {
            super(t), this.addClass("fera-review-product"), this.caret = new zt({
                app: this.app
            }), this.productName = new Ut({
                app: this.app,
                content: this.review.product.get("name"),
                expandOn: "hover"
            })
        }
        l() {
            super.l(), this.el && this.el.dataset.maxNameLength && (this.productName.maxLength = this.el.dataset.maxNameLength || 30)
        }
        r() {
            super.r(), this.Ue = this.o("[data-fera-product-img]"), this.Ue && this.Ue.addEventListener("error", () => this.addClass("fera-review-product--noImg")), this.toggleClass("fera-review-product--noImg", !this.Ue || !this.Ue.src), this.toggleClass("fera-review-product--noLink", !this.review.product || !this.review.product.isLinkable), this.app.config.designMode && this.q("[data-fera-design-disabled]", t => {
                new J(h(n({}, this.i), {
                    target: t,
                    content: this.t("Disabled in design mode")
                }))
            })
        }
        get Zn() {
            return this.product.id ? `data-fera-product="${this.product.id}"` : this.product.get("external_id") ? `data-product="${this.product.get("external_id")}"` : ""
        }
        get ue() {
            return `<div class="fera-review-product-image-container" data-fera-product-img-container><img src="${this.product.smallThumbnailUrl}"
                    alt="${this.t("Image of product reviewed")}" loading="lazy" data-fera-product-img class="fera-review-product-img"></div>`
        }
        get Ui() {
            return `<div class="fera-review-product-name-prefix">${this.t("Product")}:&nbsp;</div><!-- added to avoid extra spacing
            --><div class="fera-review-product-name" data-fera-component="productName">${this.product.get("name","")}</div>`
        }
        get Xs() {
            return this.app.config.designMode ? "#" : this.review.product.url
        }
        get Js() {
            return `<a href="${this.Xs}" class="fera-review-product-link" ${this.app.config.designMode?"data-fera-design-disabled":""}>
            ${this.ue}
            <div class="fera-review-product-text-container">
                <div class="fera-review-product-link-caption">${this.t("View product")}</div>${this.Ui}
            </div>
            <div class="fera-review-product-caret-container" data-fera-component-container="caret"></div>
        </a>`
        }
        get Yn() {
            return `${this.ue}
<div class="fera-review-product-text-container">${this.Ui}</div>`
        }
        get s() {
            return `<div ${this.Zn}>${this.product.isLinkable?this.Js:this.Yn}</div>`
        }
    };
    var Wi = class extends Pt {
        constructor(t) {
            super(t), this.timeAgo = new Ot({
                app: this.app,
                review: this.review,
                widgetModel: this.widgetModel,
                time: this.review.get("created_at")
            })
        }
        get s() {
            return `<div class="fera-review-date">
    <meta itemprop="datePublished" content="${this.review.get("created_at")}">
    <span class="fera-review-date-val" data-fera-component="timeAgo" data-value="${this.review.get("created_at")}">${this.review.get("created_at")}</span>
</div>`
        }
    };
    var Hi = class extends f {
        get s() {
            return `<div class="fera-review-heading" itemprop="name">${this.e.review.get("heading","")}</div>`
        }
    };
    var Ui = class extends Pt {
        constructor(t) {
            super(t), this.media = this.e.media, this.thumbnails = this.media.map(e => this.Xn(e)), this.addChildren(this.thumbnails), this.lightbox = new pt({
                app: this.app,
                media: this.media,
                showReview: !1
            })
        }
        Xn(t) {
            let e = h(n({}, this.i), {
                    media: t
                }),
                i = t.isVideo ? new ut(e) : new ft(e);
            return i.on("click", () => this.lightbox.show(t, i)), i
        }
        get i() {
            return h(n({}, super.i), {
                size: "small",
                lazyLoad: !!this.e.lazyLoad
            })
        }
        get s() {
            return '<div class="fera-review-media-thumbnails"></div>'
        }
    };
    var Zi = class extends f {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.flare = new Kt({
                app: this.app,
                customer: this.e.customer,
                onVerificationClick: () => this.showCustomer()
            })
        }
        get Hi() {
            return !(!this.e.showCustomerOnClick || this.customer.is("anonymous"))
        }
        r() {
            super.r(), this.fe = this.o("img"), this.fe.addEventListener("error", () => {
                this.fe.classList.add("fera-img--error"), this.fe.src != this.customer.get("default_avatar_url") ? this.fe.src = this.customer.get("default_avatar_url") : this.fe.src = "https://cdn.fera.ai/img/shoppers/placeholder2.png"
            }), this.flare.toggleVisible(!!this.e.flareVisible), this.Ks = this.o("[data-fera-avatar-container]"), this.Hi && (this.Ks.classList.add("fera--clickable"), this.Ks.addEventListener("click", t => {
                t.preventDefault(), this.showCustomer()
            }))
        }
        showCustomer() {
            this.app.showCustomer(this.customer)
        }
        get Jn() {
            return this.t("{{ customer.display_name }}'s avatar image.", {
                customer: {
                    display_name: this.customer.get("display_name", this.t("Anonymous"))
                }
            })
        }
        get Kn() {
            return this.customer && this.customer.smallAvatarUrl ? this.customer.smallAvatarUrl : "https://cdn.fera.ai/img/shoppers/placeholder2.png"
        }
        get ue() {
            return `<img ${this.e.lazyLoad?"data-":""}src="${this.Kn}"
        height="40" width="40" alt="${this.Jn}" loading="lazy">`
        }
        get s() {
            return `<div class="fera-customer-avatar">
    <div class="fera-customer-avatar-container" data-fera-avatar-container>${this.ue}</div>
    <div data-fera-component="flare"></div>
</div>`
        }
    };
    var De = class extends f {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.avatar = new Zi(h(n({}, this.i), {
                flareVisible: !!this.e.flareOnAvatar
            })), this.displayName = new je(h(n({}, this.i), {
                flareVisible: this.Gn
            }))
        }
        get i() {
            return h(n({}, super.i), {
                customer: this.customer,
                showCustomerOnClick: this.e.showCustomerOnClick !== !1,
                lazyLoad: !!this.e.lazyLoad
            })
        }
        get avatarVisible() {
            return this.e.avatarVisible !== !1
        }
        get Gn() {
            return !this.e.flareOnAvatar || !this.avatarVisible
        }
        get locationVisible() {
            return this.e.locationVisible !== !1 && this.customer.get("display_location")
        }
        get s() {
            return `<div class="fera-customer-display">
    ${this.avatarVisible?'<div data-fera-component="avatar" class="fera-customer-display-avatar"></div>':""}
    <div class="fera-customer-display-text">
        <div data-fera-component="displayName"></div>
        ${this.locationVisible?`<div class="fera-customer-display-location">${this.customer.get("display_location")}</div>`:""}
    </div>
</div>`
        }
    };
    var mt = class extends Pt {
        constructor(t) {
            super(t), this.addClass(`fera-review fera-review--for-${this.review.get("subject")}`), this.date = new Wi(n({}, this.i)), this.stars = new Ht(h(n({}, this.i), {
                value: this.review.get("rating")
            })), this.body = new zi(this.pe), this.heading = new Hi(n({}, this.i)), this.media = new Ui(h(n({}, this.i), {
                review: this.review,
                media: this.review.media
            })), this.customerWithAvatar = new De(h(n({}, this.Gs), {
                flareOnAvatar: !0,
                locationVisible: this.options.customer_locations_visible,
                avatarVisible: this.options.customer_avatars_visible,
                showCustomerOnClick: this.e.showCustomerOnClick !== !1
            })), this.customerName = new je(h(n({}, this.Gs), {
                flareVisible: !0,
                showCustomerOnClick: this.e.showCustomerOnClick !== !1
            })), this.review.product && (this.product = new Ve(n({}, this.i))), this.review.storeReply && (this.reply = new Oi(h(n({}, this.i), {
                initialState: this.review.rating && this.review.rating < 4 ? "expanded" : "collapsed"
            })))
        }
        get pe() {
            return h(n({}, this.i), {
                content: this.review.body,
                onShowMore: this.e.openModalOnClick ? () => this.app.showReview(this.review) : null
            })
        }
        get i() {
            return h(n({}, super.i), {
                on: {
                    resize: () => this.trigger("resize")
                }
            })
        }
        get Gs() {
            return h(n({}, this.i), {
                customer: this.review.customer
            })
        }
        get Qn() {
            return typeof this.e.showProduct == "boolean" ? this.e.showProduct && !!this.review.hasDisplayableProduct : this.options.products_visible === !1 || this.options.product_visible === !1 ? !1 : !!this.review.hasDisplayableProduct
        }
        l() {
            super.l(), this.review.get("heading") && this.review.body == this.review.get("heading", "") && this.heading.hide()
        }
        r() {
            super.r(), this.e.openModalOnClick && (this.tl(), this.on("press", t => {
                this.product && this.product.contains(t.target) && this.review.product && this.review.product.isLinkable || this.Qs && this.media && this.media.contains(t.target) || this.e.showCustomerOnClick !== !1 && (this.customerName && this.customerName.contains(t.target) || this.customerWithAvatar.contains(t.target)) || (t.preventDefault(), this.app.showReview(this.review))
            }))
        }
        tl() {
            this.el.addEventListener("click", t => setTimeout(() => {
                this.clickListenersDisabled || this.trigger("press", t)
            }, 1))
        }
        get Ze() {
            return !this.options.summaries_visible || !this.review.get("heading") ? "" : '<div data-fera-component="heading"></div>'
        }
        ot(t = "72xs500") {
            return this.review.body ? `<div data-fera-component="body" itemprop="description" data-max-length="${t}">${this.review.bodyHtml}</div>` : ""
        }
        Vt(t = "100") {
            return !this.options.store_replies_visible || !this.review.storeReply ? "" : `<div data-fera-component="reply" data-max-length="${t}"></div>`
        }
        Dt(t = "15") {
            return this.Qn ? `<div data-fera-component="product" data-max-name-length="${t}"></div>` : ""
        }
        get me() {
            return '<div data-fera-component="customerWithAvatar"></div>'
        }
        get Ye() {
            return `<div class="fera-review-ratingAndDate">${this.il}${this.rl}</div>`
        }
        get rl() {
            return this.options.dates_visible ? '<div data-fera-component="date"></div>' : ""
        }
        get il() {
            return !this.options.ratings_visible || !this.review.get("rating") ? "" : '<div class="fera-review-rating" data-fera-component="stars" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating"></div>'
        }
        get Xe() {
            return this.Qs ? '<div data-fera-component="media"></div>' : ""
        }
        get Qs() {
            return this.options.customer_media_visible !== !1 && this.review.media && this.review.media.length > 0
        }
        get Je() {
            return `data-id="${this.review.id}" itemprop="review" itemscope itemtype="https://schema.org/Review"`
        }
        get s() {
            return `<div ${this.Je}>
    <div class="fera-review-content">
        ${this.Ye}
        ${this.Ze}
        ${this.ot()}
        ${this.Xe}
        ${this.me}
        ${this.Vt()}
    </div>

    ${this.Dt()}
</div>`
        }
    };
    var Yi = class extends mt {
        constructor(t) {
            super(n({
                showProduct: !1,
                showCustomerOnClick: !1
            }, t)), this.body = new f(this.pe), this.addClass("fera-media-lightbox-review")
        }
        get options() {
            return h(n({}, super.options), {
                summaries_visible: !1,
                store_replies_visible: !1,
                customer_avatars_visible: !1,
                customer_media_visible: !1,
                customer_locations_visible: !1,
                product_visible: !1
            })
        }
        ot() {
            return this.review.get("body") ? `<div class="fera-review-body">${this.review.get("body","").toString().substring(0,300)}</div>` : ""
        }
    };
    var pt = class extends Li {
        constructor(t) {
            super(t), this.addClass("fera-media-lightbox-gallery"), this.media = this.e.media, this.collection = this.e.collection, this.carousel = this.content = new this.sl({
                app: this.app,
                media: this.media,
                collection: this.collection
            }), this.carousel.on("media.show", () => this.ta()), this.al()
        }
        get sl() {
            return Bi
        }
        al() {
            this.carousel.on("media.click", () => {
                this.ol(), this.Ke = new Date
            }), this.carousel.onElement("mousemove", () => this.nl()), this.carousel.onElement("mouseleave", () => {
                this.Zi(), this.ea = new Date
            }), this.ll = I(() => {
                this.Ke && new Date().getTime() - this.Ke.getTime() < 5e3 || this.ea && new Date().getTime() - this.ea.getTime() < 3e3 || this.ia()
            }, 2e3), this.nl = I(() => {
                this.Ke && new Date().getTime() - this.Ke.getTime() < 100 || this.Zi(!0)
            }, 10)
        }
        show(t = null) {
            t && this.carousel.showMedia(t), this.ta(), super.show()
        }
        ta() {
            if (!this.carousel || !this.carousel.currentItem) return;
            let t = this.carousel.currentItem.media;
            this.currentMedia !== t && (this.currentMedia && t && this.currentMedia.id == t.id || (this.currentMedia = t, this.dl()))
        }
        hl() {
            this.currentReview && this.ll()
        }
        ol() {
            this.currentReview && this.toggleClass("fera-media-lightbox-gallery--review-hidden")
        }
        ia() {
            this.currentReview && this.addClass("fera-media-lightbox-gallery--review-hidden")
        }
        Zi(t = !1) {
            this.currentReview && (this.removeClass("fera-media-lightbox-gallery--review-hidden"), t && this.hl())
        }
        dl() {
            return m(this, null, function*() {
                if (this.e.showReview !== !1) {
                    if (!this.currentReview || !this.currentMedia || this.currentMedia.get("review_id") != this.currentReview.id) {
                        this.ia();
                        let t = yield this.currentMedia.loadAssociatedReviewFromServer();
                        if (this.currentReview === t || this.currentReview && t && this.currentReview.id == t.id) return;
                        this.currentReview = t, this.currentReview ? this.cl() : this.reviewDisplay && (this.reviewDisplay.destroy(), this.reviewDisplay = null)
                    }
                    this.currentReview && (this.ra && clearTimeout(this.ra), this.ra = setTimeout(() => this.Zi(!0), 1e3))
                }
            })
        }
        cl() {
            this.reviewDisplay && this.reviewDisplay.destroy(), this.reviewDisplay = new Yi({
                app: this.app,
                review: this.currentReview,
                openModalOnClick: !0
            }), this.append(this.reviewDisplay)
        }
        zi(t) {
            super.zi(t), t.code === "ArrowLeft" && this.carousel.showPrev(), t.code === "ArrowRight" && this.carousel.showNext()
        }
    };
    var Xi = class extends f {
        get s() {
            return `<img class="fera-icon fera-icon-info" width="16" height="16" src="${this.B("fera/components/icons/minus/image.svg")}" alt="${this.t("minus")}"/>`
        }
    };
    var li = class extends f {
        constructor(t) {
            super(t), this.mt = this.e.file;
            let e = this.mt.mediaType === "video" ? kt : St;
            this.sa = new e({
                url: this.mt.data,
                caption: this.mt.name,
                thumbnail_url: this.mt.mediaType === "video" ? null : this.mt.data
            }, {
                app: this.app
            });
            let i = this.mt.mediaType === "video" ? ut : ft;
            this.ul = new i({
                media: this.sa,
                app: this.app,
                c: "fera-media-preview-item-media",
                onClick: () => {
                    this.aa = this.aa || new pt({
                        app: this.app,
                        media: [this.sa]
                    }), this.aa.show()
                }
            })
        }
        get file() {
            return this.mt
        }
        r() {
            super.r(), this.prepend(this.ul);
            let t = new Xi({
                app: this.app
            });
            this.w(".fera-media-preview-item-remove-btn", t)
        }
        handleRemove() {
            this.e.remove && this.e.remove(this)
        }
        get s() {
            return `<div class="fera-media-preview-item fera-media-preview-item-${this.mt.mediaType}" data-fera-media-preview-item>
    <a class="fera-media-preview-item-remove-btn" href="#" data-fera-action="handleRemove"></a>
        </div>`
        }
    };
    var Ji = class extends f {
        constructor(t) {
            super(t), this.K = []
        }
        addItem(t) {
            t instanceof li || (t = new li({
                app: this.app,
                file: t,
                remove: this.removeItem.bind(this)
            })), this.K.push(t), this.addChild(t)
        }
        addItems(t) {
            t.forEach(e => this.addItem(e))
        }
        removeAll() {
            this.K.forEach(t => t.remove()), this.K = []
        }
        removeItem(t) {
            this.K = this.K.filter(e => e !== t), this.e.remove && this.e.remove(t.file), t.remove()
        }
        get s() {
            return '<div data-fera-media-preview class="fera fera-media-preview"></div>'
        }
    };
    var Ki = class extends Se {
        constructor(t) {
            super(n({
                mediaTypes: ["image", "video"],
                name: "fera-media",
                fileLimit: 10
            }, t)), this.oe = this.oe || [], this.gt = [], this.Ge = new Ji({
                app: this.app,
                remove: this.fl.bind(this)
            }), this.sizeLimits = n(n({}, this.constructor.DEFAULT_SIZE_LIMITS), this.e.sizeLimits || {})
        }
        static get DEFAULT_SIZE_LIMITS() {
            return {
                image: 20 * 1024 * 1024,
                video: 100 * 1024 * 1024
            }
        }
        set value(t) {
            this.setValue(t)
        }
        get value() {
            return this.gt
        }
        val() {
            return this.value
        }
        setValue(t) {
            this.gt = t instanceof Array ? t : [t], this.refreshView()
        }
        get nt() {
            return this.e.mediaTypes
        }
        get pl() {
            return this.nt.map(t => `${t.toLowerCase()}/*`).join(",")
        }
        get Yi() {
            return this.gt.length > 0
        }
        fl(t) {
            this.gt = this.gt.filter(e => e !== t), this.trigger("remove", t), this.trigger("change"), this.toggleClass("fera-media-input--hasMedia", this.Yi)
        }
        ml(t) {
            if (this.gt.length >= this.e.fileLimit) {
                let e = this.formatNumber(this.e.fileLimit);
                this.oa(this.t("You can only upload {{ fileLimit }} files.", {
                    fileLimit: e
                }));
                return
            }
            this.gt.push(t), this.trigger("input", t), this.trigger("change"), this.toggleClass("fera-media-input--hasMedia", this.Yi), this.Ge.addItem(t)
        }
        oa(t) {
            var i, s, a, o, l;
            if ((i = this.Qe) == null || i.classList.remove("fera-form-group--error"), (a = (s = this.Qe) == null ? void 0 : s.querySelector(".fera-form-error")) == null || a.remove(), !t) return;
            (o = this.Qe) == null || o.classList.add("fera-form-group--error");
            let e = document.createElement("span");
            e.classList.add("fera-form-error"), e.innerHTML = t, (l = this.Qe) == null || l.appendChild(e)
        }
        a() {
            super.a(), this.Ge.removeAll(), this.Ge.addItems(this.gt), this.toggleClass("fera-media-input--hasMedia", this.Yi), this.toggleClass("fera-media-input--disabled", this.p)
        }
        r() {
            super.r(), this.dropzoneEl = this.o("[data-fera-media-dropzone]"), this.dropzoneEl.querySelectorAll("a").forEach(e => {
                e.addEventListener("click", i => {
                    i.preventDefault(), this.I.click()
                })
            });
            let t = new Pi({
                app: this.app
            });
            this.w("[data-fera-media-dropzone-icon]", t), this.w("[data-fera-media-preview-container]", this.Ge), this.Ni()
        }
        h() {
            super.h(), this.Qe = this.el.closest(".fera-form-group") || this.el.parentElement
        }
        Ni() {
            this.I.addEventListener("input", () => {
                Array.from(this.I.files).forEach(t => {
                    let e = new FileReader;
                    e.onload = i => {
                        let s = t.type.split("/").shift(),
                            a = this.sizeLimits[s];
                        if (t.size > a) {
                            let o = a / 1024 / 1024,
                                l = "";
                            s === "image" && (l = this.t("Image must be less than {{ limit_in_mb }} MB.", {
                                limit_in_mb: this.formatNumber(o)
                            })), s === "video" && (l = this.t("Video must be less than {{ limit_in_mb }} MB.", {
                                limit_in_mb: this.formatNumber(o)
                            })), this.oa(l);
                            return
                        }
                        this.ml({
                            name: t.name,
                            type: t.type,
                            size: t.size,
                            data: i.target.result,
                            mediaType: s
                        })
                    }, e.readAsDataURL(t)
                })
            })
        }
        get s() {
            return `<div data-fera-media-input class="fera-media-input">
  <div data-fera-media-preview-container></div>
  <label data-fera-media-dropzone class="fera-media-dropzone fera-container">
    <span data-fera-media-dropzone-icon class="fera-media-dropzone-icon"></span>
    <span class="fera-hidden-xxs">${this.t("{{ link.start }}Tap here{{ link.end }} to browse files",{link:{start:'<a href="#">',end:"</a>"}})}</span>
    <input type="file" multiple accept="${this.pl}" ${this.Ps}>
  </label>
</div>`
        }
    };
    var Ne = class extends w {
        constructor(t) {
            if (super(n({
                    reportHtml5Validation: !0
                }, t)), this.u = this.e.form, !this.u) throw new Error("Form element is required.");
            this.Xi = [], this.Ji = [], this.init()
        }
        init() {
            this.u.querySelectorAll("[data-fera-input]").forEach(t => {
                this.Xi.push(t), t.addEventListener("input", () => {
                    t.setAttribute("data-fera-modified", ""), this.clearErrors(), this.trigger("change")
                })
            })
        }
        validate(t = !0) {
            return t && this.clearErrors(), this.Xi.forEach(e => {
                let i = e.getAttribute("type") === "checkbox" ? e.checked : e.value,
                    s = [];
                if (e.hasAttribute("required") && !i && s.push(e.dataset.feraRequiredMessage || this.t("This field is required.")), e.getAttribute("type") == "email" && i && e.validity.typeMismatch && s.push(e.dataset.feraEmailMessage || this.t("Invalid email address.")), s.length && (this.Ji.push(e.getAttribute("name")), t)) {
                    let a = e.closest(".fera-form-group") || e.parentElement;
                    a == null || a.classList.add("fera-form-group--error"), s.forEach(o => {
                        let l = document.createElement("span");
                        l.classList.add("fera-form-error"), l.innerHTML = o, a == null || a.appendChild(l)
                    })
                }
            }), this.e.reportHtml5Validation && this.u.reportValidity(), this.Ji
        }
        clearErrors() {
            this.Ji = [], this.Xi.forEach(t => {
                var i;
                let e = t.closest(".fera-form-group") || t.parentElement;
                e == null || e.classList.remove("fera-form-group--error"), (i = e == null ? void 0 : e.querySelector(".fera-form-error")) == null || i.remove()
            })
        }
    };
    var Gi = class extends f {
        get gl() {
            return this.t("Image of {{ product.name }}", {
                product: {
                    name: this.e.product.name || this.t("Product")
                }
            })
        }
        get vl() {
            return this.e.productCount <= 1 ? this.t("Product") : this.t("Product ({{ tag.start }}{{ current_index }} of {{ total_count }}{{ tag.end }})", {
                current_index: this.formatNumber(this.e.productPosition),
                total_count: this.formatNumber(this.e.productCount),
                tag: {
                    start: '<span class="fera-submitter-form-product-counter">',
                    end: "</span>"
                }
            })
        }
        get s() {
            return `<div class="fera-form-group fera-submitter-productDisplay">
  <label>${this.vl}</label>
  <div class="fera-submitter-form-product">
      <div class="fera-submitter-form-product-thumbnail">
          <img src="${this.e.product.thumbnailUrl||"https://cdn.fera.ai/img/products/placeholder.png"}" alt="${this.gl}">
      </div>

      <h3 class="fera-submitter-form-product-title">${this.e.product.name}</h3>
  </div>
</div>`
        }
    };
    var Qi = class extends f {
        get s() {
            return `<div>
  ${this.e.testSubmission?`<div class="fera-submitter-form-notice fera-submitter-form-notice--test"><p>${this.t("This submission will be marked as a test.")}</p></div>`:""}
  ${this.e.editMode?`<div class="fera-submitter-form-notice fera-submitter-form-notice--edit"><p>${this.t("This will edit your previously submitted review.")}</p></div>`:""}
</div>`
        }
    };
    var tr = class extends f {
        get s() {
            return `<svg class="fera-icon fera-icon-spinner" width="49" height="49" viewBox="0 0 49 49" xmlns="http://www.w3.org/2000/svg">
  <g>
    <path d="M24.5 6.5V12.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M42.5 24.5H36.5" stroke="#000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M37.227 37.228L32.9844 32.9854" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M24.5 42.5V36.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M11.7715 37.228L16.0141 32.9854" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M6.5 24.5H12.5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M11.7715 11.7725L16.0141 16.0151" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
  </g>
</svg>
`
        }
    };
    var gt = class extends f {
        constructor(t) {
            super(t), this.St = this.e.icon, this.ge = this.e.text || "", this.p = this.e.disabled || !1, this.ic = this.e.submit || !1, this.Ki = this.e.loadingText || this.t("Loading..."), this.Gi = this.e.loading || !1, this.wl = this.e.loadingIcon || new tr(this.i)
        }
        get na() {
            return h(n({}, this.e.attributes || {}), {
                disabled: this.p
            })
        }
        setType(t) {
            this.rendered && (this.ti && this.removeClass(`fera-btn--${this.ti}`), this.addClass(`fera-btn--${t}`)), this.e.type = t
        }
        get ti() {
            return this.e.type || "primary"
        }
        get la() {
            return this.e.size || "md"
        }
        get Qi() {
            return this.e.tagName || (this.e.type === "link" ? "a" : "button")
        }
        disable() {
            this.p = !0, this.a()
        }
        softDisable() {
            this.addClass("fera-btn--disabled")
        }
        enable() {
            this.p = !1, this.removeClass("fera-btn--disabled"), this.a()
        }
        get disabled() {
            return this.p || this.softDisabled
        }
        get softDisabled() {
            return this.hasClass("fera-btn--disabled")
        }
        r() {
            super.r(), this.ti && this.addClass(`fera-btn--${this.ti}`), this.la && this.addClass(`fera-btn--${this.la}`), this.ve = this.o("[data-fera-icon-container]"), this.tr = this.o("[data-fera-text-container]"), this.e.responsive && (this.addClass("fera-btn--responsive"), this.tr.classList.add("fera-hidden-xs"), this.e.responsive === "swap" && this.ve.classList.add("fera-visible-xs-flex")), this.a()
        }
        a() {
            super.a(), this.Gi ? (this.tr.innerHTML = this.Ki, this.w("[data-fera-icon-container]", this.wl, {
                replace: !0
            }), this.ve.classList.remove("fera-hidden")) : (this.tr.innerHTML = this.ge, this.St ? (this.w("[data-fera-icon-container]", this.St, {
                replace: !0
            }), this.ve.classList.remove("fera-hidden")) : (this.ve.innerHTML = "", this.ve.classList.add("fera-hidden"))), this.p ? this.el.setAttribute("disabled", !0) : this.el.removeAttribute("disabled")
        }
        Bi(t) {
            this.disabled ? this.bl(t) : (this.e.onClick && this.e.onClick(t), this.trigger("click"))
        }
        bl(t) {
            this.e.onDisabledClick && this.e.onDisabledClick(t), this.trigger("click:disabled")
        }
        P(t = null) {
            this.rendered && (this.Gi = !0, this.Ki = t || this.Ki, this.a())
        }
        startLoading(t = null) {
            return this.P(t)
        }
        C() {
            this.Gi = !1, this.a()
        }
        stopLoading() {
            return this.C()
        }
        yl() {
            let t = Object.keys(this.na).map(e => `${e}="${this.na[e]}"`).join(" ");
            if (this.Qi === "a" && (t += ` href="${this.e.href||"#"}"`), this.e.responsive || !this.ge) {
                let e = this.e.altText || this.ge || "";
                e ? t += ` aria-label="${e}"` : this.b("Btn missing altText", this)
            }
            return t
        }
        get s() {
            return `<${this.Qi} class="fera-btn" ${this.yl()}>
  <span data-fera-icon-container class="fera-btn-icon"></span>
  <span data-fera-text-container class="fera-btn-text fera-text">${this.e.text||""}</span>
</${this.Qi}>`
        }
    };
    var er = class extends f {
        get s() {
            return `<div>
            <div class="fera-submitter-terms-modal-body">${this.e.template}</div>
            <div class="fera-submitter-terms-modal-footer">
                <button class="fera-btn fera-btn--primary" data-fera-close-btn>${this.t("Go Back")}</button>
            </div>
        </div>`
        }
    };
    var ir = class extends Mt {
        constructor(t) {
            super(t), this.addClass("fera-submitter-terms-modal"), this.e.title = this.t("Content Submission Terms"), this.content = new er(n(n({}, this.i), this.e.submissionTerms))
        }
    };
    var Fe = class extends f {
        constructor(t) {
            var e;
            super(t), this.we = this.e.subject || this.app.store, this.d = this.we instanceof R ? this.we : null, this.n = this.e.submission, this.G = this.e.contentCampaign || ((e = this.n) == null ? void 0 : e.contentCampaign), this.Nt = !!this.e.editMode, this.da = this.e.defaultParams || {}, this.er = !1, this.ir = !1, this.xl = new ir(h(n({}, this.i), {
                submissionTerms: this.rr
            }))
        }
        get rc() {
            return [!0, 1, "1", "true", "yes", "on"]
        }
        get W() {
            let t = this.app.store.get("required_review_fields", {});
            return {
                body: H(t.body),
                rating: H(t.rating),
                heading: H(t.heading),
                media: this.sr && H(t.media),
                terms: this.be
            }
        }
        Cl() {
            this.d.isSet("name") && this.o("[data-fera-product-form-group]") && (this._l = new Gi(h(n({}, this.i), {
                product: this.d,
                productPosition: this.e.productPosition || 1,
                productCount: this.e.productCount || 1
            })), this.w("[data-fera-product-form-group]", this._l))
        }
        kl() {
            this.Sl = new Qi(h(n({}, this.i), {
                editMode: this.Nt,
                testSubmission: !!this.e.testSubmission
            })), this.w("[data-fera-submitter-notices]", this.Sl)
        }
        get rr() {
            let t = this.app.store.get("content_submission_terms", {});
            return {
                enabled: H(t.enabled),
                useDefault: H(t.use_default_term),
                template: t.template,
                checkedByDefault: H(t.checked_by_default)
            }
        }
        get be() {
            var t;
            return this.rr.enabled && !((t = this.n) != null && t.is("agreed_to_terms"))
        }
        get ar() {
            return !!Object.values(this.da).filter(t => t).length
        }
        get Mt() {
            return this.ar ? this.da : {}
        }
        get nt() {
            var t;
            return ((t = this.G) == null ? void 0 : t.mediaTypes) || ["image", "video"]
        }
        get sr() {
            return this.nt.length > 0
        }
        get Ml() {
            return this.nt.length == 1 ? this.nt[0] === "image" ? this.t("Photos") : this.t("Videos") : this.t("Photos &amp; Videos")
        }
        get Rl() {
            return this.nt.length == 1 ? this.nt[0] === "image" ? this.t("Please upload a photo.") : this.t("Please upload a video.") : this.t("Please upload a photo or video.")
        }
        get editMode() {
            return this.Nt
        }
        get changed() {
            return this.ir
        }
        setSubmission(t) {
            t && (this.n = t, this.a())
        }
        r() {
            super.r(), this.d && this.Cl(), this.kl(), this.ye(), this.a()
        }
        get validator() {
            return this.ei || (this.ei = new Ne({
                form: this.u
            }))
        }
        h() {
            super.h(), this.ar && this.Ft()
        }
        a() {
            super.a(), this.n ? (this.xe.checked || (this.xe.checked = this.n.get("agreed_to_terms", this.xe.checked)), this.m.disabled && this.m.enable()) : this.m.disabled || this.m.softDisable()
        }
        ye() {
            this.u = this.o("[data-fera-submitter-form]"), this.or = new Ki(h(n({}, this.i), {
                inputName: "fera-media",
                required: this.W.media,
                inputAttr: {
                    "data-fera-required-message": this.Rl
                },
                on: {
                    change: this.Ft.bind(this)
                },
                mediaTypes: this.nt
            })), this.m = new gt(h(n({}, this.i), {
                text: this.t("Submit"),
                loadingText: this.t("Submitting..."),
                onClick: this.nr.bind(this),
                onDisabledClick: () => {
                    this.validator.validate()
                },
                size: "block",
                c: "fera-submit-btn"
            })), this.m.softDisable(), this.w("[data-fera-media-container]", this.or), this.w("[data-fera-submitter-actions]", this.m), this.xe = this.o('[name="fera-accept-terms"]'), this.xe.checked = this.rr.checkedByDefault, this.q("[data-fera-input]", t => {
                t.addEventListener("input", this.Ft.bind(this))
            }), this.app.config.designMode && (this.Tl = new J(h(n({}, this.i), {
                target: this.m,
                content: this.t("Disabled in design mode")
            })))
        }
        Ft() {
            this.ir || (this.ir = !0), this.trigger("change")
        }
        get formData() {
            let t = {};
            return this.e.customerEmail && (t.customer_email = this.e.customerEmail), this.e.customerName && (t.customer_name = this.e.customerName), this.be && this.xe.checked && (t.submission = {
                agreed_to_terms: !0
            }), this.d && (t.product_id = this.d.id), t
        }
        ii() {
            throw new Error("Must implement _createResource")
        }
        nr(t) {
            t.preventDefault(), this.submit()
        }
        submit(t) {
            return m(this, null, function*() {
                if (t == null || t.preventDefault(), !this.validator.validate().length && !this.app.config.designMode && this.u.checkValidity()) {
                    this.m.disable(), this.m.startLoading(), this.er = !0, this.trigger("submit");
                    try {
                        let e = yield this.ii();
                        e.isClientError ? this.trigger("submit:error", e.errors) : (this.be && this.n.set("agreed_to_terms", !0), e.status == 200 && (this.Nt = !0), this.trigger("submit:success", this.formData))
                    } catch (e) {
                        this.trigger("submit:error", e), this.m.enable()
                    } finally {
                        this.er = !1, this.m.stopLoading()
                    }
                }
            })
        }
        showTerms() {
            this.xl.show()
        }
        get ha() {
            return `<div class="fera-form-group ${this.sr?"":"fera-hidden"}">
        <label for="fera-media">${this.Ml} ${this.W.media?"*":""}</label>
        <div data-fera-media-container></div>
      </div>`
        }
        get ca() {
            return `<div class="fera-form-group ${this.be?"":"fera-hidden"}">
        <label class="fera-input-group">
          <input type="checkbox" name="fera-accept-terms" data-fera-input ${this.W.terms?"required":""}
          data-fera-required-message="${this.t("You must agree to our terms of service.")}">
          <span>&nbsp;${this.t("I agree to the {{ link.start }}terms of service{{ link.end }}.",{link:{start:'<a href="#" data-fera-action="showTerms">',end:"</a>"}})}</span>
        </label>
      </div>`
        }
        get s() {
            return `<div class="fera-submitter-form">
  <div data-fera-submitter-notices></div>
  ${this.d?"<div data-fera-product-form-group></div>":""}

  <form data-fera-submitter-form>${this.ua}</form>
</div>`
        }
    };
    var rr = class extends Fe {
        constructor(t) {
            super(t), this.fa = I(this.pa.bind(this), 1e3), this.Rt = this.e.existingReview, this.Nt = this.e.editMode || !!this.Rt, this.addClass("fera-submitter-reviewForm")
        }
        get ratingFeedbackOptions() {
            return [this.t("Bad!"), this.t("Poor!"), this.t("Okay!"), this.t("Great!"), this.t("Excellent!")]
        }
        get ratingSummaryOptions() {
            return {
                1: [this.t("Really not happy."), this.t("No good."), this.t("Pretty bad."), this.t("No thanks."), this.t("Awful"), this.t("No good."), this.t("Not recommended at all!")],
                2: [this.t("Not happy."), this.t("Nah."), this.t("Probably not again."), this.t("Not the best."), this.t("Not for me.")],
                3: [this.t("Meh."), this.t("Not amazing."), this.t("Pretty ok."), this.t("It's fine."), this.t("Mostly good, but..."), this.t("Decent.")],
                4: [this.t("Pretty good!"), this.t("I dig it!"), this.t("Solid!"), this.t("Recommended!"), this.t("Really, really good."), this.t("A very positive experience."), this.t("Really nice!"), this.t("Glad I got this."), this.t("Really good!"), this.t("Quite nice!")],
                5: [this.t("Great!"), this.t("Fantastic!"), this.t("Excellent!"), this.t("Highly recommended!"), this.t("How great!"), this.t("Really loved it!"), this.t("Terrific!"), this.t("Incredible!"), this.t("Wonderful!"), this.t("Marvelous!"), this.t("Remarkable!"), this.t("Phenomenal!"), this.t("Spectacular!"), this.t("Definitely recommended!"), this.t("You should get this!")]
            }
        }
        get $l() {
            return !this.app.store.is("autofill_review_headings_disabled")
        }
        setSubmission(t) {
            super.setSubmission(t), this.fa()
        }
        get Mt() {
            let t = {};
            return this.Rt && (t.rating = this.Rt.get("rating"), t.heading = this.Rt.get("heading"), t.body = this.Rt.get("body")), n(n({}, t), super.Mt)
        }
        pa() {
            return m(this, null, function*() {
                var e;
                if (!(this.Nt || this.er || this.app.config.designMode || this.e.testSubmission || !this.n || this.validator.validate(!1).filter(i => i != "fera-accept-terms").length)) try {
                    let i = yield this.ii({
                        draft: !0
                    });
                    if (i.isClientError) {
                        let s = (e = i.errors) == null ? void 0 : e.customer;
                        s != null && s.join(",").match(/already submitted/) && (this.Nt = !0, this.b("Review already submitted, switching to edit mode."))
                    }
                } catch (i) {
                    this.b(`Failed to save draft: ${i.message}`)
                }
            })
        }
        r() {
            this.ar && this.pa(), this.ma = this.o("[data-rating-feedback]"), this.lr = this.o("[data-review-content]"), super.r(), this.Pl()
        }
        a() {
            super.a(), this.vt.value ? this.ma.textContent = this.ratingFeedbackOptions[this.vt.value - 1] : this.ma.textContent = "", this.vt.value && !this.lr.classList.contains("fera-submitter-form-content--open") && this.lr.classList.add("fera-submitter-form-content--open")
        }
        Pl() {
            (!this.W.rating || this.Mt.rating || this.e.maximize) && this.lr.classList.add("fera-submitter-form-content--open")
        }
        ye() {
            this.vt = new $i(h(n({}, this.i), {
                inputName: "fera-rating",
                value: this.Mt.rating,
                required: this.W.rating,
                inputAttr: {
                    "data-fera-required-message": this.t("Please select a rating.")
                },
                on: {
                    change: this.Ft.bind(this)
                }
            })), this.Ce = this.o('[name="fera-heading"]'), this.dr = this.o('[name="fera-body"]'), this.w("[data-fera-rating-container]", this.vt), super.ye(), this.ga(), this.vt.on("change", () => {
                this.a(), this.ga(), this.Ce.value ? this.dr.value || this.dr.focus() : this.Ce.focus()
            })
        }
        ga() {
            if (!this.vt.value || this.Mt.heading || !this.$l || this.Ce.hasAttribute("data-fera-modified")) return;
            let t = this.ratingSummaryOptions[this.vt.value];
            this.Ce.value = t[Math.floor(Math.random() * t.length)]
        }
        Ft() {
            super.Ft(), this.fa()
        }
        get formData() {
            return h(n({}, super.formData), {
                rating: this.vt.value,
                heading: this.Ce.value,
                body: this.dr.value,
                media: this.or.value
            })
        }
        ii(t = {}) {
            return this.app.api.createReview(this.n.token, n(n({}, this.formData), t))
        }
        get ua() {
            return `
    <div data-fera-rating class="fera-form-group">
      <label for="rating">${this.t("Rating")} ${this.W.rating?"*":""}</label>
      <div class="form-group-rating">
        <div data-fera-rating-container></div>
        <i data-rating-feedback class="fera-rating-feedback fera-hidden-xxs"></i>
      </div>
      <span class="fera-form-error">${this.t("Please choose a rating")}</span>
    </div>
    <div data-review-content class="fera-submitter-form-content">
      <div class="fera-form-group">
        <label for="fera-heading">${this.t("Summary")} ${this.W.heading?"*":""}</label>
        <input type="text" class="fera-input" name="fera-heading" placeholder="${this.t("How was your experience?")}" data-fera-input
          value="${this.Mt.heading||""}" ${this.W.heading?"required":""}
          data-fera-required-message="${this.t("Please write a summary")}">
      </div>
      <div class="fera-form-group">
        <label for="fera-body">${this.t("Details")} ${this.W.body?"*":""}</label>
        <textarea class="fera-input" name="fera-body" rows="3" placeholder="${this.t("What did you like about it?")}" data-fera-input
          ${this.W.body?"required":""}
          data-fera-required-message="${this.t("Please write more details")}">${this.Mt.body||""}</textarea>
      </div>
      ${this.ha}
      ${this.ca}
      <div data-fera-submitter-actions></div>
    </div>`
        }
    };
    var sr = class extends Fe {
        constructor(t) {
            super(t), this.addClass("fera-submitter-mediaForm")
        }
        get formData() {
            return n({
                files: this.or.value
            }, super.formData)
        }
        get nt() {
            var t;
            return (t = this.G) != null && t.mediaTypes.length ? this.G.mediaTypes : ["image", "video"]
        }
        get sr() {
            return !0
        }
        get W() {
            return {
                media: !0,
                terms: this.be
            }
        }
        ii() {
            return this.app.api.createMedia(this.n.token, this.formData)
        }
        get ua() {
            return `${this.ha}
      ${this.ca}
    <div data-fera-submitter-actions></div>`
        }
    };
    var ar = class extends f {
        constructor(t) {
            super(t), this.addClass("fera-modal-mask fera-hidden")
        }
    };
    var Gt = class extends f {
        get s() {
            return `<svg class="fera-icon fera-icon-check" width="53" height="52" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="6.5 6 52 52">
    <title>${this.t("Success")}</title>
    <path fill="#000" fill-rule="evenodd" clip-rule="evenodd" d="M18.055 10.382A26 26 0 0132.5 6a26.03 26.03 0 0126 26 26 26 0 11-40.445-21.618zm26.136 14.341a1 1 0 00-1.382-1.446l-13.976 13.34-6.642-6.34a1 1 0 00-1.381 1.446l7.333 7a1 1 0 001.38 0l14.668-14z" />
</svg>`
        }
    };
    var Qt = class extends ar {
        constructor(t) {
            super(n({
                icon: Gt
            }, t)), this.St = this.e.icon, typeof this.St == "function" && (this.St = new this.St)
        }
        get ri() {
            return []
        }
        r() {
            super.r(), this._ = this.o(".fera-modal-mask-message"), this.M = this.o(".fera-modal-mask-title"), this.w(".fera-modal-mask-icon", this.St)
        }
        show({
            title: t,
            message: e
        } = {}) {
            super.show(), t && (this.M.innerHTML = t), e && (this._.innerHTML = e)
        }
        get s() {
            return `<div>
    <div class="fera-modal-mask-icon"></div>
    <h1 class="fera-modal-mask-title">${this.e.title}</h1>
    <p class="fera-modal-mask-message">${this.e.message}</p>
    <div class="fera-modal-mask-actions">${this.ri.join("")}</div>
<div>`
        }
    };
    var qe = class extends Qt {
        constructor(t) {
            super(n({
                icon: Gt,
                c: "fera-modal-mask--success"
            }, t)), this.e.title = this.e.title || this.t("Success!"), this.e.message = this.e.message || this.t("Success!"), this.e.continueBtnText = this.e.continueBtnText || this.t("Continue")
        }
        onContinue() {
            this.e.onContinue && this.e.onContinue()
        }
        get ri() {
            let t = [];
            return this.e.onContinue && t.push(`<button class="fera-btn fera-btn--primary fera-btn--block" data-fera-action="onContinue">${this.e.continueBtnText}</button>`), t
        }
    };
    var te = class extends f {
        get s() {
            return `<img class="fera-icon fera-icon-warn" width="53" height="52" src="${this.B("fera/components/icons/warn/image.svg")}" alt="${this.t("Warning")}"/>`
        }
    };
    var ee = class extends Qt {
        constructor(t) {
            super(n({
                icon: te,
                c: "fera-modal-mask--error"
            }, t)), this.e.title = this.e.title || this.t("There was an issue."), this.e.message = this.e.message || this.t("There was an issue, please try again.")
        }
        tryAgain() {
            this.hide(), this.e.retry && this.e.retry()
        }
        get ri() {
            return ['<button class="fera-btn fera-btn--secondary fera-btn--block" data-fera-action="tryAgain">Try Again</button>']
        }
    };
    var We = class extends Qt {
        constructor(t) {
            super(n({
                icon: te
            }, t)), this.e.title = this.e.title || this.t("Are you sure?"), this.e.message = this.e.message || this.t("Are you sure you want to continue?"), this.e.confirmBtnText = this.e.confirmBtnText || this.t("Yes"), this.e.cancelBtnText = this.e.cancelBtnText || this.t("Cancel")
        }
        onConfirm() {
            this.e.onConfirm && this.e.onConfirm()
        }
        get ri() {
            return [`<button class="fera-btn fera-btn--primary fera-btn--block" data-fera-action="onConfirm">${this.e.confirmBtnText}</button>`, `<button class="fera-btn fera-btn--secondary fera-btn--block" data-fera-action="hide">${this.e.cancelBtnText}</button>`]
        }
    };

    function Ts(r) {
        let t = r % 10,
            e = r % 100;
        return t == 1 && e != 11 ? r + "st" : t == 2 && e != 12 ? r + "nd" : t == 3 && e != 13 ? r + "rd" : r + "th"
    }
    var or = class extends Mt {
        constructor(t) {
            super(t), this.addClass("fera-submitter-content-modal"), this.we = this.e.subject || this.app.store, this.si = !1, this.ai = !1, this._e = new qe(h(n({}, this.i), {
                onContinue: () => {
                    this.ke && clearTimeout(this.ke), this.trigger("submitted")
                }
            })), this.lt = new ee(n({}, this.i)), this.Se = new We(h(n({}, this.i), {
                title: this.t("Abandon Review?"),
                message: this.t("Your review will be discarded."),
                onConfirm: this.hr.bind(this),
                confirmBtnText: this.t("Abandon Review")
            })), this.u = this.content = new this.Il(this.e), this.z = [this._e, this.lt, this.Se]
        }
        get Il() {
            return this.va ? sr : rr
        }
        get va() {
            var t;
            return ((t = this.e.contentCampaign) == null ? void 0 : t.requestMedia) || this.app.request.hasFeraFlag("media_only")
        }
        get wa() {
            return [{
                title: this.t("You're the best!"),
                message: this.t("We appreciate your feedback!")
            }, {
                title: this.t("Way to go!"),
                message: this.t("Your review was submitted successfully!")
            }, {
                title: this.t("You Rock!"),
                message: this.t("Your review was submitted successfully!")
            }, {
                title: this.t("Awesome!"),
                message: this.t("Thanks for sharing your experience")
            }]
        }
        get M() {
            return super.M ? super.M : this.va ? this.e.existingReview ? this.t("Edit Submission") : this.we instanceof this.app.store.constructor ? this.t("Submit photos/videos of your experience") : this.e.productCount === 1 ? this.t("Submit product photos/videos") : this.app.locale === "en" ? `Submit photos/videos for ${Ts(this.e.productPosition)} product` : this.t("Submit photos/videos for product #{{ index }}", {
                index: this.formatNumber(this.e.productPosition)
            }) : this.e.existingReview ? this.t("Edit Review") : this.we instanceof this.app.store.constructor ? this.t("How was your overall experience?") : this.e.productCount === 1 ? this.t("Review Product") : this.app.locale === "en" ? `Review ${Ts(this.e.productPosition)} Product` : this.t("Review Product #{{ index }}", {
                index: this.formatNumber(this.e.productPosition)
            })
        }
        r() {
            super.r(), this.u.on("submit", this.cr.bind(this)), this.u.on("submit:success", this.ur.bind(this)), this.u.on("submit:error", this.fr.bind(this)), this.u.on("change", () => this.trigger("form:change")), this.app.config.designMode && !this.e.canAbandon && (this.sc = new J(h(n({}, this.i), {
                target: this.mn,
                content: this.t("Disabled in design mode")
            })))
        }
        cr() {
            this.P(this.t("Please wait..."))
        }
        ur() {
            this.si = !0, this.C();
            let t = {};
            this.u.editMode ? t = {
                title: this.t("Review Updated"),
                message: this.t("Your review was updated successfully!")
            } : t = this.wa[Math.floor(Math.random() * this.wa.length)], this.ke = setTimeout(() => this.trigger("submitted"), 3e3), this._e.show(t)
        }
        fr(t) {
            this.C(), this.Jt ? this.lt.show({
                message: t.message
            }) : this.lt.show()
        }
        Di() {
            return this.e.canAbandon ? !0 : this.app.config.designMode ? !1 : !this.u.changed || this.si || this.ai ? !0 : (this.Se.show(), !1)
        }
        hr() {
            this.ai = !0, this.hide(), this.trigger("abandoned")
        }
        setSubmission(t) {
            this.u.setSubmission(t)
        }
    };
    var nr = class extends f {
        constructor(t) {
            super(t), this.n = this.e.submission
        }
        get validator() {
            return this.ei || (this.ei = new Ne({
                form: this.u
            }))
        }
        r() {
            super.r(), this.ye()
        }
        ye() {
            this.Ll = this.o('[name="fera-display-name"]'), this.Al = this.o('[name="fera-name"]'), this.El = this.o('[name="fera-email"]'), this.u = this.o("[data-fera-customer-form]"), this.m = new gt(h(n({}, this.i), {
                text: this.t("Submit"),
                loadingText: this.t("Submitting..."),
                onClick: this.nr.bind(this),
                onDisabledClick: () => {
                    this.ei.validate()
                },
                size: "block",
                c: "fera-submit-btn"
            })), this.w("[data-fera-submitter-actions]", this.m), this.app.config.designMode && (this.m.softDisable(), this.Tl = new J(h(n({}, this.i), {
                target: this.m,
                content: this.t("Disabled in design mode")
            })))
        }
        nr(t) {
            t.preventDefault(), this.submit()
        }
        submit(t) {
            return m(this, null, function*() {
                if (t == null || t.preventDefault(), this.validator.validate().length || this.app.config.designMode || !this.u.checkValidity()) return;
                this.m.disable(), this.m.startLoading(), this.trigger("submit");
                let e = {
                    display_name: this.Ll.value,
                    full_name: this.Al.value,
                    email: this.El.value,
                    visitor_id: this.app.visitorService.getId()
                };
                try {
                    let i = yield this.app.api.createCustomer(this.n.token, e);
                    this.n.set("customer_id", i.id), this.n.customer = i, this.trigger("submit:success", this.customer)
                } catch (i) {
                    this.trigger("submit:error", i), this.m.enable()
                } finally {
                    this.m.stopLoading()
                }
            })
        }
        get s() {
            return `<div class="fera-submitter-form fera-submitter-customerForm">
  <form data-fera-customer-form>
    <div class="fera-form-group">
      <label for="fera-display-name">${this.t("Display Name")}</label>
      <input type="text" class="fera-input" name="fera-display-name" placeholder="${this.t("Name to show on reviews")}" data-fera-input>
    </div>

    <div class="fera-form-group">
      <label for="fera-name">${this.t("Full Name")} *</label>
      <input type="text" class="fera-input" name="fera-name" placeholder="${this.t("Your full name")}" required data-fera-required-message="${this.t("Please enter your name")}" data-fera-input>
    </div>

    <div class="fera-form-group">
      <label for="fera-email">${this.t("Email")} *</label>
      <input type="email" class="fera-input" data-fera-email-message="${this.t("Please enter a valid email address")}" name="fera-email" placeholder="${this.t("Your email address")}" required data-fera-required-message="${this.t("Please enter your email address")}" data-fera-input>
    </div>
    <div data-fera-submitter-actions></div>
  </form>
</div>`
        }
    };
    var lr = class extends Mt {
        constructor(t) {
            super(t), this.addClass("fera-submitter-customer-modal"), this._e = new qe(h(n({}, this.i), {
                onContinue: () => {
                    this.ke && clearTimeout(this.ke), this.trigger("submitted")
                }
            })), this.lt = new ee(this.i), this.Se = new We(h(n({}, this.i), {
                title: this.t("Abandon Profile?"),
                message: this.t("You will not be able to manage your review without a profile."),
                onConfirm: this.hr.bind(this),
                confirmBtnText: this.t("Abandon Profile")
            })), this.z = [this._e, this.lt, this.Se], this.u = this.content = new nr(this.e)
        }
        get M() {
            return super.M ? super.M : this.t("Complete Your Profile")
        }
        r() {
            super.r(), this.u.on("submit", this.cr.bind(this)), this.u.on("submit:success", this.ur.bind(this)), this.u.on("submit:error", this.fr.bind(this))
        }
        cr() {
            this.P(this.t("Please wait..."))
        }
        ur() {
            this.si = !0, this.C(), this.ke = setTimeout(() => this.trigger("submitted"), 3e3), this._e.show({
                message: this.t("Thanks for completing your profile!")
            })
        }
        fr(t) {
            this.C(), this.Jt ? this.lt.show({
                message: t.message
            }) : this.lt.show()
        }
        Di() {
            return this.si || this.ai ? !0 : (this.Se.show(), !1)
        }
        hr() {
            this.ai = !0, this.hide(), this.trigger("abandoned")
        }
    };
    var dr = class extends f {
        constructor(t) {
            super(h(n({}, t), {
                c: "fera-submitter-summary"
            })), this.Bl = new Gt({
                app: this.app
            })
        }
        get s() {
            return `<div class="fera fera-hidden">
            <div class="${this.e.c}-icon"></div>
            <h1 class="${this.e.c}-title">${this.t("All done!")}</h1>
            <p class="${this.e.c}-message">${this.t("Thanks for the review{% if count != 1 %}s{% endif %}!",{count:0})}</p>
        </div>`
        }
        r() {
            this._ = this.o(`.${this.e.c}-message`), this.w(`.${this.e.c}-icon`, this.Bl)
        }
        showSummary({
            reviewedSubjects: t = []
        }) {
            t.length <= 0 ? this._.innerHTML = this.t("You have reviewed the store and/or all products.") : this._.innerHTML = this.t("Thanks for the review{% if count != 1 %}s{% endif %}!", {
                count: t.length
            }), this.show()
        }
    };
    var vt = class extends Mt {
        constructor(t) {
            super(t), this.addClass("fera-submitter-strategy-modal"), this.Q = [], this.H = [], this.Tt = [], this.pr = [], this.dt = null, this.$t = null, this.n = null, this.G = null, this.oi = null, this.Me = null, this.mr = !1, this.Re = [], this.lt = new ee(h(n({}, this.i), {
                retry: () => this.trigger("retry")
            })), this.Ol = this.content = new dr(this.i)
        }
        get wt() {
            return !!this.e.testSubmission
        }
        get i() {
            return h(n({}, super.i), {
                testSubmission: this.wt
            })
        }
        get Pt() {
            let t = {
                visitor_id: this.Me || this.app.visitorService.getId()
            };
            return this.wt && (t.test = !0), t
        }
        get zl() {
            return [...this.Tt, ...this.pr].filter(t => t instanceof R).length + 1
        }
        get Rt() {
            return this.dt ? this.dt instanceof this.store.constructor ? this.Re.find(t => t.forStore) : this.Re.find(t => t.forProduct && (t.get("product_id") == this.dt.id || t.get("external_product_id") == this.dt.get("external_id"))) : null
        }
        get ba() {
            var t;
            return !((t = this.n) != null && t.hasCustomer())
        }
        retry() {
            this.start()
        }
        start() {
            return m(this, null, function*() {
                this.show(), this.P(this.t("Please wait...")), yield this.qt(), this.ni()
            })
        }
        destroy() {
            var t, e, i;
            this.mr = !0, (t = this.ya) == null || t.hide(!0), (e = this.$t) == null || e.hide(!0), (i = this.gr) == null || i.hide(!0), this.hide(), super.destroy()
        }
        qt() {
            throw new Error("_fetchAndQueueSubjects not implemented")
        }
        showError(t) {
            this.C(), this.lt.show(t.message)
        }
        ac() {
            return '<div style="height: 350px"></div>'
        }
        jl() {
            this.vr()
        }
        vr() {
            this.n && (this.Tt.length > 0 ? this.app.api.finalizeSubmission(this.n.token) : this.app.api.deleteSubmission(this.n.token))
        }
        oc() {
            this.pr.push(this.dt), this.ni()
        }
        Vl() {
            this.Tt.push(this.dt), this.Tt.length && this.ba ? this.xa() : this.ni()
        }
        Dl() {
            this.n || this.Nl()
        }
        Ca() {
            this.show(), this.C(), this.Ol.showSummary({
                reviewedSubjects: this.Tt,
                skippedSubjects: this.pr
            })
        }
        _a(t) {
            return m(this, null, function*() {
                return this.store.hasReviewProductExclusions ? (yield Promise.all(t.map(i => m(this, null, function*() {
                    return (yield this.store.reviewProductExclusions.match(this.app.getState({
                        product_id: i.get("external_id")
                    }))) ? void 0 : i
                })))).filter(i => !!i) : [...t]
            })
        }
        Fl() {
            var t;
            (t = this.$t) == null || t.hide(), this.Tt.length && this.ba ? this.xa() : (this.Ca(), this.vr())
        }
        ql() {
            this.gr.hide(), this.H.length ? this.ni() : (this.Ca(), this.vr())
        }
        ni() {
            if (!this.mr) {
                if (this.dt = this.H.shift(), this.ya = this.$t, !this.dt) {
                    this.Fl();
                    return
                }
                this.Wl()
            }
        }
        get Hl() {
            let i = this.e,
                {
                    defaultParams: t
                } = i,
                e = Sa(i, ["defaultParams"]);
            return !this.Tt.length && t && (e.defaultParams = t), n(h(n({}, e), {
                subject: this.dt,
                contentCampaign: this.G,
                submission: this.n,
                productPosition: this.zl,
                productCount: this.Q.length,
                existingReview: this.Rt
            }), this.i)
        }
        Wl() {
            var t;
            this.$t = new or(h(n({}, this.Hl), {
                on: {
                    abandoned: this.jl.bind(this),
                    submitted: this.Vl.bind(this)
                },
                once: {
                    "form:change": this.Dl.bind(this)
                }
            })), this.hide(), (t = this.ya) == null || t.hide(), this.$t.show()
        }
        xa() {
            var t;
            this.mr || (this.gr = new lr(h(n({}, this.i), {
                submission: this.n,
                on: {
                    submitted: () => {
                        this.ql()
                    }
                }
            })), this.hide(), (t = this.$t) == null || t.hide(), this.gr.show())
        }
        Nl() {
            return m(this, null, function*() {
                var t;
                if (!this.app.config.designMode) {
                    if (this.n) return this.n;
                    if (!this.ka) {
                        this.ka = !0;
                        try {
                            return this.n = yield this.app.api.createSubmission(this.Pt), this.oi = this.oi || this.n.get("customer_id") || this.n.get("external_customer_id"), this.Me = this.Me || this.n.get("visitor_id"), (t = this.$t) == null || t.setSubmission(this.n), this.n
                        } catch (e) {
                            this.b(`Failed to create submission: ${e.message}`)
                        } finally {
                            this.ka = !1
                        }
                    }
                }
            })
        }
    };
    var hr = class extends vt {
        constructor(t) {
            super(t), this.Sa = t.messageToken, this._ = null
        }
        get wt() {
            var t;
            return super.wt || ((t = this._) == null ? void 0 : t.is("test"))
        }
        get Pt() {
            var e;
            let t = h(n({}, super.Pt), {
                message_token: this.Sa
            });
            return (e = this.G) != null && e.isSet("token") && (t.campaign_token = this.G.get("token")), this._.isSet("visitor_id") && (t.visitor_id = this._.get("visitor_id")), t
        }
        qt() {
            return m(this, null, function*() {
                var t, e;
                this._ = yield this.app.api.retrieveMessage(this.Sa), this.G = this._.contentCampaign, this.n = this._.activeSubmission, this.oi = this._.get("customer_id") || this._.get("external_customer_id"), this.Me = this._.get("visitor_id"), this.Re = [...this._.reviews], ((t = this.G) == null ? void 0 : t.get("review_type")) !== Bt.resourceName && (this.Q = yield this._a(this._.products), this.H = [...this.Q]), (((e = this.G) == null ? void 0 : e.get("review_type")) !== R.resourceName || this.Q.length < 1) && this.H.push(this.store)
            })
        }
    };
    var cr = class extends vt {
        constructor(t) {
            super(t), this.Ma = t.orderId, this.Ra = t.customerEmail, this.It = null
        }
        get wt() {
            var t;
            return super.wt || ((t = this.It) == null ? void 0 : t.is("test"))
        }
        get Pt() {
            return h(n({}, super.Pt), {
                order_id: this.Ma,
                customer_email: this.Ra
            })
        }
        qt() {
            return m(this, null, function*() {
                this.It = yield this.app.api.retrieveSubmissionOrder(this.Ma, this.Ra), this.Me = this.It.get("visitor_id"), this.oi = this.It.get("customer_id") || this.It.get("external_customer_id"), this.Q = yield this._a(this.It.products), this.Re = [...this.It.reviews], this.H = [...this.Q], (this.store.is("auto_request_store_review") || !this.Q.length) && this.H.push(this.store)
            })
        }
    };
    var ur = class extends vt {
        constructor(t) {
            super(t), this.bt = t.productId, this.d = null
        }
        qt() {
            return m(this, null, function*() {
                var t, e;
                if (((t = this.app.currentProduct) == null ? void 0 : t.id) == this.bt && (this.d = this.app.currentProduct), !((e = this.d) != null && e.isSet("name"))) try {
                    this.d = yield this.app.api.retrieveProduct(this.bt)
                } catch (i) {
                    this.b("error", "Failed to retrieve product", i)
                } finally {
                    this.d = this.d || new R({
                        id: this.bt
                    }, {
                        app: this.app
                    })
                }
                this.Q = [this.d], this.H = [...this.Q], this.store.is("auto_request_store_review") && this.H.push(this.store)
            })
        }
    };
    var fr = class extends vt {
        qt() {
            this.H.push(this.store)
        }
    };
    var pr = class extends vt {
        constructor(t) {
            super(t), this.Ta = t.reviewToken, this.Wt = null
        }
        get wt() {
            var t;
            return super.wt || ((t = this.Wt) == null ? void 0 : t.is("test"))
        }
        get Pt() {
            return h(n({}, super.Pt), {
                review_token: this.Ta
            })
        }
        qt() {
            return m(this, null, function*() {
                this.Wt = yield this.app.api.retrievePrivateReview(this.Ta), this.Re.push(this.Wt), this.Wt.forProduct ? (this.Q.push(this.Wt.product), this.H.push(this.Wt.product)) : this.H.push(this.store)
            })
        }
    };
    var He = class extends w {
        constructor(t) {
            super(t), this.st = {}, this.$a(this.e), this.li = null
        }
        get Ul() {
            return this.st.reviewToken ? pr : this.st.messageToken ? hr : this.st.orderId ? cr : this.st.productId ? ur : fr
        }
        show(t = {}) {
            return this.Zl(t)
        }
        hide() {
            this.li && this.li.destroy()
        }
        Zl() {
            return m(this, arguments, function*(t = {}) {
                this.hide(), yield this.$a(t), this.li = new this.Ul(n(n({}, this.i), this.st)), this.li.start()
            })
        }
        get J() {
            return this.app.request.params
        }
        $a() {
            return m(this, arguments, function*(t = {}) {
                t = n(n({}, this.J), t);
                let e = {
                    editMode: t.editMode || t.edit_mode || t.edit || !1,
                    designMode: t.designMode || t.fera_design || this.app.config.designMode,
                    testSubmission: t.testSubmission || t.test || t.fera_test,
                    orderId: t.orderId || t.order_id || t.order || t.fera_order_id || t.fera_order,
                    maximize: t.maximize || t.fera_maximize,
                    title: t.title || t.fera_title,
                    productId: t.productId || t.product_id || t.product,
                    reviewToken: t.reviewToken || t.review_token || t.rt || t.fera_rt,
                    messageToken: t.messageToken || t.customer_message_token || t.message_token || t.cmt || t.fera_cmt,
                    customerName: t.customerName || t.customer_name || t.customer || t.fera_name || t.name,
                    customerEmail: t.customerEmail || t.customer_email || t.fera_email || t.email,
                    contentCampaignToken: t.contentCampaignToken || t.content_campaign_token || t.campaign_token || t.cct || t.fera_cct,
                    canAbandon: t.canAbandon,
                    defaultParams: {
                        rating: t.defaultRating || t.fera_rating || t.rating,
                        heading: t.defaultHeading || t.fera_heading || t.heading,
                        body: t.defaultBody || t.fera_body || t.body
                    }
                };
                e.productId || (e.productId = this.app.currentProductId || (yield this.app.retrieveCurrentProductIdFromPlugins())), Object.keys(e).forEach(i => {
                    typeof e[i] == "undefined" ? delete e[i] : i === "defaultValues" && (Object.keys(e).forEach(s => {
                        typeof e[i][s] == "undefined" && delete e[i][s]
                    }), Object.keys(e[i]).length < 1 && delete e[i])
                }), this.st = n(n({}, this.st), e)
            })
        }
    };

    function ia() {
        var r = new Date().getTime();
        return globalThis.performance && typeof globalThis.performance.now == "function" && (r += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
            var e = (r + Math.random() * 16) % 16 | 0;
            return r = Math.floor(r / 16), (t == "x" ? e : e & 3 | 8).toString(16)
        })
    }
    var mr = class extends w {
        getId() {
            return this.id ? this.id : (this.app.config.designMode || (this.id = this.app.storage.get("shopperId")), this.updateBasedOnUrl(), this.id || this.issueNewId(), this.id)
        }
        setId(t) {
            this.id = t, this.id.indexOf(" path=/") !== -1 && (this.id = this.id.replace(" path=/", "")), !this.app.config.designMode && this.app.storage.set("shopperId", this.id, 5 * 365)
        }
        updateBasedOnUrl() {
            let t = this.app.request.params,
                e = t.visitor || t.visitor_id || t.shopper || t.shopper_id;
            if (!e) return this.id;
            e = e.toLowerCase(), this.id && this.id.toLowerCase() !== e && this.b("Shopper (visitor) ID was changed from URL.", this.id, e), this.setId(e)
        }
        issueNewId() {
            let t = ia();
            this.setId(t)
        }
    };
    var gr = class extends w {
        start() {
            this.Yl()
        }
        Yl() {
            this.wr && this.Xl("fera_starting")
        }
        get wr() {
            return this.br ? this.br : (this.br = globalThis.opener ? globalThis.opener : globalThis.parent && globalThis.parent.length > 0 && window !== globalThis.top ? globalThis.parent : null, this.br)
        }
        Xl(t) {
            try {
                let e = new URL(this.app.config.appUrl).href;
                this.wr && this.wr.postMessage(JSON.stringify({
                    params: {
                        status: t
                    }
                }), e)
            } catch (e) {}
        }
    };
    var vr = class extends w {
        constructor(t) {
            super(t), this.location = this.app.storage.getObject("geo")
        }
        static get example() {
            return {
                ip: "17.235.64.1",
                continent: "NA",
                country_code: "US",
                country_name: "United States",
                region_code: "TX",
                region_name: "Texas",
                city: "Austin",
                zip_code: "78760",
                time_zone: "America/Chicago",
                latitude: 30.3076576,
                longitude: -97.9205515
            }
        }
        setLocation(t) {
            this.location = this.location || {}, this.location = n(n({}, this.location), t), this.app.storage.setObject("geo", t, 365)
        }
        retrieveLocation() {
            return m(this, null, function*() {
                return this.location ? this.location : (this.setLocation(yield fetch("https://geo.bananastand.io/json/").then(t => t.json())), this.location)
            })
        }
    };
    var wr = class extends w {
        removeSeoAttributes(t) {
            !t || !t.removeAttribute || (t.removeAttribute("itemprop"), t.removeAttribute("itemtype"), t.removeAttribute("itemscope"), t.querySelectorAll("[itemprop],[itemtype],[itemscope]").forEach(e => {
                e.removeAttribute("itemprop"), e.removeAttribute("itemtype"), e.removeAttribute("itemscope")
            }))
        }
        removeFromWidget(t) {
            this.removeSeoAttributes(t.el), this.Pa(e => {
                if (!e.aggregateRating || e.aggregateRating["@type"] != "AggregateRating") return;
                let i = e.aggregateRating.reviewCount && e.aggregateRating.reviewCount > 0,
                    s = e.aggregateRating.ratingCount && e.aggregateRating.ratingCount > 0;
                !i && !s && delete e.aggregateRating
            })
        }
        loadFromWidget(t) {
            if (!t.usingSampleData) try {
                this.addReviewDataToSeoScripts(t.el);
                let e = t.el.closest("[itemType]");
                (!e || !e.getAttribute("itemType").match(/\/Product$/)) && (this.copySeoAttributesToProductContext(t.el), this.removeSeoAttributes(t.el)), this.removeDuplicateAggregateRatingSeoAttr()
            } catch (e) {
                this.N(e)
            }
        }
        copySeoAttributesToProductContext(t) {
            this.repairProductSchemas();
            let e = document.querySelectorAll('[itemType*="/Product"][itemscope]');
            if (e.length < 1) return this.b("Tried to copy object to optimize for SEO but could not find parent product SEO item type."), !1;
            if (e.length > 0) {
                let i = t.cloneNode(!0);
                i.style.visibility = "hidden", i.style.overflow = "hidden", i.style.height = "0", i.style.width = "0", i.removeAttribute("class"), i.removeAttribute("id"), i.removeAttribute("data-fera-widget"), i.removeAttribute("data-fera-widget"), i.querySelectorAll("[class]").forEach(s => {
                    s.removeAttribute("class"), s.removeAttribute("id")
                }), i.setAttribute("data-fera-message", "added to ensure search engines read content properly"), e[0].append(i)
            }
            return !0
        }
        repairProductSchemas() {
            let t = document.querySelectorAll('[itemType*="/Product"]:not([itemscope])');
            t.length < 1 || t.forEach(e => {
                if (e.querySelectorAll('[itemProp="name"]').length < 1) return;
                e.setAttribute("itemscope", "");
                let s = e.querySelectorAll('[itemType*="/Offer"]:not([itemscope])');
                s.length < 1 || s.forEach(a => a.setAttribute("itemscope", ""))
            })
        }
        removeDuplicateAggregateRatingSeoAttr() {
            let t = document.querySelector('[itemType*="Product"]');
            if (!t) return !1;
            let e = t.querySelectorAll('[itemType*="AggregateRating"]');
            if (e.length > 0) {
                let i;
                e.forEach(s => {
                    let a = s.parentElement.closest("[itemType]");
                    a && a.getAttribute("itemType").match(/\/Product$/) && !i ? i = s : this.removeSeoAttributes(s)
                })
            }
            return !0
        }
        addReviewDataToSeoScripts(t) {
            this.Pa(e => {
                this.Jl(t, e), e.aggregateRating && this.Kl(t, e)
            })
        }
        Pa(t) {
            let e = document.querySelectorAll('script[type="application/ld+json"]');
            if (e.length < 1) {
                this.b("Could not find any SEO script definitions.");
                return
            }
            e.forEach(i => {
                let s = i.innerHTML.replace(/[\n\t\r]/g, " ").trim();
                if (!s) return;
                let a;
                try {
                    a = JSON.parse(s)
                } catch (o) {
                    this.b("Encountered an error while trying to parse JSON for application/ld+json. Reading will be skipped.", o, i)
                }
                if (!a) {
                    this.ft("Failed to properly parse your application/ld+json. This could indicate that your site code/theme is not properly handling SEO elements. Contact our team for help.");
                    return
                }
                a instanceof Array && (a = a[0], this.Ia = !0), a["@type"] && a["@type"].match(/Product$/) && (t && t(a), this.Ia && (a = [a], this.Ia = !1), i.innerHTML = JSON.stringify(a))
            })
        }
        Jl(t, e) {
            let i = t.querySelector('[itemprop="aggregateRating"] ');
            if (!i) return;
            e.aggregateRating = e.aggregateRating || {}, e.aggregateRating["@type"] = "AggregateRating";
            let s = i.querySelector('[itemprop="ratingValue"]'),
                a = i.querySelector('[itemprop="ratingCount"]'),
                o = i.querySelector('[itemprop="reviewCount"]');
            s && s.innerText && (e.aggregateRating.ratingValue = s.innerText.trim()), a && a.innerText && (e.aggregateRating.ratingCount = a.innerText.trim()), o && o.innerText && (e.aggregateRating.reviewCount = o.innerText.trim()), e.review = Array.isArray(e.review) ? e.review : [], !e.aggregateRating.reviewCount && !e.aggregateRating.ratingCount && delete e.aggregateRating
        }
        Kl(t, e) {
            t.querySelectorAll('[itemprop="review"]').forEach(i => {
                let s = i.querySelector('[itemprop="datePublished"]') && i.querySelector('[itemprop="datePublished"]').getAttribute("content") || "",
                    a = i.querySelector('[itemprop="author"]') && i.querySelector('[itemprop="author"]').innerText || "",
                    o = i.dataset.id,
                    l = i.querySelector('[itemprop="ratingValue"]') && i.querySelector('[itemprop="ratingValue"]').innerText || "",
                    d = i.querySelector('[itemprop="description"]') && i.querySelector('[itemprop="description"]').innerText || "";
                if (!s || !a || e.review && e.review.find && e.review.find(p => p.identifier == o ? !0 : p.datePublished == s.trim() && p.author.name == a.trim())) return;
                let c = {
                    "@context": "https://schema.org/",
                    "@type": "Review",
                    identifier: o,
                    datePublished: s,
                    author: {
                        "@type": "Person",
                        name: a.trim()
                    },
                    reviewBody: d.trim(),
                    reviewRating: {
                        "@type": "Rating"
                    }
                };
                l && (c.reviewRating.ratingValue = l.trim()), c.reviewBody && e.review.push(c)
            })
        }
    };
    var br = class extends w {
        constructor(t) {
            super(t), this.La = this.e.prefix || this.e.namespace || "Fera."
        }
        reset() {
            document.cookie.split(";").map(t => t.split("=")[0]).filter(t => t.match(/^\s*Fera\./)).map(t => t.replace(/^\s*Fera\./, "")).forEach(t => this.setCookie(t, "", -1))
        }
        setCookie(t, e, i) {
            let s = "";
            if (i) {
                let d = new Date;
                d.setTime(d.getTime() + i * 24 * 60 * 60 * 1e3), s = "; expires=" + d.toUTCString()
            }
            let a = this.app.request.url.protocol === "https:",
                o = a ? "None" : "Lax",
                l = this.La + t + "=" + e + s + `; path=/; SameSite=${o}`;
            a && (l += "; Secure");
            try {
                document.cookie = l
            } catch (d) {
                if (d.message.match(/This document is sandboxed/)) return;
                throw d
            }
        }
        set(t, e, i) {
            this.setCookie(t, e, i)
        }
        getCookie(t, e) {
            e = e || null;
            let i = this.La + t + "=",
                s = null;
            try {
                s = document.cookie.split(";")
            } catch (a) {
                if (a.message.match(/This document is sandboxed/)) return e;
                throw a
            }
            for (let a = 0; a < s.length; a++) {
                let o = s[a];
                for (; o.charAt(0) == " ";) o = o.substring(1, o.length);
                if (o.indexOf(i) == 0) return o.substring(i.length, o.length)
            }
            return e
        }
        get(t, e) {
            return this.getCookie(t, e)
        }
        getCookieObject(t, e) {
            let i = this.getCookie(t, e);
            return typeof i == "string" && (i = JSON.parse(decodeURIComponent(atob(i)))), i
        }
        getObject(t, e) {
            return this.getCookieObject(t, e)
        }
        setCookieObject(t, e, i) {
            e = btoa(encodeURIComponent(JSON.stringify(e))), this.setCookie(t, e, i)
        }
        setObject(t, e, i) {
            this.setCookieObject(t, e, i)
        }
    };
    var yr = class extends w {
        load(t) {
            return Promise.all(Object.keys(t).map(e => this.Gl(e, t[e])))
        }
        get loadedStylesExternally() {
            return document.querySelectorAll("#fera_css_bundle,#fera_bundle,#fera_css").length > 0
        }
        clearCache() {
            let t = Array.from(document.querySelectorAll('[href*="/fera.css"],[src*="/fera.js"],[src*="/fera.bundle.js"]')).map(e => e.href || e.src);
            t.push(this.B("fera.css")), t.push(this.B("fera.js")), t = [...new Set(t)], t.forEach(e => e && fetch(e, {
                cache: "reload"
            })), this.Ql(), this.b("Fera asset browser cache was forced to clear.")
        }
        Ql() {
            let t = globalThis.localStorage.getItem("Fera.AssetCache.ferajs");
            if (t) try {
                let e = JSON.parse(t);
                e.url && fetch(e.url, {
                    cache: "reload"
                })
            } catch (e) {
                this.b("Legacy cache parse failure.")
            }
            globalThis.localStorage.removeItem("Fera.AssetCache.ferajs")
        }
        Gl(t, e) {
            let i = new ht(e.match(/^https?/i) ? e : this.B(e));
            if (i.ext === "css") return this.di(i, t);
            if (i.ext === "js") return this.yr(i, t);
            throw new Error(`Unknown external resource type: ${e}/${i}`)
        }
        di(t, e) {
            return this.Aa({
                type: "link",
                id: e,
                url: t,
                container: document.head,
                otherAttributes: {
                    rel: "stylesheet",
                    href: t,
                    fetchpriority: "high",
                    crossOrigin: "anonymous"
                }
            })
        }
        yr(t, e) {
            return this.Aa({
                type: "script",
                id: e,
                url: t,
                container: document.body,
                otherAttributes: {
                    async: !0,
                    src: t
                }
            })
        }
        Aa({
            type: t,
            id: e,
            url: i,
            container: s,
            prepend: a = !1,
            otherAttributes: o = {}
        }) {
            let l = `fera-${e}-${i.ext}`,
                d = document.getElementById(`fera-${e}-${i.ext}`);
            return d = d || document.head.querySelector(`[src*="${i}"],[href*="${i}"],[src*="${i.pathname}"],[href*="${i.pathname}"]`), d ? (Object.keys(o).forEach(u => {
                d[u] != o[u] && (d[u] = o[u])
            }), Promise.resolve({
                id: e,
                element: d
            })) : new Promise((u, c) => {
                let p = document.createElement(t);
                p.id = l, Object.keys(o).forEach(g => p[g] = o[g]), p.addEventListener("load", () => setTimeout(() => u({
                    id: e,
                    element: p
                }), 1)), p.addEventListener("error", () => c(new Error(`Failed to load ${i}.`))), a ? s.prepend(p) : s.appendChild(p)
            })
        }
    };

    function di(r, t = !1) {
        return r.replace(/[\s_.-]/g, " ").split(" ").map(([i, ...s], a) => a === 0 && !t ? (i || "").toLowerCase() + s.join("").toLowerCase() : (i || "").toUpperCase() + s.join("").toLowerCase()).join("")
    }
    var xr = class extends w {
        get td() {
            return {
                r: "showContentSubmitter",
                writeReview: "showContentSubmitter",
                submitContent: "showContentSubmitter",
                submitReview: "showContentSubmitter",
                review: "showContentSubmitter",
                editReview: "showContentSubmitter",
                showContentSubmission: "showContentSubmitter"
            }
        }
        get Ea() {
            return {
                locale: ["locale", "fera_locale", "feraLocale", "fera_language", "feraLanguage", "lang", "fera_lang", "feraLang"],
                designMode: ["design", "design_mode", "designMode", "fera_design", "feraDesign", "fera_design_mode", "feraDesignMode"],
                adminMode: ["admin_mode", "adminMode", "fera_admin", "feraAdmin", "fera_admin_mode", "feraAdminMode"],
                debugMode: ["debug_mode", "debugMode", "fera_debug", "feraDebug", "fera_debug_mode", "feraDebugMode"]
            }
        }
        isHttps() {
            return this.url.protocol.toString().match(/^https:?/)
        }
        triggerUrlApi() {
            let t = this.params.fera || this.params.f;
            if (t && (t = this.td[t] || t, typeof this.app[t] == "function")) try {
                t === "r" && (t = "writeReview"), this.app[t]()
            } catch (e) {
                this.N(e)
            }
        }
        loadUrlConfig() {
            let t = {};
            Object.keys(this.Ea).forEach(e => {
                for (let i of this.Ea[e])
                    if (typeof this.params[i] != "undefined") {
                        t[e] = this.params[i];
                        break
                    }
            }), this.app.configure(t)
        }
        get url() {
            let t = new URLSearchParams(globalThis.location.search).get("test_url");
            return new ht(t || this.e.url || globalThis.location.toString())
        }
        get isRoot() {
            return !!(this.path == "" || this.path == "/" || this.path.toString().match(/^\/([a-z]{2}(-[a-z]{2})?\/?)$/i))
        }
        get path() {
            return this.url.pathname
        }
        get params() {
            return this.url.params
        }
        getFeraParam(t) {
            let e = t;
            return Array.isArray(t) && (e = t.find(i => (i = `${i}`.replace(/^fera_?/i, ""), this.params[`fera_${i}`] || this.params[`fera${di(i||"",!0)}`]))), e = `${e}`.replace(/^fera_?/i, ""), this.params[`fera_${e}`] || this.params[`fera${di(e||"",!0)}`]
        }
        addParams(t = {}) {
            if (this.app.config.designMode) return;
            let e = new ht(globalThis.location.toString());
            Object.keys(t).forEach(i => {
                e.params[i] != t[i] && (e.params[i] = t[i])
            }), globalThis.history.replaceState(t, "", e.toString())
        }
        removeParams(t = {}) {
            if (this.app.config.designMode) return;
            let e = new ht(globalThis.location.toString());
            Object.keys(t).forEach(i => {
                e.params[i] == t[i] && delete e.params[i]
            }), globalThis.history.replaceState(t, "", e.toString())
        }
        hasFeraFlag(t) {
            return typeof this.getFeraParam(t) != "undefined"
        }
        isFeraFlag(t, e) {
            return Array.isArray(t) ? t.some(i => this.isFeraFlag(i, e)) : this.hasFeraFlag(t) ? H(this.getFeraParam(t)) === H(e) : !1
        }
    };
    var Cr = class extends w {
        constructor(t) {
            super(t), this.template = this.e.template
        }
        get filters() {
            return {
                default: (t, e) => t !== void 0 ? t : e,
                t: t => this.t(t)
            }
        }
        get variables() {
            return this.e.variables || {}
        }
        get varsAsStr() {
            return this.xr ? this.xr : (this.xr = Object.keys(this.variables).map(t => `const ${t} = ${this.ed(this.variables[t])};`).join(""), this.xr)
        }
        rd(t) {
            return t.split(".").reduce((e, i) => {
                if (e && e[i]) return e[i]
            }, this.variables)
        }
        render() {
            return this.template.replace(/\{%-?\s*if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*else? ?if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*else\s*-?%}(.*)\{%-?\s*endif\s*-?%}/g, (t, e, i, s, a, o) => this.Ht(e) ? i : this.Ht(s) ? a : o).replace(/\{%-?\s*if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*else? ?if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*else\s*-?%}(.*)\{%-?\s*endif\s*-?%}/g, (t, e, i, s, a) => this.Ht(e) ? i : this.Ht(s) ? a : "").replace(/\{%-?\s*if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*else\s*-?%}(.*)\{%-?\s*endif\s*-?%}/g, (t, e, i, s) => this.Ht(e) ? i : s).replace(/\{%-?\s*if\s+([^%+{}]*?)\s*-?%}(.*)\{%-?\s*endif\s*-?%}/g, (t, e, i) => this.Ht(e) ? i : "").replace(/\{\{\s*([^}]+?)\s*}}/g, (t, e) => this.sd(e))
        }
        sd(t) {
            let [e, ...i] = t.split("|").map(a => a.trim()), s = this.rd(e);
            for (let a of i) {
                let [o, ...l] = a.split(":").map(d => d.trim());
                this.filters[o] && (s = this.filters[o](s, ...l))
            }
            return s
        }
        ed(t) {
            let e = [];
            return JSON.stringify(t, (i, s) => {
                if (typeof s == "object" && s !== null) {
                    if (e.includes(s)) return;
                    e.push(s)
                }
                return s
            })
        }
        Ht(t) {
            let e = `return ${t.replace(/\s+or\s+/," || ").replace(/\s+and\s+/," && ")}`;
            return new Function(`${this.varsAsStr}; ${e}`)()
        }
    };
    var _r = class extends w {
        constructor(t = {}) {
            var e;
            super(t), this.hi = ((e = this.app.store) == null ? void 0 : e.translations) || {}
        }
        static get supportedLanguageCodes() {
            return ["en", "de", "es", "fr", "id", "it", "nl", "no", "pt", "ro", "ru", "sk", "sv", "th", "zh-TW"]
        }
        get isCurrentLocaleSupported() {
            return this.constructor.supportedLanguageCodes.includes(this.locale)
        }
        get locale() {
            let t = this.app.locale || "en";
            return ["zh", "zh-cn", "zh-tw"].includes(t.toLowerCase()) && (t = "zh-TW"), t
        }
        formatNumber(t, e = {}) {
            return new Intl.NumberFormat(this.locale, e).format(t)
        }
        t(t, e = null) {
            if (!t) return "";
            let i = this.Te[t],
                s, a;
            return typeof t != "string" && (t.toString ? t = t.toString() : t = `${t}`), i || (s = this.ad(t), i = this.Te[s]), i = i || this.Te[this.Cr(t)] || this.Te[this.Cr(t, !0)] || t, a = i, e && i.match(/\{[{%]/) && (a = this.od(i, e)), s && s != t && i == this.Te[s] && (a = this.Cr(a)), a
        }
        loadTranslations() {
            return m(this, arguments, function*(t = this.locale) {
                var e;
                if (t != "en" && ((e = this.app.store) == null ? void 0 : e.locale) !== t) {
                    if (!this.isCurrentLocaleSupported) {
                        this.b(`${t} locale not natively supported.`);
                        return
                    }
                    try {
                        let i = yield this.app.api.retrieveTranslations(t);
                        this.hi = ae(i, this.hi)
                    } catch (i) {
                        this.N(i)
                    }
                }
            })
        }
        get Te() {
            return this.hi[this.locale] || this.hi.en || {}
        }
        ad(t) {
            return t.replace(/(&amp;)/g, "&").replace(/(&lt;)/g, "<").replace(/(&gt;)/g, ">").replace(/(&quot;)/g, '"').replace(/(&#039;)/g, "'")
        }
        Cr(t, e = !1) {
            let i = t;
            return e && (i = i.replace(/&/g, "&amp;")), i.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;")
        }
        od(t, e = {}) {
            return new Cr({
                app: this.app,
                template: t,
                variables: e
            }).render()
        }
    };

    function hi() {
        var r;
        return ((r = navigator.userAgentData) == null ? void 0 : r.mobile) || globalThis.innerWidth < 575
    }
    var kr = class extends w {
        constructor(t) {
            super(t), this.data = this.e.data || {}, this.data.current_page = this.data.current_page || {}
        }
        matches(t) {
            return new Nt({
                app: this.app,
                conditions: t
            }).match(this)
        }
        get device() {
            return this.nd || (this.nd = {
                width: globalThis.screen && globalThis.screen.width,
                height: globalThis.screen && globalThis.screen.height,
                agent: navigator && navigator.userAgent,
                language: navigator && navigator.language
            })
        }
        get pageUrl() {
            var t;
            return this.ld || (this.ld = new ht((t = this.data.current_page.url) != null ? t : this.app.request.url.toString()))
        }
        get productId() {
            return this.bt || (this.bt = this.data.product_id || this.data.product.id || this.app.currentProductId)
        }
        get pageTitle() {
            var t;
            return (t = this.data.current_page.title) != null ? t : document.title
        }
        fetchValue(t, e) {
            return m(this, null, function*() {
                return this.fetchOtherValue(t, e) || (yield this.fetchLocationValue(t)) || this.fetchProductValue(t)
            })
        }
        fetchOtherValue(t, e) {
            switch (t) {
                case "request_url":
                    return this.pageUrl;
                case "request_title":
                    return this.pageTitle;
                case "request_is_root":
                    return this.app.request.isRoot;
                case "request_path":
                    return this.app.request.path;
                case "request_url_param":
                    return this.dd(e);
                case "is_mobile":
                    return hi() ? 1 : 0;
                case "is_not_mobile":
                    return hi() ? 1 : 0
            }
            return !1
        }
        fetchProductValue(t) {
            return m(this, null, function*() {
                if (t.match(/^(current_)?product_/)) {
                    let e = t.replace(/^(current_)?product_/, "");
                    if (e === "id") return this.productId;
                    if (this.d = this.d || this.data.product || (yield this.app.currentProduct), this.d) this.d instanceof R || (this.d = new R(this.d, {
                        app: this.app
                    }));
                    else if (this.productId) this.d = yield this.app.api.retrieveProduct(this.productId);
                    else return !1;
                    if (this.d.has(e)) return this.d.get(e)
                }
                return !1
            })
        }
        fetchLocationValue(t) {
            return m(this, null, function*() {
                let e = {
                    shopper_country_code: "country_code",
                    shopper_city: "city",
                    shopper_region_name: "region_name",
                    shopper_continent: "continent"
                };
                if (e[t] || t.match(/gdpr/)) {
                    if (this.ci = this.ci || (yield this.app.geoService.retrieveLocation()), this.ci[e[t]]) return this.ci[e[t]];
                    let i = this.constructor.GDPR_COUNTRY_CODES.indexOf(this.ci.country_code) !== -1;
                    if (t === "shopper_from_gdpr") return i;
                    if (t === "shopper_not_from_gdpr") return !i
                }
                return !1
            })
        }
        dd(t) {
            return typeof t.value == "undefined" ? this.pageUrl.search : this.pageUrl.params[t.param]
        }
        static get GDPR_COUNTRY_CODES() {
            return "AT|BE|BG|HR|CY|CZ|DK|EE|FI|FR|DE|GR|HU|IE|IT|LV|LT|LU|MT|NL|PL|PT|RO|SK|SI|ES|SE|GB".split("|")
        }
    };

    function ra() {
        try {
            return window.self !== window.top
        } catch (r) {
            return !0
        }
    }
    var Sr = class extends w {
        constructor(t) {
            super(t), this.hd()
        }
        hd() {
            (this.useSampleData || this.app.request.isFeraFlag(["admin", "admin_mode"], !0)) && !H(this.app.storage.get("Config.AdminMode.Enabled"), !1) ? this.adminMode = !0 : this.app.request.isFeraFlag(["admin", "admin_mode"], !1) && this.adminMode && (this.adminMode = !1)
        }
        get apiKey() {
            return this.e.apiKey || this.e.api_key || this.e.store_pk || this.e.public_key
        }
        get appInstanceId() {
            return this.e.appInstanceId || this.e.app_instance_id
        }
        get mockApi() {
            return this.e.mockApi
        }
        get cacheDisabled() {
            return ra() || this.adminMode || this.app.request.isFeraFlag("cache", !1) || this.Ci && !this.app.request.isFeraFlag("cache", !0) || this.app.request.params.fera == "clearCache"
        }
        get adminMode() {
            return this.e.admin_mode || H(this.app.storage.get("Config.AdminMode.Enabled"), !1)
        }
        set adminMode(t) {
            this.e.admin_mode = t, this.app.storage.set("Config.AdminMode.Enabled", t), this.Mo(`Admin mode ${t?"auto-enabled":"disabled"}. Caching ${t?"disabled":"enabled"}.`)
        }
        get debugMode() {
            return this.e.debugMode || this.app.request.isFeraFlag(["debug", "debug_mode"], !0) || this.devMode
        }
        get devMode() {
            return this.e.devMode || this.e.dev_mode || this.e.environment == "development"
        }
        get useSampleData() {
            return this.designMode || this.e.useSampleData || this.app.request.isFeraFlag(["sample_mode", "sample"], !0) || this.hasTestModeFlag
        }
        get hasTestModeFlag() {
            return this.e.testMode || this.app.request.isFeraFlag(["test_mode", "test"], !0)
        }
        get ui() {
            if (this.xi === "production") {
                let t = "https://cdn.fera.ai/";
                return {
                    app: "https://app.fera.ai/",
                    apiCdn: `${t}api/`,
                    api: "https://api.fera.ai/",
                    cdn: `${t}js/`
                }
            } else {
                let t = "{{ BASE_APP_URL }}/".replace(/\/\/+/, "/"),
                    e = `${t}api/`;
                return {
                    app: t,
                    apiCdn: this.e.apiUrl || e,
                    api: e,
                    cdn: `${t}js/v3/`
                }
            }
        }
        get appUrl() {
            return this.get("appUrl", this.get("app_url", this.ui.app))
        }
        get apiUrl() {
            return this.get("apiUrl", this.get("api_url", this.ui.api))
        }
        get cdnUrl() {
            return this.get("cdnUrl", this.get("cdn_url", this.ui.cdn))
        }
        get apiCdnUrl() {
            return this.get("apiCdnUrl", this.get("api_cdn_url", this.ui.apiCdn))
        }
        get baseApiCdnUrl() {
            return `${this.apiCdnUrl}`.replace(/\/$/, "") + "/v3/public"
        }
        get baseApiUrl() {
            return `${this.apiUrl}`.replace(/\/$/, "") + "/v3/public"
        }
        get designMode() {
            return this.getBool("designMode", this.getBool("design_mode", !1)) || this.app.request.isFeraFlag(["design", "design_mode"], !0)
        }
        get store() {
            return this.e.store || null
        }
        get locale() {
            var t;
            return this.get("locale", (t = this.app.store) == null ? void 0 : t.locale)
        }
        isSet(t) {
            return this.e[t] !== void 0 && this.e[t] !== null
        }
        get(t, e = null) {
            return this.isSet(t) ? this.e[t] : e
        }
        getBool(t, e = !1) {
            return H(this.get(t, e))
        }
        get autoIntegrationSelectors() {
            return this.e.autoIntegrationSelectors || {
                "after product detail price": [],
                "after product detail title": [],
                "after product section": [],
                page: [{
                    selector: "main",
                    action: "append_to"
                }, {
                    selector: "body",
                    action: "append_to"
                }],
                "add to cart button": [{
                    selector: "product-info variant-radios",
                    action: "insert_before"
                }, {
                    selector: 'form[action~="/cart/add"] .product-single__add-to-cart',
                    action: "insert_before"
                }, {
                    selector: 'form[action~="/cart/add"] button[type=submit]',
                    action: "insert_before"
                }, {
                    selector: 'form[action~="/cart/add"] input[type=submit]',
                    action: "insert_before"
                }, {
                    selector: ".product-form__cart-submit",
                    action: "insert_before"
                }, {
                    selector: ".add-to-cart",
                    action: "insert_before"
                }, {
                    selector: ".addToCart",
                    action: "insert_before"
                }, {
                    selector: ".add_to_cart",
                    action: "insert_before"
                }, {
                    selector: "#addToCart",
                    action: "insert_before"
                }, {
                    selector: "#add-to-cart",
                    action: "insert_before"
                }, {
                    selector: "#add_to_cart",
                    action: "insert_before"
                }, {
                    selector: ".add-to-cart input.button",
                    action: "insert_before"
                }, {
                    selector: ".btn-addtocart",
                    action: "insert_before"
                }],
                "first header": [{
                    selector: "h1"
                }],
                "cart form": [{
                    selector: 'form[action~="/cart"]'
                }],
                "cart footer": [{
                    selector: ".cart__footer",
                    action: "insert_before"
                }],
                "cart header": [{
                    selector: ".cart-header",
                    action: "insert_before"
                }],
                "product content": [{
                    selector: ".product__content .grid",
                    action: "insert_after"
                }, {
                    selector: ".product__content .grid .grid__item",
                    action: "append_to"
                }, {
                    selector: '[data-section-id="product-template"] .product-single + .product-single__description'
                }, {
                    selector: '[data-section-id="product-template"] .product-single'
                }, {
                    selector: ".product-page > .wrapper > .grid.product-single",
                    action: "insert_after"
                }, {
                    selector: ".grid.product-single",
                    action: "insert_after"
                }, {
                    selector: ".index-section--featured-product"
                }, {
                    selector: '[data-section-id="product"]',
                    action: "insert_after"
                }],
                "bottom of product content": [],
                "product description": [{
                    selector: " .product-single__description",
                    action: "insert_before"
                }],
                "before footer": [{
                    selector: "main section:last-of-type",
                    action: "insert_after"
                }, {
                    selector: "body > section:last-of-type",
                    action: "insert_after"
                }, {
                    selector: "main",
                    action: "append_to"
                }, {
                    selector: "footer",
                    action: "insert_before"
                }],
                footer: [{
                    selector: '[data-section-id="footer"] .site-footer__content',
                    action: "insert_after"
                }, {
                    selector: "footer > .site-footer__linklist",
                    action: "insert_after"
                }, {
                    selector: "footer .grid-uniform",
                    action: "insert_before"
                }, {
                    selector: "footer .footer__content",
                    action: "insert_before"
                }, {
                    selector: "footer .hr--small",
                    action: "insert_before"
                }, {
                    selector: "footer .site-footer__bottom",
                    action: "insert_before"
                }, {
                    selector: "footer .flex-footer",
                    action: "insert_before"
                }, {
                    selector: '[data-section-id="footer"] .grid:last-child',
                    action: "insert_before"
                }, {
                    selector: "footer .footer__blocks-wrapper",
                    action: "insert_before"
                }]
            }
        }
        update(t = {}) {
            t.autoIntegrationSelectors && (this.e.autoIntegrationSelectors = ae(this.autoIntegrationSelectors, t.autoIntegrationSelectors, {
                prependArray: !0
            }), delete t.autoIntegrationSelectors), this.e = n(n({}, this.e), t)
        }
        set(t, e) {
            this.e[t] = e
        }
        has(t, e = !0) {
            return typeof this.e[t] == "undefined" || this.e[t] === null ? !1 : e && !!this.e[t]
        }
    };
    var Mr = class extends w {
        constructor(t) {
            super(t), this.j = {
                0: {}
            }, this.refresh = I(() => this.refreshNow(), 10), this.cd(), this.detectedTextDirection == "rtl" && this.addToRoot("--txt-direction: rtl")
        }
        get detectedTextDirection() {
            return this.ud || (this.ud = this.fd())
        }
        convertCssClassToCssVariable(t, e, i = null) {
            let s = document.createElement("div");
            s.classList.add(t), s.style.display = "none", (document.querySelector("body > main") || document.body).append(s);
            let o = getComputedStyle(s)[e];
            return s.remove(), !o || o === "none" ? !1 : (i = i || `--${ei(e)}`, i.match(/^--/) || (i = `--${i}`), this.addToRoot(`${i}: ${o}`), !0)
        }
        addToRoot(t, e = !1) {
            t = t.replace(/\s*;\s*$/, ""), this._r = this._r || {}, this._r[t] = t, this.update({
                code: "root",
                content: `.fera { ${Object.values(this._r).join("; ")}; }`,
                priority: 0,
                now: e
            })
        }
        add({
            code: t,
            content: e,
            priority: i,
            now: s = !1
        }) {
            this.j[i] = this.j[i] || {}, e = `${this.j[i][t]||""} ${e}`, this.update({
                code: t,
                content: e,
                priority: i,
                now: s
            })
        }
        update({
            code: t = null,
            content: e,
            priority: i = 10,
            now: s = !1
        }) {
            let a = e;
            if (e instanceof M && (a = this.convertModelToCss(e), t = t || e.cssClassName), !t && this.Jt) throw new Error("CSS must have a code or the model must implement cssClassName");
            return this.j[i] = this.j[i] || {}, this.j[i][t] = a || "", s ? this.refreshNow() : this.refresh(), this
        }
        remove(t) {
            let e = !1;
            Object.keys(this.j).forEach(i => {
                this.j[i][t] && (delete this.j[i][t], e = !0)
            }), e && this.refreshNow()
        }
        refreshNow() {
            let t = (this.generateCss() || "").trim();
            (this.Ut || t) && (this.Ba = this.generateCss(), this.element.innerHTML = `/* Generated by Fera.js: */
${this.Ba}`)
        }
        generateCss() {
            return Object.keys(this.j).sort((e, i) => e - i).map(e => Object.keys(this.j[e]).map(i => this.j[e][i]).join(`
`)).join(`
`)
        }
        get element() {
            return this.Ut || (document.getElementById("fera-css") ? this.Ut = document.getElementById("fera-css") : (this.Ut = document.createElement("style"), this.Ut.id = "fera-css", document.body.appendChild(this.Ut))), this.Ut
        }
        convertModelToCss(t) {
            let e = t.designVars || t.get("design_vars", {}),
                i = this.Ci ? `
` : " ",
                s = "",
                a = Object.keys(e).map(o => {
                    let l = o.match(/^--/) ? o : `--${ei(o)}`;
                    return e[o] ? `${l}: ${e[o]} !important;` : ""
                }).filter(o => !!o).join(i);
            return a && t.cssClassName && (s += `.${t.cssClassName} {${i}${a}${i}}${i}`), t.get("custom_css", "") && (s += `
/* Custom CSS >> */
${t.get("custom_css","")}/* << Custom CSS */`), s
        }
        get css() {
            return this.Ba || ""
        }
        cd() {
            let t = getComputedStyle(document.documentElement).getPropertyValue("font-size") || "16px",
                e = parseFloat(t) / 16;
            e !== 1 && this.addToRoot(`--font-scale: ${e}`)
        }
        fd() {
            let t = document.querySelector("p,a,div,body");
            return t && getComputedStyle(t).direction == "rtl" ? "rtl" : "ltr"
        }
    };
    var Rr = class extends w {
        constructor(t) {
            super(t), this.ht = [], this.pd = [], this.md(this.e.pushBuffer)
        }
        flush() {
            for (this.gd(); this.ht.length > 0;) {
                let t = this.ht.shift();
                this.pd.push(t), this.app.push(...t)
            }
        }
        get V() {
            return {
                theme: "setTheme",
                product: "setCurrentProduct",
                store: "setStore",
                config: "configure",
                ready: ["once", "ready"]
            }
        }
        get Oa() {
            return ["configure", "setStore", "setCurrentProduct", "setTheme"]
        }
        md(t) {
            if (!t) return;
            let e = null,
                i = [];
            t.forEach(s => {
                if (s && typeof s == "object" && (s.method || s.action)) {
                    let o = s.method || s.action;
                    delete s.method, delete s.action;
                    let l = s.data ? s.data : s;
                    this.ht.push([o, l]);
                    return
                }
                let a = typeof s == "object" ? s.method || s.action : s;
                this.vd(a, s) ? (e && this.ht.push([e, ...i]), e = a, i = s.args || [s.data]) : e && this.wd(e, s) ? i.push(s) : (e && this.ht.push([e, ...i]), e = s, i = [])
            }), e && this.ht.push([e, ...i])
        }
        wd(t, e) {
            return typeof t != "string" || this.V[t] && Array.isArray(this.V[t]) && this.V[t][0] === e || this.V[e] && Array.isArray(this.V[e]) && this.V[e][0] === t ? !0 : typeof this.app[e] != "function" && !this.V[e]
        }
        vd(t, e) {
            return typeof t != "string" || typeof e != "object" ? !1 : typeof this.app[t] == "function" || this.V[t]
        }
        bd() {
            this.ht = this.ht.map(t => {
                let e = t[0];
                return this.V[e] && (t.shift(), (Array.isArray(this.V[e]) ? this.V[e] : [this.V[e]]).reverse().forEach(i => {
                    t.unshift(i)
                })), t
            })
        }
        gd() {
            this.bd(), this.ht.sort((t, e) => {
                let i = this.Oa.indexOf(t[0]),
                    s = this.Oa.indexOf(e[0]);
                return i < 0 ? 1 : s < 0 ? -1 : i - s
            })
        }
    };
    var Tr = class extends mt {
        get options() {
            return h(n({}, super.options), {
                summaries_visible: !0,
                store_replies_visible: !0,
                customer_avatars_visible: !0,
                customer_media_visible: !0,
                customer_locations_visible: !0,
                products_visible: !0
            })
        }
        Dt() {
            return super.Dt("30xs100")
        }
        ot() {
            return super.ot("500")
        }
    };
    var $r = class extends it {
        constructor(t) {
            super(h(n({}, t), {
                allowOutsideClick: !0
            })), this.addClass("fera-review-modal"), this.J = {
                fera: "showReview",
                fera_review: this.e.review.id
            }, this.content = new Tr(this.i)
        }
        get i() {
            return h(n({}, super.i), {
                showProduct: !0,
                review: this.e.review
            })
        }
    };
    var Ue = class extends f {
        constructor(t) {
            super(t), this.widgetModel = this.e.widgetModel, !this.widgetModel && this.app.widgetLoader && (this.widgetModel = this.app.widgetLoader.factory.constructor.initModelFromComponent(this, this.e.options || {}, t)), this.loadElementOptions(), this.kr(), this.on("render:complete", () => {
                this.app.trigger("widget.render:complete", this), this.yd()
            }), this.widgetModel.targetSection && this.addClass(`fera-widget-targetSection--${di(this.widgetModel.targetSection)}`)
        }
        yd() {
            let t = this.app.request.getFeraParam("widget");
            !t || t != this.widgetModel.id && t != this.widgetModel.type || (this.isVisible ? this.scrollIntoView({
                behavior: "auto"
            }) : this.ft("Attempted to scroll to invisible widget."))
        }
        kr() {
            this.addClass(`fera fera-widget ${this.widgetModel.constructor.cssClassName}`), this.widgetModel.cssClassName && this.widgetModel.cssClassName != this.widgetModel.constructor.cssClassName && this.addClass(this.widgetModel.cssClassName)
        }
        get canBeRemovedViaFera() {
            return !(this.el && this.el.dataset && this.el.dataset.editor || this.widgetModel && this.widgetModel.tagIntegrated || this.widgetModel && this.widgetModel.selectorIntegrated && this.widgetModel.installationSettings.action == "replace" || this.el && this.el.tagName && this.el.tagName.match(/fera-/))
        }
        scrollIntoView({
            behavior: t = "smooth",
            block: e = "nearest"
        } = {}) {
            this.Sr = !0;
            let i = this.el || this.e.el || this.e.container;
            i && i.scrollIntoView({
                behavior: t,
                block: e
            })
        }
        renderAsync() {
            return m(this, null, function*() {
                this.se = "queued";
                let t = this.e.container || this.e.el || this.el,
                    e = ["insert_after"].includes(this.e.insertionMode);
                return t && !this.app.config.designMode && !this.app.config.adminMode && (globalThis.addEventListener("mousemove", () => this.rendered && !this.destroyed && (this.Sr = !0)), document.addEventListener("scroll", () => this.rendered && !this.destroyed && (this.Sr = !0)), this.fi.add(this), yield ge(() => {
                    let i = globalThis.scrollY + globalThis.innerHeight,
                        s = t.getBoundingClientRect().top;
                    return e && (s += t.offsetHeight), this.Sr || i >= s
                }, {
                    timeout: 5e3,
                    checkInterval: 25
                }), this.fi.delete(this)), this.render()
            })
        }
        destroy() {
            this.e.container && this.e.container.feraWidgets && (this.e.container.feraWidgets = this.e.container.feraWidgets.filter(t => t != this)), super.destroy()
        }
        get fi() {
            return globalThis.fera.widgetsAwaitingRender = globalThis.fera.widgetsAwaitingRender || new Set, globalThis.fera.widgetsAwaitingRender
        }
        l() {
            super.l(), this.app.trigger("widget.render:before", this)
        }
        get usingSampleData() {
            return this.app.config.useSampleData
        }
        loadElementOptions() {
            !this.el || !this.el.isFera || (this.widgetModel.loadDataFromElement(this.el), this.refreshView())
        }
        r() {
            super.r(), this.xd(), this.Cd()
        }
        remove() {
            var t, e;
            super.remove(), this.fi.delete(this), (e = (t = this.e.container) == null ? void 0 : t.feraWidgets) != null && e.includes(this) && (this.e.container.feraWidgets = this.e.container.feraWidgets.filter(i => i.widgetModel.id != this.widgetModel.id)), this.app.cssService.remove(this.widgetModel.cssClassName)
        }
        Cd() {
            this.app.cssService.update({
                code: this.widgetModel.cssClassName,
                content: this.widgetModel,
                priority: 30,
                now: !0
            })
        }
        get i() {
            return h(n({}, super.i), {
                widgetModel: this.widgetModel,
                useSampleData: this.usingSampleData
            })
        }
        xd() {
            this.q("[title]", t => {
                t.getAttribute("title") && (t.feraTooltip = new J({
                    app: this.app,
                    target: t
                }))
            })
        }
        get options() {
            return this.widgetModel.options
        }
    };
    var It = class extends Ue {
        kr() {
            super.kr(), this.addClass("fera-block-widget fera-container"), this.toggleClass("fera-block-widget--withBorder", !!this.za), this.toggleClass("fera-block-widget--withBg", !!this._d)
        }
        get za() {
            return this.widgetModel.is("border_visible")
        }
        get _d() {
            return this.widgetModel.is("bg_visible")
        }
        get ja() {
            return this.options.header_visible && this.options.header ? `<h1>${this.t(this.options.header)}</h1>` : ""
        }
        get options() {
            return n(n({}, this.L), this.e.options || (this.widgetModel ? this.widgetModel.getData() : {}))
        }
        get L() {
            return {
                header_visible: !0
            }
        }
    };
    var Pr = class extends f {
        constructor(t) {
            super(h(n({}, t), {
                onClick: e => {
                    e.preventDefault(), this.e.collection.loadPage(this.e.index + 1)
                }
            }))
        }
        get s() {
            return `<a href="#" class="fera-pagination-number ${this.e.isActive?"fera-pagination-number--current":""}">${this.e.index+1}</a>`
        }
    };
    var Ir = class extends f {
        constructor(t) {
            super(t), this.collection = this.e.collection, this.prevIcon = new zt(h(n({}, this.i), {
                direction: "left"
            })), this.nextIcon = new zt(h(n({}, this.i), {
                direction: "right"
            }))
        }
        nextPage() {
            this.collection.loadNextPage()
        }
        previousPage() {
            this.collection.loadPrevPage()
        }
        a() {
            super.a(), this.clearChildren(), this.kd(), this.Mr > 0 && this.Sd(), this.toggleVisible(this.Mr > 0), this.Ai('[data-fera-action="previousPage"]', this.collection.currentPage > 1), this.Ai('[data-fera-action="nextPage"]', this.collection.currentPage < this.collection.pageCount)
        }
        kd() {
            this.Mr = 0, this.Rr = 0, this.Zt = [];
            for (let t = 0; t < this.collection.pageCount; t++) {
                let e = t + 1 === this.collection.currentPage;
                e && (this.Rr = t), this.Zt.push(new Pr(h(n({}, this.i), {
                    isActive: e,
                    index: t,
                    collection: this.collection
                }))), this.Mr += 1
            }
            return this.Zt
        }
        Sd() {
            let t = !1,
                e = !1;
            for (let i = 0; i < this.Zt.length; i++) {
                let s = this.Zt[i];
                i < this.Rr - this.Va && i !== 0 ? t || (this.Da(), t = !0) : i > this.Rr + this.Va && i !== this.Zt.length - 1 ? e || (this.Da(), e = !0) : (s.toggleClass("fera-pagination-number--first", i === 0), s.toggleClass("fera-pagination-number--last", i === this.Zt.length - 1), this.addChild(s))
            }
        }
        Da() {
            this.addChild(new f(h(n({}, this.i), {
                tpl: '<a href="#" class="fera-pagination-ellipse" onclick="return false;">...</a>'
            })))
        }
        get Va() {
            return this.Go ? 1 : 2
        }
        get s() {
            return `<div aria-label="Pagination" class="fera-pagination">
    <a href="#" class="fera-pagination-prev" data-fera-action="previousPage"><svg data-fera-component="prevIcon"></svg></a>
    <span data-fera-child-container class="fera-pagination-numbers"></span>
    <a href="#" class="fera-pagination-next" data-fera-action="nextPage"><svg data-fera-component="nextIcon"></svg></a>
</div>`
        }
    };
    var Lr = class extends gt {
        constructor(t) {
            var e, i;
            super(n({
                type: "secondary",
                size: "block",
                c: "fera-reviews-showMore-btn"
            }, t)), this.ge = this.ge || this.t("Show more"), this.e.onClick = this.e.onClick || this.showMore.bind(this), this.pi = this.e.collection, (e = this.pi) == null || e.on("load:before", () => {
                this.disable(), this.P()
            }), (i = this.pi) == null || i.on("load:after", () => {
                this.enable(), this.C()
            })
        }
        showMore() {
            this.pi.loadMore()
        }
        a() {
            super.a(), this.toggleVisible(this.pi.hasMore)
        }
    };
    var Ze = class extends f {
        constructor(t) {
            super(t), this.widgetModel = this.e.widgetModel, this.collection = this.e.collection, this.collection.on("load", () => this.refreshView()), this.paginator = this.newPaginator, this.addChild(this.paginator)
        }
        get newPaginator() {
            return this.e.usePagination ? new Ir(this.i) : new Lr(h(n({}, this.i), {
                type: this.widgetModel.get("show_more_style", "secondary")
            }))
        }
        get s() {
            return '<div class="fera-widget-footer" data-fera-widget-section="footer"></div>'
        }
        get i() {
            return h(n({}, super.i), {
                widgetModel: this.widgetModel,
                collection: this.collection
            })
        }
        a() {
            super.a(), this.e.usePagination || this.toggleVisible(this.collection.hasMore)
        }
    };
    var ot = function(r) {
        return this.$e = [], this.U = [], this.A = null, this.S = null, this.R = 0, this.Tr = null, this.g = null, this.Na = null, this.Yt = null, this.conf = {
            baseWidth: 255,
            gutterX: null,
            gutterY: null,
            gutter: 10,
            container: null,
            minify: !0,
            ultimateGutter: 5,
            surroundingGutter: !0,
            direction: "ltr",
            wedge: !1,
            minCols: 1
        }, this.init(r), this
    };
    ot.prototype.init = function(r) {
        for (var t in this.conf) r[t] != null && (this.conf[t] = r[t]);
        if ((this.conf.gutterX == null || this.conf.gutterY == null) && (this.conf.gutterX = this.conf.gutterY = this.conf.gutter), this.g = this.conf.gutterX, this.Na = this.conf.gutterY, this.A = typeof this.conf.container == "object" && this.conf.container.nodeName ? this.conf.container : document.querySelector(this.conf.container), !this.A) throw new Error("Container not found or missing");
        var e = this.resizeThrottler.bind(this);
        window.addEventListener("resize", e), this.Tr = function() {
            window.removeEventListener("resize", e), this.Yt != null && (window.clearTimeout(this.Yt), this.Yt = null)
        }, this.layout()
    };
    ot.prototype.reset = function() {
        this.$e = [], this.U = [], this.S = null, this.R = this.A.clientWidth;
        var r = this.conf.baseWidth;
        this.R < r && (this.R = r, this.A.style.minWidth = r + "px"), this.getCount() == 1 ? (this.g = this.conf.ultimateGutter, this.S = 1) : this.R < this.conf.baseWidth + 2 * this.g ? this.g = 0 : this.g = this.conf.gutterX, this.S && (this.S = Math.max(this.conf.minCols, this.S))
    };
    ot.prototype.getCount = function() {
        return this.conf.surroundingGutter ? Math.floor((this.R - this.g) / (this.conf.baseWidth + this.g)) : Math.floor((this.R + this.g) / (this.conf.baseWidth + this.g))
    };
    ot.prototype.computeWidth = function() {
        var r;
        return this.conf.surroundingGutter ? r = (this.R - this.g) / this.S - this.g : r = (this.R + this.g) / this.S - this.g, Math.round(Number.parseFloat(r))
    };
    ot.prototype.layout = function() {
        if (!this.A) {
            console.error("Container not found");
            return
        }
        this.reset(), this.S == null && (this.S = Math.max(this.conf.minCols, this.getCount()));
        for (var r = this.computeWidth(), t = 0; t < this.S; t++) this.U[t] = 0;
        for (var e = this.A.children, i = 0; i < e.length; i++) e[i].style.width = r + "px", this.$e[i] = e[i].clientHeight;
        var s;
        if (this.conf.direction == "ltr" ? s = this.conf.surroundingGutter ? this.g : 0 : s = this.R - (this.conf.surroundingGutter ? this.g : 0), this.S > this.$e.length) {
            var a = this.$e.length * (r + this.g) - this.g;
            this.conf.wedge === !1 ? this.conf.direction == "ltr" ? s = (this.R - a) / 2 : s = this.R - (this.R - a) / 2 : this.conf.direction == "ltr" || (s = this.R - this.g)
        }
        for (var o = 0; o < e.length; o++) {
            var l = this.conf.minify ? this.getShortest() : this.getNextColumn(o),
                d = 0;
            (this.conf.surroundingGutter || l != this.U.length) && (d = this.g);
            var u;
            this.conf.direction == "ltr" ? u = s + (r + d) * l : u = s - (r + d) * l - r;
            var c = this.U[l];
            e[o].style.transform = "translate3d(" + Math.round(u) + "px," + Math.round(c) + "px,0)", this.U[l] += this.$e[o] + (this.S > 1 ? this.conf.gutterY : this.conf.ultimateGutter)
        }
        this.conf.minCols == this.S ? this.A.classList.add("minCols") : this.A.classList.remove("minCols"), this.A.style.height = this.U[this.getLongest()] - this.Na + "px"
    };
    ot.prototype.getNextColumn = function(r) {
        return r % this.U.length
    };
    ot.prototype.getShortest = function() {
        for (var r = 0, t = 0; t < this.S; t++) this.U[t] < this.U[r] && (r = t);
        return r
    };
    ot.prototype.getLongest = function() {
        for (var r = 0, t = 0; t < this.S; t++) this.U[t] > this.U[r] && (r = t);
        return r
    };
    ot.prototype.resizeThrottler = function() {
        this.Yt || (this.Yt = setTimeout(function() {
            this.Yt = null, this.A.clientWidth != this.R && this.layout()
        }.bind(this), 33))
    };
    ot.prototype.destroy = function() {
        typeof this.Tr == "function" && this.Tr();
        for (var r = this.A.children, t = 0; t < r.length; t++) r[t].style.removeProperty("width"), r[t].style.removeProperty("transform");
        this.A.style.removeProperty("height"), this.A.style.removeProperty("min-width")
    };
    var Ar = class extends mt {
        constructor(t) {
            super(t), this.addClass("fera-row")
        }
        get s() {
            return `<div ${this.Je} tabindex="-1">
    <div class="fera-col fera-review-customer-col fera-hidden-xs">${this.me}</div>
    <div class="fera-col fera-review-content-col fera-review-content">
        ${this.Ye}
        ${this.Ze}
        ${this.ot("170xs450")}
        ${this.Xe}
        <div data-fera-component="customerName" class="fera-visible-xs-flex"></div>
        ${this.options.customer_locations_visible?`<div class="fera-customer-display-location fera-visible-xs-flex">${this.customer.get("display_location","")}</div>`:""}
        ${this.Vt("130xs300")}
        ${this.Dt("50")}
    </div>
</div>`
        }
    };
    var Er = class extends f {
        constructor(t) {
            super(t), this.Pe = {
                collection: this.e.collection.range
            }, Object.keys(this.Pe.collection).forEach(e => this.Pe.collection[e] = this.formatNumber(this.Pe.collection[e]))
        }
        get s() {
            return `<span class="fera-reviews-body-top-countText">
    <span class="fera-reviews-body-top-countText--long">${this.t("Showing {{ collection.from }} - {{ collection.to }} of {{ collection.total }} review{% if collection.total != 1 %}s{% endif %}.",this.Pe)}</span>
    <span class="fera-reviews-body-top-countText--short">${this.t("{{ collection.from }} - {{ collection.to }} of {{ collection.total }} review{% if collection.total != 1 %}s{% endif %}",this.Pe)}</span>
</span>`
        }
    };
    var Br = class extends f {
        constructor(t) {
            super(t), this.collection = this.e.collection
        }
        r() {
            super.r(), this.dropdown = this.o("[data-fera-sort-select]"), this.collection.sortBy && (this.dropdown.value = this.collection.sortBy), this.dropdown.addEventListener("change", () => this.collection.sort(this.dropdown.value))
        }
        get s() {
            return `<div class="fera-reviews-body-top-sort">
  <label class="fera-reviews-body-top-sort-caption" for="fera-reviews-sort-dropdown${this.k()}">${this.t("Sort By:")}</label>&nbsp;<!-- Only want a single space between these
  --><select class="fera-reviews-body-top-sort-dropdown fera--clickable" id="fera-reviews-sort-dropdown${this.k()}" data-fera-sort-select>
    <option value="quality:desc">${this.t("Highest Quality")}</option>
    <option value="media:desc">${this.t("Photos &amp; Videos")}</option>
    <option value="rating:desc">${this.t("Highest Rating")}</option>
    <option value="rating:asc">${this.t("Lowest Rating")}</option>
    <option value="created_at:desc">${this.t("Most Recent")}</option>
    <option value="created_at:asc">${this.t("Oldest")}</option>
  </select>
</div>`
        }
    };
    var Or = class extends f {
        constructor(t) {
            super(t), this.widgetModel = this.e.widgetModel, this.sortBy = new Br(this.i)
        }
        get collection() {
            return this.e.collection
        }
        get i() {
            return h(n({}, super.i), {
                widgetModel: this.widgetModel,
                collection: this.e.collection
            })
        }
        r() {
            super.r(), this.Md = this.o("[data-fera-count-text-container]"), this.a()
        }
        a() {
            super.a(), this.countText && this.countText.remove(), this.countText = new Er(this.i), this.Md.append(this.countText.render())
        }
        get s() {
            return `<div class="fera-row fera-reviews-body-top">
  <div class="fera-col fera-reviews-body-top-left" data-fera-count-text-container>
  </div>
  <div class="fera-col fera-reviews-body-top-right">
    <span data-fera-component="sortBy"></span>
  </div>
</div>`
        }
    };
    var Ye = class extends f {
        constructor(t) {
            if (super(t), this.widgetModel = this.e.widgetModel, this.reviews = this.collection = this.e.collection, this.addReviews(this.collection), this.collection.on("load:more", e => this.addReviews(e)), this.collection.on("load:page reload", e => this.setReviews(e)), this.collection.on("sort:before filter:before", () => this.P()), this.collection.on("sort:after filter:after", () => this.C()), !this.$r) throw new Error("Review Widget BodyComponent#_reviewComponentClass must exist.");
            this.top = new Or(h(n({}, this.i), {
                collection: this.collection
            }))
        }
        setReviews(t) {
            this.clearChildren(), this.addReviews(t)
        }
        addReviews(t) {
            t.forEach(e => this.addChild(new this.$r(h(n({}, this.i), {
                review: e
            })))), this.refreshView(), this.trigger("reviews.render:after")
        }
        a() {
            super.a(), this.top.toggleVisible(this.collection.totalCount > 1), this.Ai(".fera-reviews-body-items", this.collection.totalCount > 0)
        }
        get i() {
            return h(n({}, super.i), {
                widgetModel: this.widgetModel,
                showProduct: this.e.showProducts,
                forProduct: this.e.forProduct,
                includeSeoAttributes: this.e.includeSeoAttributes
            })
        }
        get $r() {
            return Ar
        }
        get s() {
            return `<div class="fera-reviews-body">
  ${this.widgetModel.is("sortable")?'<div data-fera-component="top"></div>':""}
  <div class="fera-reviews-body-items" data-fera-child-container>
  </div>
</div>`
        }
    };
    var zr = class extends Te {
        constructor(t) {
            super(t), this.lightbox = new pt({
                app: this.app,
                media: this.media,
                showReview: !1
            })
        }
        ne(t) {
            return h(n({}, super.ne(t)), {
                onClick: e => this.Rd(e)
            })
        }
        Rd(t) {
            this.lightbox.show(t.media)
        }
    };
    var jr = class extends mt {
        constructor(t) {
            super(n({
                openModalOnClick: !0
            }, t)), this.media = new zr({
                app: this.app,
                review: this.review,
                media: this.review.media,
                widgetModel: this.widgetModel
            })
        }
        get me() {
            return `<div data-fera-component="customerName"></div>${this.Td}`
        }
        get Td() {
            return !this.options.customer_locations_visible || !this.customer.get("display_location", "") ? "" : `<div class="fera-customer-display-location">${this.customer.get("display_location")}</div>`
        }
        get s() {
            return `<div ${this.Je} tabindex="-1">
    ${this.Xe}
    <div class="fera-review-content">
        ${this.Ye}
        ${this.Ze}
        ${this.ot("72")}
        ${this.me}
        ${this.Vt("40")}
    </div>
    ${this.Dt("15")}
</div>`
        }
    };
    var Vr = class extends Ye {
        constructor(t) {
            super(t), this.Lt = I(this.yt, 50), this.addClass(`minCols--${this.e.widgetModel.get("min_cols",2)}`)
        }
        get i() {
            return h(n({}, super.i), {
                on: {
                    resize: () => this.Lt()
                }
            })
        }
        get $r() {
            return jr
        }
        a() {
            super.a(), this.Pr()
        }
        h() {
            super.h(), setTimeout(() => this.yt(), 250), setTimeout(() => this.yt(), 500), setTimeout(() => this.yt(), 1e3), setTimeout(() => this.yt(), 2500), setInterval(() => this.yt(), 5e3)
        }
        yt() {
            this.masonry && this.masonry.layout()
        }
        Pr() {
            this.masonry ? this.Lt() : (this.masonry = new ot({
                container: this.Ne,
                gutter: this.Fa,
                ultimateGutter: this.Fa,
                baseWidth: this.$d,
                surroundingGutter: !1,
                minCols: this.widgetModel.minCols || 1
            }), globalThis.addEventListener("resize", () => this.rendered && !this.destroyed && this.Lt()))
        }
        get Fa() {
            return 17
        }
        get $d() {
            return {
                1: 400,
                2: 350,
                3: 300
            }[this.reviews.length] || 250
        }
    };
    var Dr = class extends f {
        constructor(t) {
            super(n({
                filterVisible: !0,
                filterCollapsible: !0,
                filterOpenByDefault: !1
            }, t)), this.qa = this.e.filterVisible, this.Ir = this.e.filterCollapsible, this.Pd = this.e.filterOpenByDefault, this.Id(), this.toggleIcon = new zt({
                app: this.app,
                direction: this.toggleIconDirection
            })
        }
        get toggleIconDirection() {
            return this.filterIsOpen ? "up" : "down"
        }
        a() {
            super.a(), (!this.qa || !this.Ir) && this.hide()
        }
        Id() {
            this.filterIsOpen = this.qa && (!this.Ir || this.Pd && this.Ir)
        }
        toggleRatingSummary() {
            this.filterIsOpen = !this.filterIsOpen, this.toggleClass("fera-ratingSummary-toggle--open", this.filterIsOpen), this.toggleClass("fera-ratingSummary-toggle--close", !this.filterIsOpen), this.toggleIcon.changeCaretDirection(this.toggleIconDirection), this.trigger("toggle", this.filterIsOpen), this.refreshView()
        }
        get s() {
            return `<div class="fera-ratingSummary-toggle">
  <a href="#" aria-label="${this.t("Toggle rating summary")}" class="fera-ratingSummary-toggle-icon" data-fera-component-container="toggleIcon" data-fera-action="toggleRatingSummary"></a>
</div>`
        }
    };
    var ie = class extends f {
        constructor(t) {
            super(n({
                includeSeoAttributes: !1,
                showRatingNumber: !1,
                short: !0,
                long: !1,
                responsive: !1,
                rating: {
                    count: 0,
                    average: 0
                },
                hideCount: !1
            }, t)), this.setRating(this.e.rating), this.stars = new Ht({
                app: this.app,
                value: this.rating.average,
                includeSeoAttributes: this.e.includeSeoAttributes
            })
        }
        set isClickable(t) {
            this.toggleClass("fera-averageRating--clickable", t)
        }
        get isClickable() {
            return this.hasClass("fera-averageRating--clickable")
        }
        get Ie() {
            return `<span ${this.e.includeSeoAttributes?'itemprop="reviewCount"':""} data-fera-rating-count="${this.rating.count}"
    class="fera-averageRating-count-total" data-fera-rating-count-number
    data-value="${this.rating.count}">${this.formatNumber(this.rating.count)}</span>`
        }
        get Lr() {
            return parseFloat(this.rating.average).toFixed(1)
        }
        a() {
            super.a(), this.stars.setValue(this.rating.average)
        }
        setRating(t) {
            this.rating = t, this.refreshView()
        }
        get Ar() {
            return this.e.showRatingNumber ? `<span ${this.e.includeSeoAttributes?'itemprop="ratingValue"':""}
class="fera-averageRating-average-number ${this.e.responsive?"fera-hidden-xxs":""}"
            data-value="${this.rating.average||0}">${this.rating.count>0?this.Lr:""}</span>` : ""
        }
        get Wa() {
            let t = {
                average: this.rating.average,
                count: this.rating.count,
                formatted_count: this.Ie
            };
            return this.t("{{ formatted_count }} review{% if count != 1 %}s{% endif %}", t)
        }
        get Ld() {
            return this.e.hideCount ? "" : this.e.responsive ? `<div class="fera-averageRating-count-str fera-hidden-xs">${this.Wa}</div>
      <div class="fera-averageRating-count-str fera-averageRating-count-str--min fera-visible-xs">${this.Ie}</div>` : this.e.long ? `<div class="fera-averageRating-count-str">${this.Wa}</div>` : `<div class="fera-averageRating-count-str fera-averageRating-count-str--min">${this.Ie}</div>`
        }
        get s() {
            return `<div class="fera-averageRating" ${this.e.includeSeoAttributes?'itemscope itemtype="https://schema.org/AggregateRating" itemprop="aggregateRating"':""}>
  <div class="fera-averageRating-average">
    ${this.Ar}
    <div class="fera-averageRating-average-stars" data-fera-component="stars"></div>
  </div>
  <div class="fera-averageRating-count">
    ${this.Ld}
    <span ${this.e.includeSeoAttributes?'itemprop="ratingCount"':""} class="fera--srOnly">${this.rating.count||"0"}</span>
  </div>
</div>`
        }
    };
    var Nr = class extends f {
        constructor(t) {
            super(n({
                includeSeoAttributes: !1,
                rating: 0,
                percentage: 0,
                frequency: 0,
                totalFrequency: 0,
                fullWidth: !1,
                onClick: () => this.filter()
            }, t)), this.rating = this.e.rating, this.collection = this.e.collection, this.frequencyElement = null, this.percentageElement = null, this.ratingStar = new $e({
                app: this.app,
                value: this.rating,
                showRatingDesc: !0
            }), this.collection.on("filter:after", () => this.refreshView())
        }
        r() {
            super.r(), this.frequencyElement = this.o(".fera-ratingSummary-ratingItem-histogram-frequency-content .fera-number"), this.captionText = this.o(".fera-ratingSummary-ratingItem-histogram-frequency-content .fera-text"), this.percentageElement = this.o(".fera-ratingSummary-ratingItem-histogram-bar-content"), this.startAnimation(), this.percentageElement.addEventListener("animationend", () => {
                this.isAnimating = !1, this.removeClass("fera-ratingSummary-ratingItem--animating"), this.addClass("fera-ratingSummary-ratingItem--animated")
            }), this.percentageElement.addEventListener("animationstart", () => {
                this.isAnimating = !0, this.removeClass("fera-ratingSummary-ratingItem--animated")
            })
        }
        a() {
            var t;
            super.a(), this.toggleClass("fera-ratingSummary-ratingItem--with-caption", ((t = this.app.store) == null ? void 0 : t.locale) == "en"), this.Ha()
        }
        stopAnimation() {
            this.isAnimating = !1, this.removeClass("fera-ratingSummary-ratingItem--animating"), this.removeClass("fera-ratingSummary-ratingItem--animated")
        }
        startAnimation() {
            if (this.isAnimating) return !1;
            this.addClass("fera-ratingSummary-ratingItem--animating");
            let {
                frequency: t
            } = this.e;
            if (this.frequencyElement.textContent = 0, this._i || t <= 0) return this.frequencyElement.textContent = t, !0;
            this.animateNumberCount({
                element: this.frequencyElement,
                start: 0,
                end: t,
                duration: 300
            })
        }
        animateNumberCount({
            element: t,
            start: e,
            end: i,
            duration: s
        }) {
            let a = Math.max(1, Math.floor(i / 100)),
                o = s / Math.max(1, Math.floor(i / a)),
                l = e,
                d = setInterval(() => {
                    l < i ? (l += a, t.textContent = this.formatNumber(l, {
                        notation: "compact"
                    }), this.captionText && this.captionText.textContent && (l == 1 ? this.captionText.textContent = this.t("Reviews").replace(/s$/, "") : this.captionText.textContent = this.t("Reviews"))) : clearInterval(d)
                }, o)
        }
        filter() {
            this.e.filterEnabled && (this.Ha(), this.collection.toggleRatingFilter(this.rating))
        }
        Ha() {
            this.toggleClass("fera-ratingSummary-ratingItem-filter--active", this.filtered), this.toggleClass("fera-ratingSummary-ratingItem-filter--inactive", !this.filtered)
        }
        get filtered() {
            return this.collection.activeRatingFilter == this.rating || !this.collection.activeRatingFilter
        }
        get s() {
            var t;
            return `<div class="fera-ratingSummary-ratingItem ${this.e.fullWidth?"fera-ratingSummary-ratingItem--fullWidth":""}"
     data-fera-rating="${this.e.rating}" data-fera-rating-count="${this.e.frequency||0}" data-fera-rating-percentage="${this.e.percentage||0}">
  <div class="fera-ratingSummary-ratingItem-histogram-star">
    <div class="fera-ratingSummary-ratingItem-histogram-star-content" data-fera-component-container="ratingStar"></div>
  </div>
  <div class="fera-ratingSummary-ratingItem-histogram-bar">
    <div class="fera-ratingSummary-ratingItem-histogram-bar-content" style="--percent: ${this.e.percentage||0}%"><span class="fera--srOnly">${this.e.percentage||0}%</span></div>
  </div>
  <div class="fera-ratingSummary-ratingItem-histogram-frequency">
    <span class="fera-ratingSummary-ratingItem-histogram-frequency-content">
      <span class="fera-number" data-frequency="${this.e.frequency||0}" style="--frequency: ${this.e.frequency||0}">${this.formatNumber(0)}</span>&nbsp;<!-- Only want a single space between these
   -->${((t=this.app.store)==null?void 0:t.locale)=="en"?`<span class="fera-text">${this.t("Reviews")}</span>`:""}
    </span>
  </div>
</div>`
        }
    };
    var Fr = class extends f {
        constructor(t) {
            super(t), this.rating = this.e.rating, this.collection = this.e.collection, this.fullWidth = this.e.fullWidth || this.e.scope.getCount("media") <= 0
        }
        r() {
            super.r(), this.Ad(), this.collection.on("filter:after", t => this.setRatingFilterState(t.rating))
        }
        startAnimation() {
            this.Er.forEach(t => t.startAnimation())
        }
        stopAnimation() {
            this.Er.forEach(t => t.stopAnimation())
        }
        Ad() {
            this.Er = [];
            let t = [...this.rating.counts].reverse();
            t.forEach((e, i) => {
                let s = t.length - i,
                    a = this.rating.count,
                    o = e / a * 100,
                    l = new Nr(h(n({}, this.i), {
                        rating: s,
                        percentage: o,
                        collection: this.collection,
                        frequency: e,
                        totalFrequency: a,
                        fullWidth: this.fullWidth,
                        filterEnabled: a > 0
                    }));
                this.Er.push(l), this.append(l)
            })
        }
        setRatingFilterState(t) {
            this.toggleClass("fera-ratingSummary-ratingItems--filtering", !!t), this.refreshView()
        }
        get s() {
            return `<div class="fera-ratingSummary-ratingItems ${this.fullWidth?"fera-ratingSummary-ratingItems--fullWidth":""}"></div>`
        }
    };
    var Xe = class extends xe {
        constructor(t) {
            super(t), this.productId = this.e.productId
        }
        get forProduct() {
            return !!this.productId
        }
        load(t = {}) {
            return this.e.models ? this.Mi() : (this.Ti(), new Promise((e, i) => {
                this.forProduct ? this.app.api.listProductMedia(this.e.productId, h(n(n({}, this.nextParams), t), {
                    include_product: !0
                })).then(({
                    product: s,
                    media: a,
                    meta: o
                }) => {
                    this.product = s, this.ie(a, o), e(a)
                }, i) : this.app.api.listMedia(n(n({}, this.nextParams), t)).then(({
                    media: s,
                    meta: a
                }) => {
                    this.ie(s, a), e(s)
                }, i)
            }))
        }
    };
    var qr = class extends f {
        constructor(t) {
            super(n({
                count: 0
            }, t)), this.count = this.e.count
        }
        r() {
            super.r(), this.count <= 0 && this.hide()
        }
        get s() {
            return `<div class="fera-ratingSummary-mediaList-itemOverlay">
            ${this.count}+
        </div>`
        }
    };
    var En = 4,
        Bn = 8,
        On = 300,
        Wr = class extends f {
            constructor(t) {
                super(t), this.At = [], this.Br = I(this.Or, 50), globalThis.addEventListener("resize", () => this.rendered && !this.destroyed && this.Br())
            }
            l() {
                super.l(), this.mi()
            }
            r() {
                super.r(), this.Le()
            }
            h() {
                super.h(), this.mi()
            }
            Le() {
                return m(this, null, function*() {
                    return this.collection = new Xe(this.zr), this.el.addEventListener("animationend", () => {
                        this.isAnimating = !1, this.removeClass("fera-ratingSummary-mediaList--animating"), this.addClass("fera-ratingSummary-mediaList--animated")
                    }), this.el.addEventListener("animationstart", () => {
                        this.isAnimating = !0, this.removeClass("fera-ratingSummary-mediaList--animated")
                    }), yield this.collection.load(), this.tt(), this.collection
                })
            }
            reloadCollection() {
                return this.Le()
            }
            tt() {
                !this.D && this.collection.length < 1 && this.e.whenNoReviews == "show_all_reviews" ? (this.D = !0, this.reloadCollection()) : (this.Ed(), this.Bd(), this.startAnimation())
            }
            Ed() {
                this.collection.on("load:before", () => this.P()), this.collection.on("load:before", () => this.C())
            }
            Bd() {
                this.product = this.collection.product, this.totalMediaCount = this.collection.totalCount, this.setModels(this.collection)
            }
            Or() {
                !this.rendered || this.destroyed || (this.mi(), this.setModels(this.collection))
            }
            a() {
                super.a(), this.Od()
            }
            get maxVisibleItems() {
                return this.jr ? this.jr : (this.mi(), this.jr)
            }
            mi() {
                let {
                    maxMobileVisibleItems: t = En,
                    maxVisibleItems: e = Bn
                } = this.e;
                this.jr = this.Ua ? t : e
            }
            startAnimation() {
                if (this.isAnimating) return !1;
                this.addClass("fera-ratingSummary-mediaList--animating");
                let t = On / this.At.length;
                return this.At.forEach((e, i) => {
                    setTimeout(() => {
                        this._i || (e.el.style.animationDelay = `${i*t}ms`, e.el.style.animationPlayState = "running")
                    }, 0)
                }), !0
            }
            stopAnimation() {
                this.isAnimating = !1, this.removeClass("fera-ratingSummary-mediaList--animating"), this.removeClass("fera-ratingSummary-mediaList--animated")
            }
            get Ua() {
                return globalThis.innerWidth < 779
            }
            zd(t) {
                return this.Ua ? [] : {
                    1: ["1 / 1 / 3 / 5"],
                    2: ["1 / 1 / 3 / 3", "1 / 3 / 3 / 5"],
                    3: ["1 / 3 / 2 / 5", "2 / 3 / 3 / 5", "1 / 1 / 3 / 3"],
                    4: ["1 / 1 / 2 / 3", "1 / 3 / 2 / 5", "2 / 1 / 3 / 3", "2 / 3 / 3 / 5"],
                    5: ["1 / 3 / 2 / 4", "1 / 4 / 2 / 5", "2 / 4 / 3 / 5", "2 / 3 / 3 / 4", "1 / 1 / 3 / 3"],
                    6: ["1 / 1 / 2 / 2", "1 / 2 / 2 / 3", "1 / 3 / 2 / 5", "2 / 3 / 3 / 5", "2 / 2 / 3 / 3", "2 / 1 / 3 / 2"],
                    7: ["1 / 1 / 2 / 2", "1 / 2 / 2 / 3", "1 / 3 / 2 / 4", "1 / 4 / 2 / 5", "2 / 4 / 3 / 5", "2 / 3 / 3 / 4", "2 / 2 / 3 / 3"]
                }[t] || []
            }
            Od() {
                let t = this.At.length,
                    e = this.zd(t);
                if (this.At.forEach((i, s) => {
                        i.el.style.gridArea = e[s] || "auto"
                    }), t >= this.maxVisibleItems) {
                    let i = this.At[this.maxVisibleItems - 1];
                    this.Vr && this.Vr.destroy(), this.Vr = new qr({
                        app: this.app,
                        count: this.totalMediaCount
                    }), i.append(this.Vr)
                }
                this.toggleClass("fera-ratingSummary-mediaList--single", t === 1)
            }
            get productId() {
                return this.e.productId
            }
            get forProduct() {
                return !!this.productId && !this.D
            }
            get zr() {
                let t = {
                    app: this.app,
                    usePagination: this.e.usePagination,
                    productId: this.forProduct && this.productId,
                    forProduct: this.forProduct,
                    useSampleData: this.e.useSampleData
                };
                return this.e.useSampleData && (t.samples = !0), t
            }
            get i() {
                return h(n({}, super.i), {
                    collection: this.collection,
                    productId: this.productId,
                    scope: this.forProduct ? this.collection.product : this.app.store,
                    forProduct: this.forProduct
                })
            }
            get mediaLightbox() {
                return this.Dr ? this.Dr : (this.Dr = new pt({
                    app: this.app,
                    media: this.collection.items,
                    collection: this.collection,
                    c: "fera-ratingSummary-mediaList-lightbox"
                }), this.Dr)
            }
            setModels(t) {
                this.clearChildren(), this.At = [], !t || t.length < 1 ? this.hide() : this.addModels(t), this.refreshView()
            }
            addModels(t) {
                for (let e = 0; e < t.length && !(e >= this.maxVisibleItems); e++) this.jd(t, e)
            }
            jd(t, e) {
                let i = this.Nr(h(n({}, this.i), {
                    model: t.models[e]
                }));
                i.on("error", () => {
                    e < this.maxVisibleItems - 1 ? i.hide() : i.usePlaceholderAsThumbnailUrl()
                }), this.At.push(i), this.addChild(i)
            }
            Nr(t) {
                let e = t.model.get("type") === "video" ? ut : ft;
                return new e(h(n({}, t), {
                    media: t.model,
                    on: {
                        click: () => this.mediaLightbox.show(t.model)
                    }
                }))
            }
            get s() {
                return `<div class="fera-ratingSummary-mediaList ${this.e.scope.getCount("media")<=0?"fera-ratingSummary-mediaList--empty":""}"></div>`
            }
        };
    var Hr = class extends f {
        constructor(t) {
            super(n({
                includeSeoAttributes: !1,
                responsive: !1,
                hideCount: !1,
                rating: {
                    count: 0,
                    average: 0,
                    counts: Array(5).fill(0)
                },
                collection: null,
                productId: null
            }, t)), this.rating = this.e.rating, this.collection = this.e.collection, this.widgetModel = this.e.widgetModel || null, this.mediaList = new Wr(n({}, this.i)), this.ratingItems = new Fr(n({}, this.i))
        }
        get i() {
            return h(n({}, super.i), {
                rating: this.rating,
                collection: this.collection,
                productId: this.e.productId,
                includeSeoAttributes: this.e.includeSeoAttributes,
                useSampleData: this.e.useSampleData,
                scope: this.e.scope,
                whenNoReviews: this.widgetModel && this.widgetModel.options.when_no_reviews
            })
        }
        r() {
            super.r(), this.el.addEventListener("transitionend", () => {
                this.Fr ? (this.ratingItems.startAnimation(), this.mediaList.startAnimation()) : (this.ratingItems.stopAnimation(), this.mediaList.stopAnimation())
            })
        }
        toggleOpen(t) {
            this.Fr = t, this.toggleClass("fera-ratingSummary--expanded", this.Fr), this.toggleClass("fera-ratingSummary--collapsed", !this.Fr)
        }
        get s() {
            return `<div class="fera-ratingSummary">
  <div data-fera-component="ratingItems"></div>
  <div data-fera-component="mediaList"></div>
</div>`
        }
    };
    var Ur = class extends f {
        get s() {
            return `<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.8744 5.29216L15.3737 6.79281C15.2207 6.9458 14.9734 6.9458 14.8204 6.79281L11.2071 3.17952C11.0541 3.02653 11.0541 2.77913 11.2071 2.62614L12.7077 1.12549C13.3164 0.516764 14.306 0.516764 14.918 1.12549L16.8744 3.08187C17.4864 3.69059 17.4864 4.68018 16.8744 5.29216ZM9.91801 3.9152L1.36983 12.4634L0.67973 16.4185C0.585329 16.9523 1.05082 17.4146 1.58468 17.3234L5.53976 16.63L14.0879 8.08187C14.2409 7.92887 14.2409 7.68148 14.0879 7.52848L10.4747 3.9152C10.3184 3.76221 10.071 3.76221 9.91801 3.9152V3.9152ZM3.53129 14.4686H5.09379V15.6502L2.99418 16.0181L1.98181 15.0057L2.34965 12.9061H3.53129V14.4686Z" fill="currentColor"/></svg>`
        }
    };
    var Zr = class extends f {
        constructor(t) {
            super(t), this.widgetModel = this.e.widgetModel, this.model = this.e.scope, this.Vd = I(() => this.Za(), 150), this.O = this.e.collection && this.e.collection.rating || this.model.rating, (!this.O || this.O.count < 1) && this.e.useSampleData && (this.O = {
                count: 120,
                average: 4.2,
                counts: [3, 5, 5, 62, 45]
            }), this.averageRating = new ie({
                app: this.app,
                rating: this.O,
                includeSeoAttributes: this.e.includeSeoAttributes,
                responsive: !0,
                showRatingNumber: !0
            }), this.ratingSummaryToggle = new Dr({
                app: this.app,
                filterVisible: this.widgetModel.get("summary_filters_visible", !0),
                filterCollapsible: this.widgetModel.get("summary_filter_collapsible", !0),
                filterOpenByDefault: this.widgetModel.get("open_summary_filters_by_default", !1),
                on: {
                    toggle: e => this.Ya(e)
                }
            })
        }
        Ya(t) {
            this.widgetModel.get("summary_filters_visible", !0) && (this.ratingSummary || this.Dd(), this.ratingSummary.toggleOpen(t))
        }
        Dd() {
            this.ratingSummary = new Hr({
                app: this.app,
                rating: this.O,
                includeSeoAttributes: this.e.includeSeoAttributes,
                responsive: !0,
                collection: this.e.collection,
                productId: this.bt,
                useSampleData: this.e.useSampleData,
                scope: this.model,
                widgetModel: this.widgetModel
            }), this.w(".fera-reviews-header-row2", this.ratingSummary, {
                replace: !1
            })
        }
        Za() {
            let t = this.o(".fera-reviews-header-summary-container"),
                e = t.querySelectorAll(".fera-col");
            e[0].getBoundingClientRect().top < e[1].getBoundingClientRect().top ? t.classList.add("fera-reviews-header-summary-container--wrap") : t.classList.remove("fera-reviews-header-summary-container--wrap")
        }
        setText(t) {
            let e = this.o("[data-fera-widget-heading]");
            e && (e.innerText = this.t(t))
        }
        get Nd() {
            return {
                app: this.app,
                product: this.e.product,
                productId: this.bt,
                canAbandon: this.app.config.designMode
            }
        }
        get bt() {
            var t;
            return this.e.productId || ((t = this.e.product) == null ? void 0 : t.id) || this.app.currentProductId
        }
        r() {
            super.r(), this.Fd = this.o("[data-fera-actions-col]"), this.widgetModel.is("write_review_visible") && this.Fd.appendChild(this.writeReviewBtn.render()), this.ratingSummaryToggle.filterIsOpen && this.Ya(!0)
        }
        h() {
            super.h(), this.widgetModel.is("write_review_visible") && (this.Za(), globalThis.addEventListener("resize", () => this.rendered && !this.destroyed && this.Vd()))
        }
        get writeReviewBtn() {
            return this.qr ? this.qr : (this.qr = new gt({
                app: this.app,
                text: this.t("Write a review"),
                type: this.widgetModel.get("write_review_style", "primary") || "primary",
                onClick: t => {
                    t.preventDefault(), this.showContentSubmitter()
                },
                responsive: "swap",
                icon: new Ur({
                    app: this.app
                }),
                c: "fera-reviews-writeReviewLink"
            }), this.qr)
        }
        showContentSubmitter() {
            let t = new He(this.Nd);
            return t.show(), t
        }
        get options() {
            return n(n({}, this.L), this.e.options || (this.widgetModel ? this.widgetModel.getData() : {}))
        }
        get L() {
            return this.review.forStore ? et.defaultTypeSettings : tt.defaultTypeSettings
        }
        get qd() {
            return !this.widgetModel.is("header_visible") || !this.widgetModel.get("header") ? "" : `<div class="fera-reviews-header-row1"><h1 data-fera-widget-heading>${this.t(this.widgetModel.get("header"))}</h1></div>`
        }
        get Wd() {
            return `<div class="fera-col fera-reviews-header-summary">
  <div data-fera-component="averageRating" class="fera-reviews-header-summary-average-rating"></div>
  <div data-fera-component-container="ratingSummaryToggle"></div>
</div>`
        }
        get Hd() {
            return this.widgetModel.is("write_review_visible") ? '<div class="fera-col" data-fera-actions-col></div>' : ""
        }
        get s() {
            return `<div class="fera-reviews-header">
    ${this.qd}
    <div class="fera-reviews-header-row2">
        <div class="fera-row fera-reviews-header-summary-container ${this.widgetModel.is("write_review_visible")?"":"fera-row--middle"}">
            ${this.Wd}
            ${this.Hd}
        </div>
    </div>
</div>`
        }
    };
    var Je = class extends f {
        get s() {
            return `<img class="fera-icon fera-icon-info" width="16" height="16" src="${this.B("fera/components/icons/info/image.svg")}" alt="${this.t("Info")}"/>`
        }
    };
    var nt = class extends f {
        constructor(t) {
            super(t), this.type = this.e.type || "info", this.icon = new Je({
                app: this.app
            })
        }
        close() {
            this.hide(), this.remove()
        }
        get s() {
            return `<div class="fera-alert fera-alert--${this.type} fera-alert--dismissible" role="alert">
    <img class="fera-alert-icon" data-fera-component="icon" alt="!">
    <div class="fera-alert-content" data-fera-content>${this.content||""}</div>
</div>`
        }
    };
    var Yr = class extends nt {
        constructor(t) {
            super(t), this.addClass("fera-reviews-widget-filter-alert"), this.collection = this.e.collection, this.content = this.content || this.t("Sorry, no reviews match your filters. Please adjust your criteria or {{ link.start }}view all reviews{{ link.end }}.", {
                link: {
                    start: '<a class="fera-reviews-widget-filter-alert--clear" href="#">',
                    end: "</a>"
                }
            })
        }
        r() {
            super.r(), this.Ud()
        }
        Ud() {
            this.Ii(".fera-reviews-widget-filter-alert--clear", "click", t => {
                t.preventDefault(), t.stopPropagation(), this.collection.clearFilters()
            })
        }
    };
    var re = class extends It {
        constructor(t) {
            super(t), this.addClass(`fera-reviews-${this.layoutCode} fera-reviews-widget`), this.Br = I(this.Or, 300), globalThis.addEventListener("resize", () => this.rendered && !this.destroyed && this.Br()), this.Xa()
        }
        r() {
            super.r(), this.Le()
        }
        Wr() {
            this.e.forCustomer && this.e.customer ? this.collection = this.e.customer.collectReviews(this.ct) : this.collection = new _t(this.ct)
        }
        get ct() {
            let t = this.widgetModel.collectionParams;
            t.page_size != this.pageSize && (t.page_size = this.pageSize);
            let e = {
                app: this.app,
                params: t,
                usePagination: this.widgetModel.usePagination
            };
            return this.usingSampleData && (e.params.samples = !0), e
        }
        Le() {
            return m(this, null, function*() {
                return this.Wr(), yield this.collection.load(), this.collection.on("load.page:before", () => globalThis.scroll(this.el.offsetLeft, this.el.offsetTop)), this.tt(), this.collection
            })
        }
        reloadCollection() {
            return this.Le()
        }
        get Hr() {
            return this.Zd || (this.Zd = new Yr({
                app: this.app,
                collection: this.collection
            }))
        }
        Ja() {
            this.rendered && (!this.Hr.rendered && this.collection.length <= 0 && this.insertBefore(this.Hr, this.body), this.Hr.toggleVisible(this.collection.length <= 0))
        }
        get Yd() {
            return this.layoutCode === "masonry" ? Vr : Ye
        }
        get layoutCode() {
            let t = this.widgetModel.get("layout");
            return t == "grid" && (t = "masonry"), ["list", "masonry"].includes(t) ? t : this.Ka
        }
        get Ka() {
            return "list"
        }
        kt() {
            this.destroyed || (this.clear(), this.Xd(), this.Et(), this.Ur(), this.Jd())
        }
        Jd() {
            this.body && this.body.on("reviews.render:after", () => this.xt()), this.xt(), this.trigger("reviews.render:after")
        }
        Xd() {
            this.e.headerVisible !== !1 && (this.header = new Zr(this.Kd), this.addChild(this.header))
        }
        Et() {
            this.body = new this.Yd(this.pe), this.addChild(this.body)
        }
        Ur() {
            this.footer = new Ze(h(n({}, this.i), {
                usePagination: this.widgetModel.usePagination
            })), this.addChild(this.footer)
        }
        get i() {
            return h(n({}, super.i), {
                collection: this.collection,
                widgetModel: this.widgetModel
            })
        }
        get Kd() {
            return h(n({}, this.i), {
                useSampleData: this.usingSampleData
            })
        }
        get pe() {
            return this.i
        }
        Or() {
            if (this.collection && this.collection.isLoading || this.layoutCode != "masonry") return;
            let t = this.Zr;
            this.Xa(), this.Zr != t && (this.collection && this.collection.pageSize == this.pageSize || this.reloadCollection())
        }
        Xa() {
            this.Zr = globalThis.innerWidth < 634 ? "mobile" : "desktop"
        }
        get pageSize() {
            return this.Zr == "desktop" ? this.widgetModel.desktopPageSize : this.widgetModel.mobilePageSize
        }
        get s() {
            return '<div id="reviews"></div>'
        }
    };
    var Ke = class extends re {
        constructor(t) {
            super(t), this.addClass("fera-allReviews-widget")
        }
        get ct() {
            return h(n({}, super.ct), {
                forProduct: !1
            })
        }
        get Ka() {
            return "masonry"
        }
        tt() {
            this.collection.on("filter:after", () => this.Ja()), this.kt(), this.refreshView()
        }
        xt() {
            this.app.seoService.removeFromWidget(this)
        }
        Et() {
            this.collection.length < 1 ? this.addChild(new nt({
                app: this.app,
                content: this.t("There are no reviews to show right now. Check back soon!")
            })) : super.Et()
        }
        get i() {
            return h(n({}, super.i), {
                scope: this.app.store,
                showProducts: this.widgetModel.is("products_visible"),
                forProduct: !1,
                includeSeoAttributes: !1
            })
        }
    };
    var Xr = class extends f {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.averageRating = new ie({
                app: this.app,
                rating: this.e.customer.rating,
                showRatingNumber: !0,
                hideCount: !0
            }), this.customerSince = new Ot({
                app: this.app,
                time: this.e.customer.get("created_at")
            }), this.lastActivity = new Ot({
                app: this.app,
                time: this.e.customer.get("updated_at")
            }), this.verifiedIcon = new Jt({
                app: this.app
            }), this.channelIcon = new Kt({
                app: this.app,
                showStoreSource: !0,
                customer: this.e.customer
            })
        }
        get Gd() {
            return this.customer.is("verified") ? `<dt>${this.t("Verification")}</dt>
        <dd class="fera-customer-details-item-withIcon">
            <svg width="16" height="16" data-fera-component="verifiedIcon"></svg>
            <span>${this.t("Verified Customer")}</span>
        </dd>` : ""
        }
        get Qd() {
            return this.customer.is("verified") ? this.Gd : this.customer.channel && this.customer.channel.code != "custom" ? `<dt>${this.t("Original Source")}</dt>
        <dd class="fera-customer-details-item-withIcon" data-fera-source="${this.customer.channel.code}">
            <span data-fera-component="channelIcon"></span>
            <span>${this.customer.channel.get("name")}</span>
        </dd>` : ""
        }
        get s() {
            return `<dl class="fera-customer-details">
    ${this.Qd}
    <dt>${this.t("Customer Since")}</dt>
    <dd class="fera-customer-details-createdAt">
        <span data-fera-component="customerSince" data-value="${this.customer.get("created_at")}">${this.customer.get("created_at")}</span>
    </dd>
    <dt>${this.t("Average Rating")}</dt>
    <dd class="fera-customer-details-rating-average"><div data-fera-component="averageRating"></div></dd>
    <dt>${this.t("Number of Reviews")}</dt>
    <dd class="fera-customer-details-rating-count">${this.customer.rating.count}</dd>
</dl>`
        }
    };
    var Jr = class extends f {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.customerDisplay = new De({
                app: this.app,
                customer: this.customer,
                flareOnAvatar: !1,
                showCustomerOnClick: !1
            }), this.customerDetails = new Xr({
                app: this.app,
                customer: this.customer
            }), this.customerReviews = new Ke({
                app: this.app,
                customer: this.customer,
                forCustomer: !0,
                headerVisible: !1,
                widgetModel: new et({
                    app: this.app,
                    layout: "list"
                })
            })
        }
        get s() {
            return `<div class="fera-customer-modal-content fera-row" data-id="${this.customer.id}">
    <div class="fera-col fera-customer-modal-content-info">
        <div data-fera-component="customerDisplay"></div>
        <div data-fera-component="customerDetails"></div>
    </div>
    <div class="fera-col fera-customer-modal-content-reviews">
        <div data-fera-component="customerReviews">Loading...</div>
    </div>
</div>`
        }
    };
    var Kr = class extends it {
        constructor(t) {
            super(t), this.customer = this.e.customer, this.customer.id && (this.J = {
                fera: "showCustomer",
                fera_customer: this.customer.id
            }), this.addClass("fera-customer-modal"), this.content = new Jr(this.i)
        }
        get M() {
            return super.M || this.t("Reviewer Profile")
        }
        get i() {
            return h(n({}, super.i), {
                customer: this.customer
            })
        }
    };
    var Gr = class extends f {
        constructor(t = {}) {
            super(t), this.addClass("fera-confirmModal-content"), this.Ct = this.e.btns || this.e.buttons || [], this.e.primaryBtn && this.Ct.push(this.e.primaryBtn), this.e.secondaryBtn && this.Ct.push(this.e.secondaryBtn)
        }
        r() {
            super.r(), this.Yr = this.o(".fera-confirmModal-content-footer"), this.Xr = this.o(".fera-confirmModal-content-body"), this.Et(), this.Ur()
        }
        Et() {
            this.e.body ? typeof this.e.body == "string" ? this.Xr.innerHTML = this.e.body : this.Xr.appendChild(this.e.body.render()) : this.e.message || this.Xr.remove()
        }
        Ur() {
            this.Ct.length === 0 && (this.Ct.push({
                text: "OK"
            }), this.Ct.push({
                text: "Cancel"
            })), this.Ct.forEach((t, e) => {
                let i = t;
                t instanceof f || (i = new gt(n(n({}, this.i), t))), e === 0 ? (this.primaryBtn = i, i.setType("primary"), i.on("click", s => this.trigger("primaryBtn.click", s))) : e === 1 && (this.secondaryBtn = i, i.setType("secondary"), i.on("click", s => this.trigger("secondaryBtn.click", s))), this.Yr.appendChild(i.render())
            }), this.Ct.length === 0 && this.Yr.remove(), this.Ct.length === 1 && this.Yr.classList.add("fera-confirmModal-content-footer--singleBtn")
        }
        get s() {
            return `<div id="modal-11-content" class="fera-confirmModal-content">
    <div class="fera-confirmModal-content-body">${this.e.message||""}</div>
    <div class="fera-confirmModal-content-footer"></div>
</div>`
        }
    };
    var Ge = class extends it {
        constructor(t = {}) {
            super(t), this.addClass("fera-confirmModal"), this.e.type && (this.addClass(`fera-confirmModal--${this.e.type}`), this.e.icon = this.e.icon || {
                warning: "warning",
                info: "info",
                error: "warning"
            }[this.e.type]), this.content = new Gr(this.i), this.content.on("primaryBtn.click secondaryBtn.click", () => this.hide())
        }
        static show(t) {
            let e = new this(t);
            return new Promise(i => {
                let s = !1;
                e.on("primaryBtn.click", () => {
                    s = !0, i(!0)
                }), e.on("secondaryBtn.click", () => i(!1)), e.on("hide", () => s || i(!1)), e.show()
            })
        }
        static warn(t) {
            return this.show(h(n({}, t), {
                type: "warning"
            }))
        }
        static info(t) {
            return this.show(h(n({}, t), {
                type: "info"
            }))
        }
        static error(t) {
            return t.title = t.title || t.app.t("There was an issue."), t.primaryBtn = t.primaryBtn || {
                text: t.app.t("OK")
            }, t.secondaryBtn = t.secondaryBtn || !1, this.show(h(n({}, t), {
                type: "error"
            }))
        }
        r() {
            super.r(), this.th()
        }
        th() {
            let t = this.e.icon;
            if (typeof t == "string") {
                let e = {
                    warning: te,
                    info: Je
                }[t];
                t = new e({
                    app: this.app
                })
            }
            t && (this.o(".fera-modal-header").prepend(t.render()), this.addClass("fera-confirmModal--withIcon"))
        }
        get M() {
            return super.M || this.t("Are you sure?")
        }
        get i() {
            return h(n({}, super.i), {
                btns: this.e.btns || this.e.buttons,
                body: this.e.message || this.e.body,
                primaryBtn: this.e.primaryBtn,
                secondaryBtn: this.e.secondaryBtn
            })
        }
    };
    var ci = class extends w {
        static get version() {
            return "3.0.10"
        }
        get version() {
            return this.constructor.version
        }
        static get build() {
            return "1711998266321"
        }
        get build() {
            return this.constructor.build
        }
        static init({
            pushBuffer: t = [],
            WidgetLoader: e
        } = {}) {
            let i = () => new Promise((s, a) => {
                let o = (globalThis.fera ? globalThis.fera.environment : null) || globalThis.feraEnvironment || globalThis.feraEnvironment;
                setTimeout(() => {
                    try {
                        if (globalThis.fera && globalThis.fera.version) Array.isArray(t) && globalThis.fera.push(t), o !== "production" && console.warn("Fera.js was initialized more than once. 2nd init ignored."), s(globalThis.fera);
                        else {
                            let l = [...globalThis.fera || [], ...t];
                            globalThis.fera = new this({
                                pushBuffer: l,
                                WidgetLoader: e
                            })
                        }
                        globalThis.fera.once("ready", () => s(globalThis.fera))
                    } catch (l) {
                        o !== "production" ? (globalThis.Kt = globalThis.Kt || [], globalThis.Kt.push({
                            line_number: l.lineno,
                            column_number: l.colno,
                            message: l.message
                        }), a(l)) : console.warn(`Fera.js failed to load due to an unexpected error: ${l.message}. Contact help@fera.ai for support.`)
                    }
                }, 1)
            });
            return new Promise(s => {
                document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", () => i().then(() => s(globalThis.fera))) : i().then(() => s(globalThis.fera))
            })
        }
        constructor(t) {
            super(h(n({}, t), {
                app: "this"
            })), this.eh.flush(), this.b(`Fera.js v${this.constructor.version} loaded successfully.`), this.ih()
        }
        ih() {
            return m(this, null, function*() {
                this.request.loadUrlConfig(), this.rh(), this.clientAppService.start(), yield this.Ga(), this.yr(), yield Promise.allSettled([this.i18n.loadTranslations(), this.di()]), this.sh(), this.request.triggerUrlApi(), this.ls()
            })
        }
        get isReady() {
            return !!this.Xt
        }
        yr() {
            try {
                new Function(this.store.get("frontend_js", ""))()
            } catch (t) {
                this.ft("Ignored unexpected error while loading store.frontend_js:"), this.N(t)
            }
        }
        get config() {
            return this.Qa || (this.Qa = new Sr(n({
                app: this
            }, typeof this.e.config == "string" ? JSON.parse(this.e.config) : this.e.config || {}))), this.Qa
        }
        get request() {
            return this.ah || (this.ah = new xr({
                app: this
            }))
        }
        get translationService() {
            return this.oh || (this.oh = new _r({
                app: this
            }))
        }
        get i18n() {
            return this.translationService
        }
        t(t, e = null) {
            return this.translationService.t(t, e)
        }
        get storage() {
            return this.nh || (this.nh = new br({
                app: this
            }))
        }
        get assetService() {
            return this.lh || (this.lh = new yr({
                app: this
            }))
        }
        get visitorService() {
            return this.dh || (this.dh = new mr({
                app: this
            }))
        }
        get geoService() {
            return this.hh || (this.hh = new vr({
                app: this
            }))
        }
        get cssService() {
            return this.ch || (this.ch = new Mr({
                app: this
            }))
        }
        get seoService() {
            return this.uh || (this.uh = new wr({
                app: this
            }))
        }
        get clientAppService() {
            return this.fh || (this.fh = new gr({
                app: this
            }))
        }
        getState(t = {}) {
            return new kr({
                data: t,
                app: this
            })
        }
        setCurrentProduct(t) {
            typeof t == "object" ? (this.currentProduct = new R(t, {
                app: this
            }), this.Jr = this.currentProduct.id) : this.Jr = t
        }
        setProduct(t) {
            return this.setCurrentProduct(t)
        }
        setProductId(t) {
            return this.setCurrentProduct(typeof t == "object" ? t : {
                id: t
            })
        }
        get currentProductId() {
            var t;
            return this.Jr || ((t = this.currentProduct) == null ? void 0 : t.id)
        }
        unsetCurrentProduct() {
            this.currentProduct = null, this.Jr = null
        }
        unsetProduct() {
            return this.unsetCurrentProduct()
        }
        retrieveCurrentProduct() {
            return m(this, null, function*() {
                return this.currentProductId && (this.currentProduct = yield this.api.retrieveProduct(this.currentProductId)), this.currentProduct
            })
        }
        retrieveCurrentProductIdFromPlugins() {
            return m(this, null, function*() {
                return (yield Promise.all(this.plugins.map(e => m(this, null, function*() {
                    return typeof e.currentProductId == "function" ? yield e.currentProductId(): e.currentProductId
                })))).find(e => !!e)
            })
        }
        reset() {
            this.storage.reset()
        }
        clearCache() {
            this.assetService.clearCache()
        }
        rh() {
            if (!this.e.WidgetLoader) return;
            let t = this.e.WidgetLoader.getAttributeConfig();
            Object.keys(t).length != 0 && this.configure(t)
        }
        sh() {
            this.widgetLoader && this.widgetLoader.load()
        }
        get widgetLoader() {
            return this.Kr ? this.Kr : this.e.WidgetLoader ? (this.Kr = new this.e.WidgetLoader({
                app: this
            }), this.Kr) : null
        }
        get locale() {
            return this.config.locale || this.store.locale || "en"
        }
        setLocale(t) {
            t && (t.match(/^((nn|nb)-)/i) || ["nn", "nb"].includes(t.toLowerCase()) ? t = "no" : ["mni-mtei", "zh-tw", "zh-cn"].includes(t.toLowerCase()) || (t = t.split("-").shift())), this.configure({
                locale: t
            })
        }
        showContentSubmitter(t = {}) {
            return this.contentSubmitter.show(t), this.contentSubmitter
        }
        showReview(t) {
            return m(this, null, function*() {
                if (t = t || this.request.getFeraParam(["review", "review_id", "reviewId", "id"]), !t) return this.N("Missing review parameter");
                if (!(t instanceof O)) try {
                    t = yield this.api.retrieveReview(t)
                } catch (i) {
                    return this.eo(i)
                }
                let e = new $r({
                    app: this.app,
                    title: t.title,
                    review: t
                });
                return e.show(), e
            })
        }
        eo(t) {
            if (!(t instanceof Vt)) throw t;
            return Ge.error({
                app: this.app,
                body: this.t(t.message)
            })
        }
        showCustomer(t) {
            return m(this, null, function*() {
                if (t = t || this.request.getFeraParam(["customer", "customer_id", "customerId", "id"]), !t) return this.N("Missing customer parameter");
                if (!(t instanceof ct)) try {
                    t = yield this.api.retrieveCustomer(t)
                } catch (i) {
                    return this.eo(i)
                }
                let e = new Kr({
                    app: this.app,
                    title: this.t("Reviewer Profile"),
                    customer: t
                });
                return e.show(), e
            })
        }
        configure(t) {
            let e = n({}, t);
            e && e.store && this.setStore(e.store), this.config.update(e)
        }
        loadStylesheet(t, e) {
            this.Ae = this.Ae || {}, this.Ae[t] != e && (this.Ae[t] = e, this.ph && this.assetService.load(this.Ae))
        }
        plugin(t, e) {
            this.gi = this.gi || {}, this.gi[t] = this.gi[t] || new e(this)
        }
        get plugins() {
            return Object.values(this.gi || [])
        }
        get api() {
            return this.io = this.io || new Ri({
                app: this,
                mock: this.config.mockApi
            }), this.io
        }
        get store() {
            return this.Ee
        }
        get environment() {
            return this.e.environment ? this.e.environment : globalThis.location.href.match(/^https?:\/\/((127\.0\.0\.1|localhost)(:[0-9]+)?|[a-z0-9]+\.ngrok\.io)/i) ? "development" : globalThis.feraEnvironment || "production"
        }
        get contentSubmitter() {
            return this.ro = this.ro || new He({
                app: this
            }), this.ro
        }
        get widgets() {
            return this.widgetLoader ? this.widgetLoader.widgets : []
        }
        reloadWidgets() {
            this.widgetLoader.reload()
        }
        refreshContent() {
            this.widgets.forEach(t => t.refreshView())
        }
        clearWidgets() {
            this.widgetLoader.clear()
        }
        setTheme(t) {
            this.mh = t, this.so()
        }
        loadPlatformAdapter() {}
        startProductPageViewing() {}
        setCart() {}
        setStore(t) {
            this.Ee = t instanceof Bt ? t : new Bt(t, {
                app: this
            })
        }
        updateStore(t) {
            if (!this.Ee) {
                this.setStore(t);
                return
            }
            let e = n({}, t);
            delete e.id, this.Ee.loadDataFromServer(e, {
                fresh: !0
            }), this.Xt && this.di()
        }
        Ga() {
            return m(this, null, function*() {
                if (this.Ee) return;
                let t = this.e.store || this.config.store;
                t ? this.setStore(t) : this.api.isConfigured ? this.setStore(yield this.api.retrieveStore()) : (yield ge(() => this.api.isConfigured && (this.Ee || this.config.store), {
                    checkInterval: 1,
                    timeoutError: "API not configured."
                }), yield this.Ga())
            })
        }
        di() {
            return m(this, null, function*() {
                yield this.so(), this.cssService.update({
                    code: "store",
                    content: this.store.get("frontend_css") || this.store,
                    priority: 20
                })
            })
        }
        so() {
            return m(this, null, function*() {
                this.assetService.loadedStylesExternally || this.loadStylesheet("core", "/fera.css"), this.store.get("frontend_css") && this.store.get("frontend_css").includes("/* Fera Theme") || this.loadStylesheet("theme", `/themes/${this.currentTheme}.css`), yield this.assetService.load(this.Ae || []), this.ph = !0
            })
        }
        get currentTheme() {
            return this.mh || this.store.theme || "neutral"
        }
        get eh() {
            return this.gh || (this.gh = new Rr({
                app: this,
                pushBuffer: this.e.pushBuffer
            }))
        }
        push(t, ...e) {
            return typeof t != "string" ? this : (this[t] || this.N(`Invalid method:${t}`), this[t](...e))
        }
    };
    var Qr = class extends f {
        constructor(t) {
            super(t), this.collection = this.e.collection, this.addModels(this.collection), this.collection.on("load:more", e => this.addModels(e)), this.collection.on("load:page", e => this.setModels(e)), this.Lt = I(this.yt, 50), this.addClass(`minCols--${this.e.widgetModel.get("min_cols",2)}`)
        }
        get mediaLightbox() {
            return new pt({
                app: this.app,
                media: this.collection.items
            })
        }
        setModels(t) {
            this.clearChildren(), this.addModels(t)
        }
        addModels(t) {
            t.forEach(e => this.addChild(this.Nr(h(n({}, this.i), {
                model: e
            })))), this.refreshView()
        }
        get i() {
            return h(n({}, super.i), {
                forProduct: this.e.forProduct,
                widgetModel: this.widgetModel,
                includeSeoAttributes: this.e.includeSeoAttributes,
                on: {
                    resize: () => this.Lt()
                }
            })
        }
        Nr(t) {
            let e = t.model.get("type") === "video" ? ut : ft;
            return new e(h(n({}, t), {
                media: t.model,
                on: {
                    click: () => this.mediaLightbox.show(t.model)
                }
            }))
        }
        a() {
            super.a(), this.Pr()
        }
        yt() {
            this.masonry && this.masonry.layout()
        }
        Pr() {
            this.masonry ? this.Lt() : (this.masonry = new ot({
                container: this.Ne,
                gutter: 0,
                ultimateGutter: 0,
                surroundingGutter: !1,
                minCols: this.e.widgetModel.get("min_cols", 2)
            }), globalThis.addEventListener("resize", () => this.rendered && !this.destroyed && this.Lt()))
        }
        get s() {
            return `<div class="fera-mediaGallery-body">
  <div class="fera-mediaGallery-body-items" data-fera-child-container></div>
</div>`
        }
    };
    var de = class extends It {
        constructor(t) {
            super(t), this.addClass("fera-mediaGallery-widget"), this.noContentAlert = new nt({
                app: this.app,
                content: this.t("There are no photos or videos to show yet - check back soon!")
            })
        }
        h() {
            super.h(), this.ao(), this.vh = I(() => this.ao(), 150), globalThis.addEventListener("resize", () => {
                !this.body || !this.rendered || this.destroyed || this.vh()
            })
        }
        ao() {
            this.collection = new Xe({
                app: this.app,
                params: this.zr,
                usePagination: this.widgetModel.usePagination,
                productId: this.productId,
                forProduct: this.forProduct
            }), this.body && this.P(), this.collection.load().then(() => {
                var t, e, i;
                (t = this.body) == null || t.destroy(), (e = this.footer) == null || e.destroy(), (i = this.noContentAlert) == null || i.destroy(), this.C(), this.footer = new Ze(h(n({}, this.i), {
                    usePagination: this.widgetModel.usePagination
                })), this.body = new Qr(this.i), this.collection.on("load:before", () => this.P()), this.collection.on("load:after", () => this.C()), this.product = this.collection.product, this.collection.length < 1 ? this.addChild(this.noContentAlert) : this.addChild(this.body, "#mediaGallery-body"), this.addChild(this.footer), this.refreshView(), this.tt()
            })
        }
        tt() {}
        get zr() {
            let t = this.widgetModel.collectionParams;
            return this.usingSampleData && (t.samples = !0), t.page_size = this.wh, t
        }
        get productId() {
            return this.e.productId
        }
        get forProduct() {
            return !!this.productId
        }
        get subject() {
            return this.forProduct ? "product" : "store"
        }
        get i() {
            return h(n({}, super.i), {
                collection: this.collection,
                productId: this.productId,
                scope: this.forProduct ? this.collection.product : this.app.store,
                subject: this.subject,
                forProduct: this.forProduct,
                widgetModel: this.widgetModel
            })
        }
        get s() {
            return `<div id="mediaGallery">
            ${this.ja}
            <div id="mediaGallery-body"> </div>
        </div>`
        }
        get L() {
            return Lt.defaultTypeSettings
        }
        get oo() {
            return this.o("#mediaGallery-body").offsetWidth
        }
        get wh() {
            return hi() && this.bh ? this.widgetModel.get("mobile_page_size", this.ee) : this.oo < 575 ? 4 : this.yh ? this.widgetModel.get("page_size", this.te) : Math.min(Math.floor(this.oo / 255) * 2, 12)
        }
        get te() {
            return this.L.page_size
        }
        get ee() {
            return this.L.mobile_page_size
        }
        get yh() {
            return this.widgetModel.get("page_size", this.te) != this.te
        }
        get bh() {
            return this.widgetModel.get("mobile_page_size", this.ee) != this.ee
        }
    };
    var ui = class extends de {
        get forProduct() {
            return !0
        }
        get L() {
            return At.defaultTypeSettings
        }
        tt() {
            super.tt(), this.collection.length < 1 && this.widgetModel.hideWhenNoMedia && this.hide()
        }
    };
    var ts = class extends _t {
        load() {
            return m(this, arguments, function*(t = {}) {
                if (this.e.models) return this.Mi();
                if (this.Ti(), !this.e.productId) throw "Product ID is missing.";
                let {
                    product: e,
                    reviews: i,
                    rating: s,
                    meta: a
                } = yield this.app.api.listProductReviews(this.e.productId, h(n(n({}, this.nextParams), t), {
                    include_product: !0
                }));
                return this.product = e, this.rating = s, this.ie(i, a), i
            })
        }
    };
    var Qe = class extends re {
        constructor(t) {
            super(t), this.addClass("fera-productReviews-widget")
        }
        get ct() {
            return h(n({}, super.ct), {
                productId: this.productId,
                forProduct: !0
            })
        }
        Wr() {
            if (this.D) return super.Wr();
            this.collection = new ts(this.ct)
        }
        tt() {
            this.collection.on("filter:after", () => this.Ja()), this.D ? this.xh() : this.collection.length > 0 ? this.no() : this.widgetModel.get("when_no_reviews") === "hide" ? this.hide() : ["show_from_related", "show_all_reviews"].includes(this.widgetModel.get("when_no_reviews")) ? (this.D = !0, this.reloadCollection()) : this.no()
        }
        no() {
            this.product = this.collection.product || new R({
                rating: {
                    count: 0
                }
            }, {
                app: this.app
            }), this.kt(), this.refreshView()
        }
        xh() {
            this.product = null, this.kt(), this.refreshView()
        }
        xt() {
            !this.jt || this.collection.length < 1 || this.showingOtherReviews ? this.app.seoService.removeFromWidget(this) : this.app.seoService.loadFromWidget(this)
        }
        get productId() {
            return this.e.productId || this.widgetModel.productId || this.app.currentProductId
        }
        get forProduct() {
            return !!this.productId && !this.D
        }
        get showingOtherReviews() {
            return this.D
        }
        Et() {
            this.collection.length < 1 ? this.addChild(new nt({
                app: this.app,
                content: this.t("There are no reviews to show right now. Check back soon!")
            })) : (this.D && (this.addChild(new nt({
                app: this.app,
                content: this.t("This product doesn't have any reviews yet, so check out our other reviews instead."),
                c: "fera-productReviews-widget-alert"
            })), this.header.setText(this.widgetModel.get("header_when_showing_other_reviews", "Reviews"))), super.Et())
        }
        get jt() {
            return typeof this.e.includeSeoAttributes != "undefined" ? this.e.includeSeoAttributes : !this.D
        }
        get i() {
            return h(n({}, super.i), {
                productId: this.productId,
                scope: this.D ? this.app.store : this.product,
                subject: "product",
                showProducts: this.D,
                forProduct: !this.D,
                includeSeoAttributes: this.jt
            })
        }
    };
    var es = class extends it {
        constructor(t) {
            super(h(n({}, t), {
                allowOutsideClick: !0
            })), this.addClass("fera-block-widget-modal fera-product-reviews-modal "), this.content = new Qe({
                app: this.app,
                productId: this.e.productId,
                includeSeoAttributes: !1,
                widgetModel: new tt({
                    app: this.app,
                    layout: "list",
                    header_visible: !1,
                    when_no_reviews: this.e.whenNoReviews
                })
            })
        }
        get M() {
            return this.t("Product Reviews")
        }
        h() {
            super.h(), this.startLoading(), this.content.on("reviews.render:after", () => this.stopLoading())
        }
    };
    var fi = class extends Ue {
        l() {
            super.l(), this.averageRating = new ie({
                app: this.app,
                rating: this.rating,
                showRatingNumber: this.widgetModel.is("avg_num_visible"),
                hideCount: !this.widgetModel.is("count_num_visible"),
                includeSeoAttributes: !0
            }), this.averageRating.setRating(this.rating), setTimeout(() => this.refreshView(), 500), setTimeout(() => this.refreshView(), 1e3), setTimeout(() => this.refreshView(), 2e3), setTimeout(() => this.refreshView(), 4e3)
        }
        r() {
            super.r(), this.lo(), this.xt(), setTimeout(() => this.xt(), 2e3), this.averageRating.addEventListener("click", t => this.Ch(t))
        }
        renderAsync() {
            return m(this, null, function*() {
                return this.usingSampleData ? this.O = {
                    average: 4.5,
                    count: 123
                } : this.productId && this._h && (this.O = yield this.app.api.retrieveProductRating(this.productId)), this.render(), this
            })
        }
        get _h() {
            return !this.O && !this.ho && !this.product
        }
        a() {
            super.a(), this.toggleVisible(this.count > 0 || this.widgetModel.showWhenNoReviews), this.toggleClass("fera-rating-widget--inline", !!this.widgetModel.is("inline")), this.averageRating.isClickable = this.isClickable
        }
        get isClickable() {
            return this.ut || this.isCollectionRating ? !0 : this.count > 0
        }
        get isDetailRating() {
            return this.widgetModel.type == "product_detail_rating" || this.productId == this.app.currentProductId
        }
        get isCollectionRating() {
            return this.widgetModel.type == "product_collection_rating" || !this.isDetailRating
        }
        xt() {
            this.ut || this.count < 1 || this.isCollectionRating ? this.app.seoService.removeFromWidget(this) : this.app.seoService.loadFromWidget(this)
        }
        lo() {
            return this.ut ? this.ut : (this.ut = Array.from(document.querySelectorAll("#reviews")).find(t => !t.fera || t.fera.productId && this.productId && t.fera.productId != this.productId ? !1 : t), this.ut = this.ut || Array.from(this.fi).find(t => t || !t.widgetModel || t.widgetModel.type != "product_reviews" ? !1 : this.productId == t.productId), this.ut)
        }
        Ch(t) {
            if (!(!this.isClickable || this.el.closest("a"))) {
                if (this.app.config.designMode && this.usingSampleData) {
                    this.kh();
                    return
                }
                this.lo(), this.ut ? (this.ut.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                }), t.preventDefault()) : this.isCollectionRating ? this.Sh().then(i => i && this.co()) : this.co()
            }
        }
        Sh() {
            return m(this, null, function*() {
                let t = yield this.app.api.retrieveProduct(this.productId);
                return t && t.url ? (globalThis.location.href = `${t.url}#reviews`, !1) : !0
            })
        }
        kh() {
            let t = this.widgetModel.type == "product_detail_rating" ? "Once you're out of design/preview mode then clicking the stars should scroll to your Fera product reviews widget (if one exists)." : "Once you're out of design/preview mode then clicking the stars should take you to the product page";
            this.alertModal || (this.alertModal = new it({
                app: this.app,
                c: "previewAlertModal",
                title: "Rating Badge Clicked",
                content: new f({
                    app: this.app,
                    tpl: `<div>${t}</div>`
                })
            })), this.alertModal.show()
        }
        co() {
            this.uo = this.uo || new es(this.i), this.uo.show()
        }
        get rating() {
            let t = this.O || this.ho || this.Mh;
            return (!t || t.count <= 0) && this.app.config.designMode ? {
                average: 4.5,
                count: 123
            } : t
        }
        get Mh() {
            return this.scope ? this.scope.rating : {
                average: 0,
                count: 0
            }
        }
        get ho() {
            return st.parseTransientRating(this.e.el || this.e.container)
        }
        get average() {
            return this.rating.average
        }
        get count() {
            return this.rating.count
        }
        get productId() {
            return this.e.productId || this.widgetModel.productId
        }
        get forProduct() {
            return this.e.subject === "product"
        }
        get scope() {
            return this.forProduct && !this.productId ? (this.ft("Missing product ID for widget."), null) : this.forProduct ? this.product : this.app.store
        }
        get jt() {
            return typeof this.e.includeSeoAttributes != "undefined" ? this.e.includeSeoAttributes : this.forProduct
        }
        get i() {
            return h(n({}, super.i), {
                rating: this.rating,
                productId: this.productId,
                subject: this.e.subject,
                forProduct: this.forProduct,
                includeSeoAttributes: this.jt,
                whenNoReviews: this.widgetModel.get("when_no_reviews")
            })
        }
        get s() {
            return '<div class="fera fera-widget fera-rating-widget"><div data-fera-component="averageRating"></div></div>'
        }
    };
    var oo = {
        type: "slider",
        startAt: 0,
        perView: 1,
        focusAt: 0,
        gap: 10,
        autoplay: !1,
        hoverpause: !0,
        keyboard: !0,
        bound: !1,
        swipeThreshold: 80,
        dragThreshold: 120,
        perSwipe: "",
        touchRatio: .5,
        touchAngle: 45,
        animationDuration: 400,
        rewind: !0,
        rewindDuration: 800,
        animationTimingFunc: "cubic-bezier(.165, .840, .440, 1)",
        waitForTransition: !0,
        throttle: 10,
        direction: "ltr",
        peek: 0,
        cloningRatio: 1,
        breakpoints: {},
        classes: {
            swipeable: "glide--swipeable",
            dragging: "glide--dragging",
            direction: {
                ltr: "glide--ltr",
                rtl: "glide--rtl"
            },
            type: {
                slider: "glide--slider",
                carousel: "glide--carousel"
            },
            slide: {
                clone: "glide__slide--clone",
                active: "glide__slide--active"
            },
            arrow: {
                disabled: "glide__arrow--disabled"
            },
            nav: {
                active: "glide__bullet--active"
            }
        }
    };

    function K(r) {
        console.error(`[Glide warn]: ${r}`)
    }

    function E(r) {
        return parseInt(r)
    }

    function no(r) {
        return parseFloat(r)
    }

    function is(r) {
        return typeof r == "string"
    }

    function jt(r) {
        let t = typeof r;
        return t === "function" || t === "object" && !!r
    }

    function pi(r) {
        return typeof r == "function"
    }

    function $s(r) {
        return typeof r == "undefined"
    }

    function rs(r) {
        return r.constructor === Array
    }

    function lo(r, t, e) {
        let i = {};
        for (let s in t) pi(t[s]) ? i[s] = t[s](r, i, e) : K("Extension must be a function");
        for (let s in i) pi(i[s].mount) && i[s].mount();
        return i
    }

    function _(r, t, e) {
        Object.defineProperty(r, t, e)
    }

    function ho(r) {
        return Object.keys(r).sort().reduce((t, e) => (t[e] = r[e], t[e], t), {})
    }

    function ss(r, t) {
        let e = Object.assign({}, r, t);
        return t.hasOwnProperty("classes") && (e.classes = Object.assign({}, r.classes, t.classes), ["direction", "type", "slide", "arrow", "nav"].forEach(s => {
            t.classes.hasOwnProperty(s) && (e.classes[s] = n(n({}, r.classes[s]), t.classes[s]))
        })), t.hasOwnProperty("breakpoints") && (e.breakpoints = Object.assign({}, r.breakpoints, t.breakpoints)), e
    }
    var as = class {
        constructor(t = {}) {
            this.events = t, this.hop = t.hasOwnProperty
        }
        on(t, e) {
            if (rs(t)) {
                for (let s = 0; s < t.length; s++) this.on(t[s], e);
                return
            }
            this.hop.call(this.events, t) || (this.events[t] = []);
            let i = this.events[t].push(e) - 1;
            return {
                remove() {
                    delete this.events[t][i]
                }
            }
        }
        emit(t, e) {
            if (rs(t)) {
                for (let i = 0; i < t.length; i++) this.emit(t[i], e);
                return
            }
            this.hop.call(this.events, t) && this.events[t].forEach(i => {
                i(e || {})
            })
        }
    };
    var os = class {
        constructor(t, e = {}) {
            this.et = {}, this.vi = [], this.E = new as, this.disabled = !1, this.selector = t, this.settings = ss(oo, e), this.index = this.settings.startAt
        }
        mount(t = {}) {
            return this.E.emit("mount.before"), jt(t) ? this.et = lo(this, t, this.E) : K("You need to provide a object on `mount()`"), this.E.emit("mount.after"), this
        }
        mutate(t = []) {
            return rs(t) ? this.vi = t : K("You need to provide a array on `mutate()`"), this
        }
        update(t = {}) {
            return this.settings = ss(this.settings, t), t.hasOwnProperty("startAt") && (this.index = t.startAt), this.E.emit("update"), this
        }
        go(t) {
            return this.et.Run.make(t), this
        }
        move(t) {
            return this.et.Transition.disable(), this.et.Move.make(t), this
        }
        destroy() {
            return this.E.emit("destroy"), this
        }
        play(t = !1) {
            return t && (this.settings.autoplay = t), this.E.emit("play"), this
        }
        pause() {
            return this.E.emit("pause"), this
        }
        disable() {
            return this.disabled = !0, this
        }
        enable() {
            return this.disabled = !1, this
        }
        on(t, e) {
            return this.E.on(t, e), this
        }
        isType(t) {
            return this.settings.type === t
        }
        get settings() {
            return this.Z
        }
        set settings(t) {
            jt(t) ? this.Z = t : K("Options must be an `object` instance.")
        }
        get index() {
            return this.Be
        }
        set index(t) {
            this.Be = E(t)
        }
        get type() {
            return this.settings.type
        }
        get disabled() {
            return this.Rh
        }
        set disabled(t) {
            this.Rh = !!t
        }
    };

    function co(r, t, e) {
        let i = {
            mount() {
                this.Z = !1
            },
            make(d) {
                r.disabled || (!r.settings.waitForTransition || r.disable(), this.move = d, e.emit("run.before", this.move), this.calculate(), e.emit("run", this.move), t.Transition.after(() => {
                    this.isStart() && e.emit("run.start", this.move), this.isEnd() && e.emit("run.end", this.move), this.isOffset() && (this.Z = !1, e.emit("run.offset", this.move)), e.emit("run.after", this.move), r.enable()
                }))
            },
            calculate() {
                let {
                    move: d,
                    length: u
                } = this, {
                    steps: c,
                    direction: p
                } = d, g = 1;
                if (p === "=") {
                    if (r.settings.bound && E(c) > u) {
                        r.index = u;
                        return
                    }
                    r.index = c;
                    return
                }
                if (p === ">" && c === ">") {
                    r.index = u;
                    return
                }
                if (p === "<" && c === "<") {
                    r.index = 0;
                    return
                }
                if (p === "|" && (g = r.settings.perView || 1), p === ">" || p === "|" && c === ">") {
                    let v = s(g);
                    v > u && (this.Z = !0), r.index = a(v, g);
                    return
                }
                if (p === "<" || p === "|" && c === "<") {
                    let v = o(g);
                    v < 0 && (this.Z = !0), r.index = l(v, g);
                    return
                }
                K(`Invalid direction pattern [${p}${c}] has been used`)
            },
            isStart() {
                return r.index <= 0
            },
            isEnd() {
                return r.index >= this.length
            },
            isOffset(d = void 0) {
                return d ? this.Z ? d === "|>" ? this.move.direction === "|" && this.move.steps === ">" : d === "|<" ? this.move.direction === "|" && this.move.steps === "<" : this.move.direction === d : !1 : this.Z
            },
            isBound() {
                return r.isType("slider") && r.settings.focusAt !== "center" && r.settings.bound
            }
        };

        function s(d) {
            let {
                index: u
            } = r;
            return r.isType("carousel") ? u + d : u + (d - u % d)
        }

        function a(d, u) {
            let {
                length: c
            } = i;
            return d <= c ? d : r.isType("carousel") ? d - (c + 1) : r.settings.rewind ? i.isBound() && !i.isEnd() ? c : 0 : i.isBound() ? c : Math.floor(c / u) * u
        }

        function o(d) {
            let {
                index: u
            } = r;
            return r.isType("carousel") ? u - d : (Math.ceil(u / d) - 1) * d
        }

        function l(d, u) {
            let {
                length: c
            } = i;
            return d >= 0 ? d : r.isType("carousel") ? d + (c + 1) : r.settings.rewind ? i.isBound() && i.isStart() ? c : Math.floor(c / u) * u : 0
        }
        return _(i, "move", {
            get() {
                return this.Th
            },
            set(d) {
                let u = d.substr(1);
                this.Th = {
                    direction: d.substr(0, 1),
                    steps: u ? E(u) ? E(u) : u : 0
                }
            }
        }), _(i, "length", {
            get() {
                let {
                    settings: d
                } = r, {
                    length: u
                } = t.Html.slides;
                return this.isBound() ? u - 1 - (E(d.perView) - 1) + E(d.focusAt) : u - 1
            }
        }), _(i, "offset", {
            get() {
                return this.Z
            }
        }), i
    }

    function sa() {
        return new Date().getTime()
    }

    function he(r, t, e = {}) {
        let i, s, a, o, l = 0,
            d = function() {
                l = e.leading === !1 ? 0 : sa(), i = null, o = r.apply(s, a), i || (s = a = null)
            },
            u = function() {
                let c = sa();
                !l && e.leading === !1 && (l = c);
                let p = t - (c - l);
                return s = this, a = arguments, p <= 0 || p > t ? (i && (clearTimeout(i), i = null), l = c, o = r.apply(s, a), i || (s = a = null)) : !i && e.trailing !== !1 && (i = setTimeout(d, p)), o
            };
        return u.cancel = function() {
            clearTimeout(i), l = 0, i = s = a = null
        }, u
    }
    var Ps = {
        ltr: ["marginLeft", "marginRight"],
        rtl: ["marginRight", "marginLeft"]
    };

    function uo(r, t, e) {
        let i = {
            apply(s) {
                for (let a = 0, o = s.length; a < o; a++) {
                    let l = s[a].style,
                        d = t.Direction.value;
                    a !== 0 ? l[Ps[d][0]] = `${this.value/2}px` : l[Ps[d][0]] = "", a !== s.length - 1 ? l[Ps[d][1]] = `${this.value/2}px` : l[Ps[d][1]] = ""
                }
            },
            remove(s) {
                for (let a = 0, o = s.length; a < o; a++) {
                    let l = s[a].style;
                    l.marginLeft = "", l.marginRight = ""
                }
            }
        };
        return _(i, "value", {
            get() {
                return E(r.settings.gap)
            }
        }), _(i, "grow", {
            get() {
                return i.value * t.Sizes.length
            }
        }), _(i, "reductor", {
            get() {
                let s = r.settings.perView;
                return i.value * (s - 1) / s
            }
        }), e.on(["build.after", "update"], he(() => {
            i.apply(t.Html.wrapper.children)
        }, 30)), e.on("destroy", () => {
            i.remove(t.Html.wrapper.children)
        }), i
    }

    function aa(r) {
        if (r && r.parentNode) {
            let t = r.parentNode.firstChild,
                e = [];
            for (; t; t = t.nextSibling) t.nodeType === 1 && t !== r && e.push(t);
            return e
        }
        return []
    }

    function oa(r) {
        return !!(r && r.appendChild && r.isConnected)
    }

    function na(r) {
        return Array.prototype.slice.call(r)
    }
    var fo = '[data-glide-el="track"]';

    function po(r, t, e) {
        let i = {
            mount() {
                this.root = r.selector, this.track = this.root.querySelector(fo), this.collectSlides()
            },
            collectSlides() {
                this.slides = na(this.wrapper.children).filter(s => !s.classList.contains(r.settings.classes.slide.clone))
            }
        };
        return _(i, "root", {
            get() {
                return i.$h
            },
            set(s) {
                is(s) && (s = document.querySelector(s)), oa(s) ? i.$h = s : K("Root element must be a existing Html node")
            }
        }), _(i, "track", {
            get() {
                return i.vi
            },
            set(s) {
                oa(s) ? i.vi = s : K(`Could not find track element. Please use ${fo} attribute.`)
            }
        }), _(i, "wrapper", {
            get() {
                return i.track.children[0]
            }
        }), e.on("update", () => {
            i.collectSlides()
        }), i
    }

    function mo(r, t, e) {
        let i = {
            mount() {
                this.value = r.settings.peek
            }
        };
        return _(i, "value", {
            get() {
                return i.Gr
            },
            set(s) {
                jt(s) ? (s.before = E(s.before), s.after = E(s.after)) : s = E(s), i.Gr = s
            }
        }), _(i, "reductor", {
            get() {
                let s = i.value,
                    a = r.settings.perView;
                return jt(s) ? s.before / a + s.after / a : s * 2 / a
            }
        }), e.on(["resize", "update"], () => {
            i.mount()
        }), i
    }

    function go(r, t, e) {
        let i = {
            mount() {
                this.Z = 0
            },
            make(s = 0) {
                this.offset = s, e.emit("move", {
                    movement: this.value
                }), t.Transition.after(() => {
                    e.emit("move.after", {
                        movement: this.value
                    })
                })
            }
        };
        return _(i, "offset", {
            get() {
                return i.Z
            },
            set(s) {
                i.Z = $s(s) ? 0 : E(s)
            }
        }), _(i, "translate", {
            get() {
                return t.Sizes.slideWidth * r.index
            }
        }), _(i, "value", {
            get() {
                let s = this.offset,
                    a = this.translate;
                return t.Direction.is("rtl") ? a + s : a - s
            }
        }), e.on(["build.before", "run"], () => {
            i.make()
        }), i
    }

    function vo(r, t, e) {
        let i = {
            setupSlides() {
                let s = `${this.slideWidth}px`,
                    a = t.Html.slides;
                for (let o = 0; o < a.length; o++) a[o].style.width = s
            },
            setupWrapper() {
                t.Html.wrapper.style.width = `${this.wrapperSize}px`
            },
            remove() {
                let s = t.Html.slides;
                for (let a = 0; a < s.length; a++) s[a].style.width = "";
                t.Html.wrapper.style.width = ""
            }
        };
        return _(i, "length", {
            get() {
                return t.Html.slides.length
            }
        }), _(i, "width", {
            get() {
                return t.Html.track.offsetWidth
            }
        }), _(i, "wrapperSize", {
            get() {
                return i.slideWidth * i.length + t.Gaps.grow + t.Clones.grow
            }
        }), _(i, "slideWidth", {
            get() {
                return i.width / r.settings.perView - t.Peek.reductor - t.Gaps.reductor
            }
        }), e.on(["build.before", "resize", "update"], () => {
            i.setupSlides(), i.setupWrapper()
        }), e.on("destroy", () => {
            i.remove()
        }), i
    }

    function wo(r, t, e) {
        let i = {
            mount() {
                e.emit("build.before"), this.typeClass(), this.activeClass(), e.emit("build.after")
            },
            typeClass() {
                t.Html.root.classList.add(r.settings.classes.type[r.settings.type])
            },
            activeClass() {
                let s = r.settings.classes,
                    a = t.Html.slides[r.index];
                a && (a.classList.add(s.slide.active), aa(a).forEach(o => {
                    o.classList.remove(s.slide.active)
                }))
            },
            removeClasses() {
                let {
                    type: s,
                    slide: a
                } = r.settings.classes;
                t.Html.root.classList.remove(s[r.settings.type]), t.Html.slides.forEach(o => {
                    o.classList.remove(a.active)
                })
            }
        };
        return e.on(["destroy", "update"], () => {
            i.removeClasses()
        }), e.on(["resize", "update"], () => {
            i.mount()
        }), e.on("move.after", () => {
            i.activeClass()
        }), i
    }

    function bo(r, t, e) {
        let i = {
            mount() {
                this.items = [], r.isType("carousel") && (this.items = this.collect())
            },
            collect(s = []) {
                let {
                    slides: a
                } = t.Html, {
                    perView: o,
                    classes: l,
                    cloningRatio: d
                } = r.settings;
                if (a.length > 0) {
                    let u = +!!r.settings.peek,
                        c = o + u + Math.round(o / 2),
                        p = a.slice(0, c).reverse(),
                        g = a.slice(c * -1);
                    for (let v = 0; v < Math.max(d, Math.floor(o / a.length)); v++) {
                        for (let y = 0; y < p.length; y++) {
                            let b = p[y].cloneNode(!0);
                            b.classList.add(l.slide.clone), s.push(b)
                        }
                        for (let y = 0; y < g.length; y++) {
                            let b = g[y].cloneNode(!0);
                            b.classList.add(l.slide.clone), s.unshift(b)
                        }
                    }
                }
                return s
            },
            append() {
                let {
                    items: s
                } = this, {
                    wrapper: a,
                    slides: o
                } = t.Html, l = Math.floor(s.length / 2), d = s.slice(0, l).reverse(), u = s.slice(l * -1).reverse(), c = `${t.Sizes.slideWidth}px`;
                for (let p = 0; p < u.length; p++) a.appendChild(u[p]);
                for (let p = 0; p < d.length; p++) a.insertBefore(d[p], o[0]);
                for (let p = 0; p < s.length; p++) s[p].style.width = c
            },
            remove() {
                let {
                    items: s
                } = this;
                for (let a = 0; a < s.length; a++) t.Html.wrapper.removeChild(s[a])
            }
        };
        return _(i, "grow", {
            get() {
                return (t.Sizes.slideWidth + t.Gaps.value) * i.items.length
            }
        }), e.on("update", () => {
            i.remove(), i.mount(), i.append()
        }), e.on("build.before", () => {
            r.isType("carousel") && i.append()
        }), e.on("destroy", () => {
            i.remove()
        }), i
    }
    var G = class {
        constructor(t = {}) {
            this.listeners = t
        }
        on(t, e, i, s = !1) {
            is(t) && (t = [t]);
            for (let a = 0; a < t.length; a++) this.listeners[t[a]] = i, e.addEventListener(t[a], this.listeners[t[a]], s)
        }
        off(t, e, i = !1) {
            is(t) && (t = [t]);
            for (let s = 0; s < t.length; s++) e.removeEventListener(t[s], this.listeners[t[s]], i)
        }
        destroy() {
            delete this.listeners
        }
    };

    function yo(r, t, e) {
        let i = new G,
            s = {
                mount() {
                    this.bind()
                },
                bind() {
                    i.on("resize", window, he(() => {
                        e.emit("resize")
                    }, r.settings.throttle))
                },
                unbind() {
                    i.off("resize", window)
                }
            };
        return e.on("destroy", () => {
            s.unbind(), i.destroy()
        }), s
    }
    var zn = ["ltr", "rtl"],
        jn = {
            ">": "<",
            "<": ">",
            "=": "="
        };

    function xo(r, t, e) {
        let i = {
            mount() {
                this.value = r.settings.direction
            },
            resolve(s) {
                let a = s.slice(0, 1);
                return this.is("rtl") ? s.split(a).join(jn[a]) : s
            },
            is(s) {
                return this.value === s
            },
            addClass() {
                t.Html.root.classList.add(r.settings.classes.direction[this.value])
            },
            removeClass() {
                t.Html.root.classList.remove(r.settings.classes.direction[this.value])
            }
        };
        return _(i, "value", {
            get() {
                return i.Gr
            },
            set(s) {
                zn.indexOf(s) > -1 ? i.Gr = s : K("Direction value must be `ltr` or `rtl`")
            }
        }), e.on(["destroy", "update"], () => {
            i.removeClass()
        }), e.on("update", () => {
            i.mount()
        }), e.on(["build.before", "update"], () => {
            i.addClass()
        }), i
    }

    function Co(r, t) {
        return {
            modify(e) {
                return t.Direction.is("rtl") ? -e : e
            }
        }
    }

    function _o(r, t) {
        return {
            modify(e) {
                let i = Math.floor(e / t.Sizes.slideWidth);
                return e + t.Gaps.value * i
            }
        }
    }

    function ko(r, t) {
        return {
            modify(e) {
                return e + t.Clones.grow / 2
            }
        }
    }

    function So(r, t) {
        return {
            modify(e) {
                if (r.settings.focusAt >= 0) {
                    let i = t.Peek.value;
                    return jt(i) ? e - i.before : e - i
                }
                return e
            }
        }
    }

    function Mo(r, t) {
        return {
            modify(e) {
                let i = t.Gaps.value,
                    s = t.Sizes.width,
                    a = r.settings.focusAt,
                    o = t.Sizes.slideWidth;
                return a === "center" ? e - (s / 2 - o / 2) : e - o * a - i * a
            }
        }
    }

    function Ro(r, t, e) {
        let i = [_o, ko, So, Mo].concat(r.vi, [Co]);
        return {
            mutate(s) {
                for (var a = 0; a < i.length; a++) {
                    let o = i[a];
                    pi(o) && pi(o().modify) ? s = o(r, t, e).modify(s) : K("Transformer should be a function that returns an object with `modify()` method")
                }
                return s
            }
        }
    }

    function To(r, t, e) {
        let i = {
            set(s) {
                let o = `translate3d(${-1*Ro(r,t).mutate(s)}px, 0px, 0px)`;
                t.Html.wrapper.style.mozTransform = o, t.Html.wrapper.style.webkitTransform = o, t.Html.wrapper.style.transform = o
            },
            remove() {
                t.Html.wrapper.style.transform = ""
            },
            getStartIndex() {
                let s = t.Sizes.length,
                    a = r.index,
                    o = r.settings.perView;
                return t.Run.isOffset(">") || t.Run.isOffset("|>") ? s + (a - o) : (a + o) % s
            },
            getTravelDistance() {
                let s = t.Sizes.slideWidth * r.settings.perView;
                return t.Run.isOffset(">") || t.Run.isOffset("|>") ? s * -1 : s
            }
        };
        return e.on("move", s => {
            if (!r.isType("carousel") || !t.Run.isOffset()) return i.set(s.movement);
            t.Transition.after(() => {
                e.emit("translate.jump"), i.set(t.Sizes.slideWidth * r.index)
            });
            let a = t.Sizes.slideWidth * t.Translate.getStartIndex();
            return i.set(a - t.Translate.getTravelDistance())
        }), e.on("destroy", () => {
            i.remove()
        }), i
    }

    function $o(r, t, e) {
        let i = !1,
            s = {
                compose(a) {
                    let o = r.settings;
                    return i ? `${a} 0ms ${o.animationTimingFunc}` : `${a} ${this.duration}ms ${o.animationTimingFunc}`
                },
                set(a = "transform") {
                    t.Html.wrapper.style.transition = this.compose(a)
                },
                remove() {
                    t.Html.wrapper.style.transition = ""
                },
                after(a) {
                    setTimeout(() => {
                        a()
                    }, this.duration)
                },
                enable() {
                    i = !1, this.set()
                },
                disable() {
                    i = !0, this.set()
                }
            };
        return _(s, "duration", {
            get() {
                let a = r.settings;
                return r.isType("slider") && t.Run.offset ? a.rewindDuration : a.animationDuration
            }
        }), e.on("move", () => {
            s.set()
        }), e.on(["build.before", "resize", "translate.jump"], () => {
            s.disable()
        }), e.on("run", () => {
            s.enable()
        }), e.on("destroy", () => {
            s.remove()
        }), s
    }
    var Po = !1;
    try {
        let r = Object.defineProperty({}, "passive", {
            get() {
                Po = !0
            }
        });
        window.addEventListener("testPassive", null, r), window.removeEventListener("testPassive", null, r)
    } catch (r) {}
    var la = Po;
    var Is = ["touchstart", "mousedown"],
        Io = ["touchmove", "mousemove"],
        Lo = ["touchend", "touchcancel", "mouseup", "mouseleave"],
        Ao = ["mousedown", "mousemove", "mouseup", "mouseleave"];

    function da(r, t, e) {
        let i = new G,
            s = 0,
            a = 0,
            o = 0,
            l = !1,
            d = la ? {
                passive: !0
            } : !1,
            u = {
                mount() {
                    this.bindSwipeStart()
                },
                start(c) {
                    if (!l && !r.disabled) {
                        this.disable();
                        let p = this.touches(c);
                        s = null, a = E(p.pageX), o = E(p.pageY), this.bindSwipeMove(), this.bindSwipeEnd(), e.emit("swipe.start")
                    }
                },
                move(c) {
                    if (!r.disabled) {
                        let {
                            touchAngle: p,
                            touchRatio: g,
                            classes: v
                        } = r.settings, y = this.touches(c), b = E(y.pageX) - a, C = E(y.pageY) - o, k = Math.abs(b << 2), $ = Math.abs(C << 2), P = Math.sqrt(k + $), x = Math.sqrt($);
                        if (s = Math.asin(x / P), s * 180 / Math.PI < p) c.stopPropagation(), t.Move.make(b * no(g)), t.Html.root.classList.add(v.dragging), e.emit("swipe.move");
                        else return !1
                    }
                },
                end(c) {
                    if (!r.disabled) {
                        let {
                            perSwipe: p,
                            touchAngle: g,
                            classes: v
                        } = r.settings, y = this.touches(c), b = this.threshold(c), C = y.pageX - a, k = s * 180 / Math.PI;
                        this.enable(), C > b && k < g ? t.Run.make(t.Direction.resolve(`${p}<`)) : C < -b && k < g ? t.Run.make(t.Direction.resolve(`${p}>`)) : t.Move.make(), t.Html.root.classList.remove(v.dragging), this.unbindSwipeMove(), this.unbindSwipeEnd(), e.emit("swipe.end")
                    }
                },
                bindSwipeStart() {
                    let {
                        swipeThreshold: c,
                        dragThreshold: p
                    } = r.settings;
                    c && i.on(Is[0], t.Html.wrapper, g => {
                        this.start(g)
                    }, d), p && i.on(Is[1], t.Html.wrapper, g => {
                        this.start(g)
                    }, d)
                },
                unbindSwipeStart() {
                    i.off(Is[0], t.Html.wrapper, d), i.off(Is[1], t.Html.wrapper, d)
                },
                bindSwipeMove() {
                    i.on(Io, t.Html.wrapper, he(c => {
                        this.move(c)
                    }, r.settings.throttle), d)
                },
                unbindSwipeMove() {
                    i.off(Io, t.Html.wrapper, d)
                },
                bindSwipeEnd() {
                    i.on(Lo, t.Html.wrapper, c => {
                        this.end(c)
                    })
                },
                unbindSwipeEnd() {
                    i.off(Lo, t.Html.wrapper)
                },
                touches(c) {
                    return Ao.indexOf(c.type) > -1 ? c : c.touches[0] || c.changedTouches[0]
                },
                threshold(c) {
                    let p = r.settings;
                    return Ao.indexOf(c.type) > -1 ? p.dragThreshold : p.swipeThreshold
                },
                enable() {
                    return l = !1, t.Transition.enable(), this
                },
                disable() {
                    return l = !0, t.Transition.disable(), this
                }
            };
        return e.on("build.after", () => {
            t.Html.root.classList.add(r.settings.classes.swipeable)
        }), e.on("destroy", () => {
            u.unbindSwipeStart(), u.unbindSwipeMove(), u.unbindSwipeEnd(), i.destroy()
        }), u
    }

    function ha(r, t, e) {
        let i = new G,
            s = !1,
            a = !1,
            o = {
                mount() {
                    this.Ph = t.Html.wrapper.querySelectorAll("a"), this.bind()
                },
                bind() {
                    i.on("click", t.Html.wrapper, this.click)
                },
                unbind() {
                    i.off("click", t.Html.wrapper)
                },
                click(l) {
                    a && (l.stopPropagation(), l.preventDefault())
                },
                detach() {
                    if (a = !0, !s) {
                        for (var l = 0; l < this.items.length; l++) this.items[l].draggable = !1;
                        s = !0
                    }
                    return this
                },
                attach() {
                    if (a = !1, s) {
                        for (var l = 0; l < this.items.length; l++) this.items[l].draggable = !0;
                        s = !1
                    }
                    return this
                }
            };
        return _(o, "items", {
            get() {
                return o.Ph
            }
        }), e.on("swipe.move", () => {
            o.detach()
        }), e.on("swipe.end", () => {
            t.Transition.after(() => {
                o.attach()
            })
        }), e.on("destroy", () => {
            o.attach(), o.unbind(), i.destroy()
        }), o
    }
    var Eo = '[data-glide-el^="controls"]',
        T6 = `${Eo} [data-glide-dir*="<"]`,
        $6 = `${Eo} [data-glide-dir*=">"]`;

    function ca(r, t, e) {
        let i = new G,
            s = {
                mount() {
                    this.enable(), this.start(), r.settings.hoverpause && this.bind()
                },
                enable() {
                    this.E = !0
                },
                disable() {
                    this.E = !1
                },
                start() {
                    this.E && (this.enable(), r.settings.autoplay && $s(this.Be) && (this.Be = setInterval(() => {
                        this.stop(), t.Run.make(">"), this.start(), e.emit("autoplay")
                    }, this.time)))
                },
                stop() {
                    this.Be = clearInterval(this.Be)
                },
                bind() {
                    i.on("mouseover", t.Html.root, () => {
                        this.E && this.stop()
                    }), i.on("mouseout", t.Html.root, () => {
                        this.E && this.start()
                    })
                },
                unbind() {
                    i.off(["mouseover", "mouseout"], t.Html.root)
                }
            };
        return _(s, "time", {
            get() {
                let a = t.Html.slides[r.index].getAttribute("data-glide-autoplay");
                return a ? E(a) : E(r.settings.autoplay)
            }
        }), e.on(["destroy", "update"], () => {
            s.unbind()
        }), e.on(["run.before", "swipe.start", "update"], () => {
            s.stop()
        }), e.on(["pause", "destroy"], () => {
            s.disable(), s.stop()
        }), e.on(["run.after", "swipe.end"], () => {
            s.start()
        }), e.on(["play"], () => {
            s.enable(), s.start()
        }), e.on("update", () => {
            s.mount()
        }), e.on("destroy", () => {
            i.destroy()
        }), s
    }

    function Bo(r) {
        return jt(r) ? ho(r) : (K("Breakpoints option must be an object"), {})
    }

    function ua(r, t, e) {
        let i = new G,
            s = r.settings,
            a = Bo(s.breakpoints),
            o = Object.assign({}, s),
            l = {
                match(d) {
                    if (typeof window.matchMedia != "undefined") {
                        for (let u in d)
                            if (d.hasOwnProperty(u) && window.matchMedia(`(max-width: ${u}px)`).matches) return d[u]
                    }
                    return o
                }
            };
        return Object.assign(s, l.match(a)), i.on("resize", window, he(() => {
            r.settings = ss(s, l.match(a))
        }, r.settings.throttle)), e.on("update", () => {
            a = Bo(a), o = Object.assign({}, s)
        }), e.on("destroy", () => {
            i.off("resize", window)
        }), l
    }
    var Vn = {
        Html: po,
        Translate: To,
        Transition: $o,
        Direction: xo,
        Peek: mo,
        Sizes: vo,
        Gaps: uo,
        Move: go,
        Clones: bo,
        Resize: yo,
        Build: wo,
        Run: co
    };
    var ns = class extends os {
        mount(t = {}) {
            return super.mount(Object.assign({}, Vn, t))
        }
    };
    var ls = class extends Ve {
        get Js() {
            return `<a href="${this.Xs}" class="fera-review-product-link" ${this.app.config.designMode?"data-fera-design-disabled":""}>${this.Ui}</a>`
        }
        get ue() {
            return ""
        }
    };
    var ds = class extends mt {
        constructor(t) {
            super(n({
                openModalOnClick: !0
            }, t)), this.review.product && (this.product = new ls(n({}, this.i)))
        }
        get i() {
            return h(n({}, super.i), {
                lazyLoad: !0
            })
        }
        Vt() {
            return super.Vt("130xs300")
        }
        ot() {
            return super.ot("170")
        }
        get s() {
            return `<div ${this.Je} tabindex="-1">
    <div class="fera-review-content">
        ${this.Ye}
        ${this.Ze}
        ${this.ot()}
        ${this.Xe}
        ${this.Dt()}
        ${this.me}
        ${this.Vt()}
    </div>
</div>`
        }
    };
    var mi = class extends It {
        constructor(t) {
            super(t), this.addClass("fera-testimonialCarousel-widget"), this.Ih = I(this.Qr.bind(this), 100), this.K = []
        }
        r() {
            super.r(), this.collection = new _t(this.ct), this.collection.load().then(() => this.tt())
        }
        get ct() {
            let t = {
                app: this.app,
                params: this.widgetModel.collectionParams,
                usePagination: this.widgetModel.usePagination
            };
            return this.widgetModel.get("types_to_show", "both") !== "both" && (t.params.subject = this.widgetModel.get("types_to_show") === "product" ? "product" : "store"), this.widgetModel.is("only_with_content") && (t.params.only_with_content = !0), this.usingSampleData && (t.params.samples = !0), t
        }
        tt() {
            this.collection.on("load:before", () => this.P()), this.collection.on("load:after", () => this.C()), this.collection.length < 1 ? this.addChild(new nt({
                app: this.app,
                content: this.t("There are no reviews to show right now. Check back again soon!")
            })) : (this.K = this.collection.models.map(t => new ds(h(n({}, this.i), {
                c: "fera-slider-slide",
                review: t
            }))), this.addChildren(this.K), this.Lh = !0, this.Qr()), this.xt()
        }
        xt() {
            this.app.seoService.removeFromWidget(this)
        }
        h() {
            super.h(), this.Lh && this.Qr()
        }
        destroy() {
            this.po(), super.destroy()
        }
        po() {
            if (this.glide) try {
                this.glide.destroy()
            } catch (t) {
                this.ft(`Glide destroy error ignored. ${t.message}`)
            }
        }
        get Ah() {
            if (this.widgetModel.is("autoplay_enabled")) return this.widgetModel.get("autoplay_speed", 5e3)
        }
        get Eh() {
            return Math.ceil(this.el.getBoundingClientRect().width / 575)
        }
        get Bh() {
            return {
                perView: this.Eh,
                gap: 24,
                type: "carousel",
                autoplay: this.Ah,
                direction: this.Oh,
                classes: {
                    direction: {
                        ltr: "fera-slider--ltr",
                        rtl: "fera-slider--rtl"
                    },
                    slider: "fera-slider--slider",
                    carousel: "fera-slider--carousel",
                    swipeable: "fera-slider--swipeable",
                    dragging: "fera-slider--dragging",
                    cloneSlide: "fera-slider-slide--clone",
                    activeNav: "fera-slider-bullet--active",
                    activeSlide: "fera-slider-slide--active",
                    disabledArrow: "fera-slider-arrow--disabled"
                }
            }
        }
        get Oh() {
            return this.app.cssService.detectedTextDirection
        }
        mo() {
            if (!this.el) return;
            let t = this.el.querySelector(".glide__slide--active");
            if (!t) return;
            this.bi(t);
            let e = Math.round(document.body.offsetWidth / (t.offsetWidth || 200) / 2),
                i = t.previousSibling,
                s = t.nextSibling;
            for (let a = 0; a < e; a++) this.bi(i), this.bi(s), i = i.previousSibling, s = s.nextSibling;
            this.bi(s)
        }
        bi(t) {
            return t ? (t.querySelectorAll("img[data-src]:not([src])").forEach(e => e.src = e.dataset.src), !0) : !1
        }
        Qr() {
            this.po(), !(!this.rendered || this.destroyed) && (this.glide = new ns("[data-fera-carousel-track]", this.Bh), this.glide.mount({
                Breakpoints: ua,
                Swipe: da,
                Anchors: ha,
                Autoplay: ca
            }), this.vo || (this.vo = new ResizeObserver(() => {
                !this.rendered || this.destroyed || this.wo && this.wo == globalThis.innerWidth || (this.wo = globalThis.innerWidth, this.Ih())
            }), this.vo.observe(this.el)), this.glide.on("move.after", I(() => this.mo(), 250)), this.mo(), this.Ei(), this.refreshView())
        }
        Ei() {
            let t = !1,
                e = {},
                i = () => {
                    t = !1, e = {}, this.K.forEach(s => s.clickListenersDisabled = !1)
                };
            this.el.addEventListener("mousedown", s => {
                i(), e = {
                    x: s.clientX,
                    y: s.clientY
                }
            }), this.el.addEventListener("mouseup", () => {
                setTimeout(i, 10)
            }), this.el.addEventListener("mousemove", s => {
                if (!e.x) return;
                let a = s.clientX - e.x,
                    o = s.clientY - e.y;
                !t && (Math.abs(a) > 10 || Math.abs(o) > 10) && (t = !0, this.K.forEach(l => l.clickListenersDisabled = !0))
            })
        }
        get i() {
            return h(n({}, super.i), {
                collection: this.collection,
                widgetModel: this.widgetModel,
                includeSeoAttributes: !1,
                showProduct: this.widgetModel.is("products_visible")
            })
        }
        get pe() {
            return this.i
        }
        get L() {
            return Et.defaultTypeSettings
        }
        get s() {
            return `<div id="testimonials">
  ${this.ja}
  <div data-fera-carousel-track class="fera-slider">
    <div class="fera-slider-track" data-glide-el="track">
      <div data-fera-child-container class="fera-carousel-body fera-slider-slides"></div>
    </div>
  </div>
</div>`
        }
    };
    var hs = class extends It {
        constructor(t) {
            super(t), this.addClass("fera-overallRatingBanner-widget"), this.stars = new Ht({
                app: this.app,
                value: this.averageRating,
                includeSeoAttributes: !1
            }), this.verificationIcon = new Jt({
                app: this.app,
                onClick: this.e.onVerificationClick
            })
        }
        get za() {
            return !0
        }
        get zh() {
            return this.verifiedReviewCount / this.reviewCount >= .5
        }
        get rating() {
            let t = this.O || this.store.rating;
            return this.usingSampleData ? {
                average: 4.5,
                count: 123,
                verified_count: 65
            } : (!t || t.count <= 0) && this.app.config.designMode ? {
                average: 4.5,
                count: 123,
                verified_count: 65
            } : t
        }
        get averageRating() {
            return this.rating.average
        }
        get reviewCount() {
            return this.rating.count
        }
        get verifiedReviewCount() {
            return this.rating.verified_count
        }
        get Lr() {
            return parseFloat(this.averageRating).toFixed(1)
        }
        get Ar() {
            return `<span class="fera-overallRatingBanner-rating-number">${this.Lr}</span>`
        }
        get Ie() {
            return `<span data-fera-rating-count="${this.reviewCount}"
    class="fera-overallRatingBanner-rating-count-total" data-fera-rating-count-number
    data-value="${this.reviewCount}">${this.formatNumber(this.reviewCount,{notation:"compact"})}</span>`
        }
        get jh() {
            return !this.options.stars_visible || !this.averageRating ? "" : '<span class="fera-overallRatingBanner-rating-stars" data-fera-component="stars"></span>'
        }
        get Vh() {
            return `<span>${this.t("Overall Average Rating")}</span>`
        }
        get Dh() {
            let t = {
                average: this.averageRating,
                count: this.reviewCount,
                formatted_count: this.Ie
            };
            return `<span>${this.t("{{ formatted_count }} Customer Review{% if count != 1 %}s{% endif %}",t)}</span>`
        }
        get L() {
            return Ft.defaultTypeSettings
        }
        get s() {
            return `<div id="overallRatingBanner">
    <div class="fera-overallRatingBanner-widget-content">
        <div class="fera-overallRatingBanner-firstLineText">${this.Vh}</div>
        <div class="fera-overallRatingBanner-rating-container">
            <svg class="fera-overallRatingBanner-leftRibbon" width="39" height="86" viewBox="0 0 39 86" fill="none" xmlns="http://www.w3.org/2000/svg"><!-- Left Ribbon SVG Path Here -->
                <path d="M38.4338 0.898905C25.5381 0.629314 27.1354 7.98277 27.1354 7.98277C27.1354 7.98277 33.0173 12.6567 38.4338 0.898905Z" fill="#171717" />
                <path d="M24.3413 0C14.2933 8.11026 20.2253 12.7161 20.2253 12.7161C20.2253 12.7161 27.7213 12.4899 24.3413 0Z" fill="#171717" />
                <path d="M14.4346 9.53403C5.9448 19.2772 12.5845 22.7784 12.5845 22.7784C12.5845 22.7784 19.9275 21.251 14.4346 9.53403Z" fill="#171717" />
                <path d="M6.57925 20.7358C1.91907 32.7965 9.34871 33.8139 9.34871 33.8139C9.34871 33.8139 15.7297 29.8499 6.57925 20.7358Z" fill="#171717" />
                <path d="M1.95875 31.9378C1.69017 44.8825 9.01575 43.2792 9.01575 43.2792C9.01575 43.2792 13.6634 37.358 1.95875 31.9378Z" fill="#171717" />
                <path d="M0.5 42.3293C2.46694 55.1175 9.4124 52.2654 9.4124 52.2654C9.4124 52.2654 12.9722 45.638 0.5 42.3293Z" fill="#171717" />
                <path d="M3.06501 53.4426C7.22248 65.694 13.5652 61.6753 13.5652 61.6753C13.5652 61.6753 15.9079 54.5244 3.06501 53.4426Z" fill="#171717" />
                <path d="M8.15035 64.1689C14.365 75.5167 19.9121 70.4512 19.9121 70.4512C19.9121 70.4512 20.993 63.0013 8.15035 64.1689Z" fill="#171717" />
                <path d="M14.7472 74.8118C24.4534 83.3339 27.9413 76.6689 27.9413 76.6689C27.9413 76.6689 26.4156 69.3107 14.7472 74.8118Z" fill="#171717" />
                <path d="M23.9011 82.7037C34.5709 89.9796 37.2135 82.9406 37.2135 82.9406C37.2135 82.9406 34.8134 75.8173 23.9011 82.7037Z" fill="#171717" />
                <path d="M32.7205 12.4051C20.0733 9.89687 20.3703 17.4167 20.3703 17.4167C20.3703 17.4167 25.3579 23.0361 32.7205 12.4051Z" fill="#171717" />
                <path d="M23.8184 20.5236C11.0787 22.498 13.9199 29.4699 13.9199 29.4699C13.9199 29.4699 20.5222 33.0432 23.8184 20.5236Z" fill="#171717" />
                <path d="M20.3732 30.6048C8.16826 34.7781 12.1717 41.145 12.1717 41.145C12.1717 41.145 19.2914 43.5093 20.3732 30.6048Z" fill="#171717" />
                <path d="M18.9407 41.694C7.63593 47.9323 12.6822 53.5005 12.6822 53.5005C12.6822 53.5005 20.108 54.5729 18.9407 41.694Z" fill="#171717" />
                <path d="M21.5292 49.7923C11.4812 57.9026 17.4131 62.5085 17.4131 62.5085C17.4131 62.5085 24.9092 62.2822 21.5292 49.7923Z" fill="#171717" />
                <path d="M24.9437 57.3727C18.2668 68.4382 25.407 70.739 25.407 70.739C25.407 70.739 32.374 67.9502 24.9437 57.3727Z" fill="#171717" />
                <path d="M30.5324 67.2795C30.2638 80.2242 37.5894 78.6208 37.5894 78.6208C37.5894 78.6208 42.2371 72.6997 30.5324 67.2795Z" fill="#171717" />
            </svg>
            <div class="fera-overallRatingBanner-rating">
                ${this.Ar}
                ${this.jh}
            </div>
            <svg class="fera-overallRatingBanner-rightRibbon" width="39" height="86" viewBox="0 0 39 86" fill="none" xmlns="http://www.w3.org/2000/svg"><!-- Right Ribbon SVG Path Here -->
                <path d="M0.566396 0.898847C13.4621 0.629256 11.8648 7.98269 11.8648 7.98269C11.8648 7.98269 5.98286 12.6566 0.566396 0.898847Z" fill="#171717" />
                <path d="M14.6589 0C24.7069 8.11025 18.775 12.7161 18.775 12.7161C18.775 12.7161 11.279 12.4899 14.6589 0Z" fill="#171717" />
                <path d="M24.5656 9.5344C33.0554 19.2776 26.4157 22.7787 26.4157 22.7787C26.4157 22.7787 19.0727 21.2513 24.5656 9.5344Z" fill="#171717" />
                <path d="M32.4207 20.7356C37.0808 32.7963 29.6512 33.8137 29.6512 33.8137C29.6512 33.8137 23.2702 29.8497 32.4207 20.7356Z" fill="#171717" />
                <path d="M37.0412 31.9377C37.3097 44.8824 29.9842 43.2791 29.9842 43.2791C29.9842 43.2791 25.3365 37.3579 37.0412 31.9377Z" fill="#171717" />
                <path d="M38.5 42.3288C36.5331 55.117 29.5876 52.2649 29.5876 52.2649C29.5876 52.2649 26.0279 45.6375 38.5 42.3288Z" fill="#171717" />
                <path d="M35.935 53.4428C31.7775 65.6942 25.4348 61.6755 25.4348 61.6755C25.4348 61.6755 23.0921 54.5246 35.935 53.4428Z" fill="#171717" />
                <path d="M30.8497 64.1687C24.6351 75.5165 19.088 70.4511 19.088 70.4511C19.088 70.4511 18.007 63.0011 30.8497 64.1687Z" fill="#171717" />
                <path d="M24.2529 74.8118C14.5466 83.3339 11.0588 76.669 11.0588 76.669C11.0588 76.669 12.5845 69.3108 24.2529 74.8118Z" fill="#171717" />
                <path d="M15.099 82.7037C4.42917 89.9796 1.78658 82.9406 1.78658 82.9406C1.78658 82.9406 4.18666 75.8173 15.099 82.7037Z" fill="#171717" />
                <path d="M6.27967 12.405C18.9269 9.89683 18.6299 17.4166 18.6299 17.4166C18.6299 17.4166 13.6423 23.036 6.27967 12.405Z" fill="#171717" />
                <path d="M15.1816 20.5238C27.9212 22.4983 25.08 29.4701 25.08 29.4701C25.08 29.4701 18.4777 33.0434 15.1816 20.5238Z" fill="#171717" />
                <path d="M18.6269 30.6047C30.8319 34.778 26.8285 41.1448 26.8285 41.1448C26.8285 41.1448 19.7088 43.5091 18.6269 30.6047Z" fill="#171717" />
                <path d="M20.0597 41.6935C31.3644 47.9318 26.3182 53.5 26.3182 53.5C26.3182 53.5 18.8924 54.5723 20.0597 41.6935Z" fill="#171717" />
                <path d="M17.4709 49.7922C27.5189 57.9025 21.5869 62.5084 21.5869 62.5084C21.5869 62.5084 14.0909 62.2821 17.4709 49.7922Z" fill="#171717" />
                <path d="M14.0564 57.3728C20.7334 68.4382 13.5931 70.739 13.5931 70.739C13.5931 70.739 6.62613 67.9502 14.0564 57.3728Z" fill="#171717" />
                <path d="M8.46759 67.2795C8.73616 80.2243 1.41059 78.6209 1.41059 78.6209C1.41059 78.6209 -3.23706 72.6997 8.46759 67.2795Z" fill="#171717" />
            </svg>
        </div>
        <div class="fera-overallRatingBanner-secondLineText">
            ${this.Dh}
            ${this.zh?'<svg class="fera-overallRatingBanner-verification-icon" data-fera-component="verificationIcon"></svg>':""}
        </div>
    </div>
</div>`
        }
    };
    var cs = class extends w {
        initModelFromElement(t, e = {}) {
            let i = t.dataset,
                s = i.type || i.feraWidget || i.feraContainer,
                a = i.product || i.productId || i.product_id;
            e.app = this.app;
            let o = i.editor;
            o && (o = o.replace("shopify_dawn", "shopify_theme_editor"));
            let l, d;
            if (i.feraWidgetId && (d = this.app.store.widgets.find(u => u.id === i.feraWidgetId)), !d && o) {
                let u = o;
                d = this.app.store.widgets.find(c => c.get("type") === s && c.installation.method === u)
            }
            return d = d || this.app.store.widgets.find(u => u.get("type") === s), d && (l = d.clone()), l = l || be.initModel({
                type: s,
                product: a,
                editor: o
            }, e), l.installation.method != o && (l.set("installation_method", o || "tag"), l.set("conditions", {})), l.loadDataFromElement(t), l
        }
        static initModelFromComponent(t, e = {}, i = {}) {
            if (t instanceof mi) return new Et(e, i);
            if (t instanceof re) return new Ct(e, i);
            if (t instanceof fi) return new st(e, i);
            if (t instanceof de) return new Lt(e, i);
            if (t instanceof ui) return new At(e, i);
            throw new Error(`Unknown widget model for '${t}'.`)
        }
        initComponent(t) {
            if (t.widgetModel instanceof Et) return new mi(t);
            if (t.widgetModel instanceof et) return new Ke(t);
            if (t.widgetModel instanceof tt) return new Qe(t);
            if (t.widgetModel instanceof st) return new fi(h(n({}, t), {
                subject: "product"
            }));
            if (t.widgetModel instanceof Lt) return new de(t);
            if (t.widgetModel instanceof At) return new ui(h(n({}, t), {
                subject: "product"
            }));
            if (t.widgetModel instanceof Ft) return new hs(t);
            throw new Error(`Unknown widget type '${t.widgetModel.get("type")}' for element.`)
        }
        create({
            element: t = null,
            container: e = null,
            widgetModel: i = null
        }) {
            let s = t || e,
                a = {
                    app: this.app,
                    widgetModel: i
                };
            if (s) {
                if (s.fera) return Promise.resolve(s.fera);
                a.widgetModel = this.Nh(s)
            } else {
                if (i) return this.Fh(i, a);
                throw new Error("WidgetFactory.create requires either an element, container, or widgetModel.")
            }
            if (t) a.el = t;
            else if (e) a.container = e;
            else throw new Error("WidgetFactory.create requires either an element or container.");
            return this.ts(a)
        }
        Fh(t, e) {
            return m(this, null, function*() {
                if (t.managedInFera && t.installation.disabled && this.app.request.getFeraParam("widget") !== t.id) return this.b("Widget disabled and not previewing so it was not rendered.", t), null;
                if (t.autoIntegrated) {
                    let i = Array.from(t.autoIntegrationPossibilities).map(o => o.selector);
                    if (this.app.plugins.some(o => typeof o.supportsAutomaticWidgetIntegration == "function" && o.supportsAutomaticWidgetIntegration(t.type))) return null;
                    if (i.length < 1 && t.isVisible) throw new Error(`Automatic widget installation requested for widget ${t.type} but no possible installation options provided.`);
                    let s = yield this.bo(i, {
                        widgetModel: t
                    });
                    if (!s) return null;
                    let a = t.autoIntegrationPossibilities.find(o => o.selector === s);
                    return e.container = this.es(a.selector), e.container.feraWidgets && e.container.feraWidgets.find(o => o.widgetModel.id === t.id) ? null : this.ts(e, a.action)
                } else if (t.installation.selector) {
                    if (!(yield this.bo([t.installation.selector], {
                            widgetModel: t
                        }))) return null;
                    e.container = this.es(t.installation.selector);
                    let s = e.container.feraWidgets && e.container.feraWidgets.find(a => a.widgetModel.id === t.id);
                    if (s) try {
                        s.destroy(), e.container.feraWidgets && (e.container.feraWidgets = e.container.feraWidgets.filter(a => a !== s))
                    } catch (a) {
                        this.b("Error destroying duplicate widget", a.message)
                    }
                    return this.ts(e, t.installation.action)
                } else throw new Error(`Missing selector for widget ${t.get("type")} installation and installation mode is not 'auto'.`)
            })
        }
        Nh(t) {
            let e;
            return e ? e.loadDataFromElement(t) : e = this.initModelFromElement(t), e
        }
        es(t) {
            return document.querySelector(t.replace(/:(last|first)([^-])/g, ":$1-child$2").replace(/:(last|first)$/g, ":$1-child"))
        }
        bo(t, {
            widgetModel: e = null,
            timeout: i = 1e3
        } = {
            timeout: 1e3,
            widgetModel: null
        }) {
            let s = 0;
            return new Promise(a => {
                let o = () => {
                    let l = Array.from(t).find(d => this.es(d));
                    l ? a(l) : s === i ? (e.isVisible && globalThis.parent == window && this.b(`No suitable automatic installation location for widget could be found after ${i}ms.`, e), a(null)) : setTimeout(() => {
                        s += 100, o()
                    }, 100)
                };
                o()
            })
        }
        rs(t) {
            if (!t || t.tagName === "BODY") return null;
            if (t && t.dataset) {
                if (t.dataset.productId) return t.dataset.productId;
                if (t.dataset.product_id) return t.dataset.product_id;
                if (t.dataset.product) return t.dataset.product
            }
            return t.parentElement ? this.rs(t.parentElement) : null
        }
        ts(t, e = "append_to") {
            return m(this, null, function*() {
                if (t.productId = this.rs(t.el) || this.rs(t.container), t.productId = t.productId || t.widgetModel.productId, t.productId = t.productId || (yield this.app.retrieveCurrentProductIdFromPlugins()), !t.widgetModel.hasValidOptsToRender(t)) return null;
                t.insertionMode = t.insertionMode || e;
                let i = this.initComponent(t);
                if (!(yield t.widgetModel.conditions.match(this.app.getState({
                        product_id: t.productId
                    }))) || !t.widgetModel.isVisible) return null;
                if (t.widgetModel.id && i.addClass(`fera-${t.widgetModel.id}`), t.container) yield this.qh(t, i);
                else {
                    if (t.el.fera) return t.el.fera;
                    t.el.fera = i, i.el = t.el, yield i.renderAsync()
                }
                return this.Wh(t.widgetModel, i), i
            })
        }
        qh(t, e) {
            return m(this, null, function*() {
                t.container.feraWidgets = t.container.feraWidgets || [], t.container.feraWidgets.push(e), yield e.renderAsync(), t.insertionMode === "insert_after" ? t.container.after(e.el) : t.insertionMode === "insert_before" ? t.container.before(e.el) : t.insertionMode === "prepend_to" ? t.container.prepend(e.el) : t.insertionMode === "replace" ? t.container.replaceWith(e.el) : t.container.append(e.el)
            })
        }
        Wh(t, e) {
            this.Hh || t.id && t.isDeactivated && this.app.request.getFeraParam("widget") == t.id && (Ge.info({
                app: this.app,
                body: `The ${t.get("name","fera")} widget you're previewing on this page has been deactivated so it <b>won't show to customers</b> but you'll still see it here.`,
                title: "Deactivated Widgets Still Show in Previews",
                primaryBtn: {
                    text: "Continue Preview",
                    onClick: () => {
                        e.scrollIntoView()
                    }
                },
                secondaryBtn: {
                    text: "View Live Site",
                    onClick: () => {
                        this.app.request.removeParams({
                            fera_widget: t.id
                        }), globalThis.location.reload()
                    }
                }
            }), this.Hh = !0)
        }
    };
    var us = class extends w {
        constructor(t) {
            super(t), this.F = []
        }
        static get pageConfiguredElements() {
            return Array.from(document.querySelectorAll("[data-fera-widget],[data-fera-container]")).filter(t => {
                var e;
                return !((e = t.dataset.feraContainer) != null && e.match(/^\d+$/) || t.dataset.feraSkill)
            })
        }
        static get yo() {
            return {
                apiKey: ["api_key", "api-key", "apiKey", "store_pk", "store-pk", "storePk", "public_key", "public-key", "publicKey"],
                apiUrl: ["api_url", "api-url", "apiUrl"],
                cdnUrl: ["cdn_url", "cdn-url", "cdnUrl"],
                apiCdnUrl: ["api_cdn_url", "api-cdn-url", "apiCdnUrl"],
                designMode: ["design_mode", "design-mode", "designMode", "fera-design", "fera_design", "feraDesign"],
                locale: ["locale", "language", "lang"]
            }
        }
        static getAttributeConfig() {
            return this.pageConfiguredElements.reduce((t, e) => {
                let i = {};
                return Object.keys(this.yo).forEach(s => {
                    var a;
                    for (let o of this.yo[s]) {
                        let l = (a = e == null ? void 0 : e.dataset) == null ? void 0 : a[o];
                        if (typeof l != "undefined") {
                            i[s] = l;
                            break
                        }
                    }
                }), n(n({}, t), i)
            }, {})
        }
        initModelFromElement(t) {
            return this.factory.initModelFromElement(t)
        }
        get factory() {
            return this.Uh || (this.Uh = new cs({
                app: this.app
            }))
        }
        load() {
            this.isLoading = !0, this.xo(), this.Zh()
        }
        reload() {
            this.isLoading = !0, this.clear(), this.load()
        }
        clear() {
            for (let t = this.F.length - 1; t >= 0; t--) this.F[t].canBeRemovedViaFera && (this.F[t].destroy(), this.F[t] = null);
            this.F = this.F.filter(t => t)
        }
        get widgets() {
            return this.F
        }
        ss(t) {
            if (t) {
                if (Array.isArray(t)) return t.forEach(e => this.ss(e));
                this.F.includes(t) || this.F.push(t)
            }
        }
        Zh() {
            this.as = [], this.Yh = this.app.store.widgets, this.Yh.forEach(t => {
                if (!t.selectorIntegrated && !t.autoIntegrated) {
                    this.as.push(t), this.yi();
                    return
                }
                this.factory.create({
                    widgetModel: t
                }).then(e => {
                    this.as.push(t), this.ss(e), this.yi()
                })
            })
        }
        yi() {
            this.as.length == this.app.store.widgets.length && this.os.length == this.Co.length && (this.isLoading = !1)
        }
        xo() {
            this.os = [], this.Co = this.constructor.pageConfiguredElements, this.Co.forEach(t => {
                let e = this.Xh(t);
                e ? e.then(i => {
                    this.os.push(t), this.ss(i), this.yi()
                }) : (this.os.push(t), this.yi())
            }), this.Jh()
        }
        Xh(t) {
            return this.factory.create({
                element: t
            })
        }
        Jh() {
            this._o || (this._o = new MutationObserver(t => {
                t.forEach(e => {
                    !e.addedNodes || Array.from(e.addedNodes).every(s => {
                        let a = s;
                        for (; a;) {
                            if (a.fera) return !0;
                            a = a.parentNode
                        }
                        return !1
                    }) || this.xo()
                })
            }), this._o.observe(document.body, {
                childList: !0,
                subtree: !0,
                attributes: !1,
                characterData: !1
            }))
        }
    };
    ci.init({
        pushBuffer: globalThis.fera,
        WidgetLoader: us
    });
    var mS = ci;
})();