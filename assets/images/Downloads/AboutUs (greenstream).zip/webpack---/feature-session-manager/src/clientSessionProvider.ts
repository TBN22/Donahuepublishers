import { fetchDynamicModel } from '@wix/thunderbolt-commons'
import { named, withDependencies } from '@wix/thunderbolt-ioc'
import type { ISessionProvider, SessionManagerSiteConfig } from './types'
import {
	DynamicModelSymbol,
	Fetch,
	LoggerSymbol,
	SiteFeatureConfigSymbol,
	Experiments,
	ExperimentsSymbol,
} from '@wix/thunderbolt-symbols'
import type { IFetchApi, ILogger, DynamicSessionModel } from '@wix/thunderbolt-symbols'
import { name } from './symbols'

export const ClientSessionProvider = withDependencies(
	[DynamicModelSymbol, named(SiteFeatureConfigSymbol, name), Fetch, ExperimentsSymbol, LoggerSymbol],
	(
		dynamicModel: DynamicSessionModel,
		siteFeatureConfig: SessionManagerSiteConfig,
		fetchApi: IFetchApi,
		experiments: Experiments,
		logger: ILogger
	): ISessionProvider => {
		let currentSession: Partial<DynamicSessionModel> = dynamicModel

		return {
			getCurrentSession: () => currentSession,
			loadNewSession: async ({ authorizationCode }) => {
				try {
					const accessTokensEndpoint = experiments['specs.thunderbolt.replaceDynamicModel']
						? siteFeatureConfig.accessTokensApiUrl
						: siteFeatureConfig.dynamicModelApiUrl

					if (experiments['specs.thunderbolt.hardenFetchAndXHR']) {
						const fetchArgs: RequestInit = {
							credentials: 'same-origin',
							...(authorizationCode && { headers: { authorization: authorizationCode } }),
						}
						const accessTokens = await fetchDynamicModel(fetchArgs)

						return accessTokens
					} else {
						const res = await fetchApi.envFetch(accessTokensEndpoint, {
							credentials: 'same-origin',
							...(authorizationCode && { headers: { authorization: authorizationCode } }),
						})

						if (!res.ok) {
							throw new Error(`[${res.status}]${res.statusText}`)
						}

						currentSession = await res.json()
						return currentSession
					}
				} catch (error) {
					logger.captureError(new Error(`failed fetching dynamicModel`), {
						tags: { feature: 'session-manager', fetchFail: 'dynamicModel' },
						extra: { errorMessage: error.message },
					})
					throw error
				}
			},
		}
	}
)
