(function(g) {
    var window = this;
    /*
     SPDX-License-Identifier: Apache-2.0
    */
    /*

     Copyright Google LLC All Rights Reserved.

     Use of this source code is governed by an MIT-style license that can be
     found in the LICENSE file at https://angular.io/license
    */
    /*

     Copyright 2017 Google LLC
     SPDX-License-Identifier: BSD-3-Clause
    */
    'use strict';
    var $pb = function(a) {
            a.mutedAutoplay = !1;
            a.endSeconds = NaN;
            a.limitedPlaybackDurationInSeconds = NaN;
            g.VS(a)
        },
        aqb = function() {
            return {
                I: "svg",
                X: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                V: [{
                    I: "path",
                    Ic: !0,
                    S: "ytp-svg-fill",
                    X: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        bqb = function() {},
        g5 = function(a, b) {
            for (; a.length > b;) a.pop()
        },
        cqb = function(a) {
            a = Array(a);
            g5(a, 0);
            return a
        },
        dqb = function(a, b, c) {
            if (null == c) a.removeAttribute(b);
            else {
                var d = 0 === b.lastIndexOf("xml:", 0) ? "http://www.w3.org/XML/1998/namespace" : 0 === b.lastIndexOf("xlink:", 0) ? "http://www.w3.org/1999/xlink" : null;
                d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)
            }
        },
        fqb = function(a, b, c) {
            a = a.style;
            if ("string" === typeof c) a.cssText = c;
            else {
                a.cssText = "";
                for (var d in c)
                    if (eqb.call(c, d)) {
                        b = a;
                        var e = d,
                            f = c[d];
                        0 <= e.indexOf("-") ? b.setProperty(e, f) : b[e] = f
                    }
            }
        },
        gqb = function(a, b, c) {
            var d = typeof c;
            "object" === d || "function" === d ? a[b] = c : dqb(a, b, c)
        },
        hqb = function() {
            var a = new bqb;
            a.__default = gqb;
            a.style = fqb;
            return a
        },
        iqb = function(a, b, c, d) {
            (d[b] || d.__default)(a, b, c)
        },
        jqb = function(a) {
            this.created = [];
            this.j = [];
            this.node = a
        },
        kqb = function(a, b) {
            this.j = null;
            this.B = a;
            this.key = b;
            this.text = void 0
        },
        lqb = function(a, b, c) {
            b = new kqb(b, c);
            return a.__incrementalDOMData = b
        },
        h5 = function(a, b) {
            if (a.__incrementalDOMData) return a.__incrementalDOMData;
            var c = 1 === a.nodeType ? a.localName : a.nodeName,
                d = 1 === a.nodeType ? a.getAttribute("key") : null;
            b = lqb(a, c, 1 === a.nodeType ? d || b : null);
            if (1 === a.nodeType && (a = a.attributes, c = a.length)) {
                d = b.j || (b.j = cqb(2 * c));
                for (var e = 0, f = 0; e < c; e += 1, f += 2) {
                    var h = a[e],
                        l = h.value;
                    d[f] = h.name;
                    d[f + 1] = l
                }
            }
            return b
        },
        mqb = function(a, b, c, d, e) {
            return b == c && d == e
        },
        l5 = function(a) {
            for (var b = i5, c = j5(); c !== a;) {
                var d = c.nextSibling;
                b.removeChild(c);
                k5.j.push(c);
                c = d
            }
        },
        j5 = function() {
            return m5 ? m5.nextSibling : i5.firstChild
        },
        nqb = function(a, b) {
            m5 = j5();
            var c;
            a: {
                if (c = m5) {
                    do {
                        var d = c,
                            e = a,
                            f = b,
                            h = h5(d, f);
                        if (n5(d, e, h.B, f, h.key)) break a
                    } while (b && (c = c.nextSibling))
                }
                c = null
            }
            c || ("#text" === a ? (a = o5.createTextNode(""), lqb(a, "#text", null)) : (c = o5, d = i5, "function" === typeof a ? c = new a : c = (d = "svg" === a ? "http://www.w3.org/2000/svg" : "math" === a ? "http://www.w3.org/1998/Math/MathML" : null == d || "foreignObject" === h5(d).B ? null : d.namespaceURI) ? c.createElementNS(d, a) : c.createElement(a), lqb(c, a, b), a = c), k5.created.push(a), c = a);
            a = c;
            if (a !== m5) {
                if (0 <= p5.indexOf(a))
                    for (b = i5, c = a.nextSibling,
                        d = m5; null !== d && d !== a;) e = d.nextSibling, b.insertBefore(d, c), d = e;
                else i5.insertBefore(a, m5);
                m5 = a
            }
        },
        oqb = function(a, b) {
            nqb(a, b);
            i5 = m5;
            m5 = null;
            return i5
        },
        qqb = function(a, b) {
            b = void 0 === b ? {} : b;
            var c = void 0 === b.matches ? mqb : b.matches;
            return function(d, e, f) {
                var h = k5,
                    l = o5,
                    m = p5,
                    n = q5,
                    p = m5,
                    q = i5,
                    r = n5;
                o5 = d.ownerDocument;
                k5 = new jqb(d);
                n5 = c;
                q5 = [];
                m5 = null;
                var t = i5 = d.parentNode,
                    v, x = pqb.call(d);
                if ((v = 11 === x.nodeType || 9 === x.nodeType ? x.activeElement : null) && d.contains(v)) {
                    for (x = []; v !== t;) x.push(v), v = v.parentNode || (t ? v.host : null);
                    t = x
                } else t = [];
                p5 = t;
                try {
                    return a(d, e, f)
                } finally {
                    d = k5, r5 && 0 < d.j.length && r5(d.j), o5 = l, k5 = h, n5 = r, q5 = n, m5 = p, i5 = q, p5 = m
                }
            }
        },
        rqb = function(a, b, c, d) {
            s5.push(iqb);
            s5.push(a);
            s5.push(b);
            s5.push(c);
            s5.push(d)
        },
        sqb = function(a) {
            nqb("#text", null);
            var b = m5;
            var c = h5(b);
            if (c.text !== a) {
                c = c.text = a;
                for (var d = 1; d < arguments.length; d += 1) c = (0, arguments[d])(c);
                b.data !== c && (b.data = c)
            }
        },
        u5 = function(a, b) {
            var c = t5;
            t5 = a;
            try {
                return b()
            } finally {
                t5 = c
            }
        },
        tqb = function(a, b) {
            return Object.is(a, b)
        },
        v5 = function(a) {
            var b = uqb;
            uqb = a;
            return b
        },
        vqb = function(a) {
            a.Yl = !0;
            if (void 0 !== a.wk) {
                var b = w5;
                w5 = !0;
                try {
                    for (var c = g.u(a.wk), d = c.next(); !d.done; d = c.next()) {
                        var e = d.value;
                        e.Yl || vqb(e)
                    }
                } finally {
                    w5 = b
                }
            }
            var f;
            null == (f = a.dW) || f.call(a, a)
        },
        wqb = function(a) {
            a && (a.XP = 0);
            return v5(a)
        },
        zqb = function(a, b) {
            v5(b);
            if (a && void 0 !== a.Gk && void 0 !== a.Ar && void 0 !== a.cB) {
                if (xqb(a))
                    for (b = a.XP; b < a.Gk.length; b++) yqb(a.Gk[b], a.Ar[b]);
                for (; a.Gk.length > a.XP;) a.Gk.pop(), a.cB.pop(), a.Ar.pop()
            }
        },
        Aqb = function(a) {
            x5(a);
            for (var b = 0; b < a.Gk.length; b++) {
                var c = a.Gk[b],
                    d = a.cB[b];
                if (d !== c.version) return !0;
                if (!xqb(c) || c.Yl)
                    if (c.Yl || 1 !== c.sY)(c.t_(c) || Aqb(c)) && c.u_(c), c.Yl = !1, c.sY = 1;
                if (d !== c.version) return !0
            }
            return !1
        },
        yqb = function(a, b) {
            null != a.wk || (a.wk = []);
            null != a.uw || (a.uw = []);
            x5(a);
            if (1 === a.wk.length)
                for (var c = 0; c < a.Gk.length; c++) yqb(a.Gk[c], a.Ar[c]);
            c = a.wk.length - 1;
            a.wk[b] = a.wk[c];
            a.uw[b] = a.uw[c];
            a.wk.length--;
            a.uw.length--;
            b < a.wk.length && (c = a.uw[b], a = a.wk[b], x5(a), a.Ar[c] = b)
        },
        xqb = function(a) {
            var b, c;
            return a.cW || 0 < (null != (c = null == a ? void 0 : null == (b = a.wk) ? void 0 : b.length) ? c : 0)
        },
        x5 = function(a) {
            null != a.Gk || (a.Gk = []);
            null != a.Ar || (a.Ar = []);
            null != a.cB || (a.cB = [])
        },
        Eqb = function(a, b, c) {
            function d(f) {
                e.Uy = f
            }
            var e = Object.create(Bqb);
            c && (e.oN = !0);
            e.Ns = a;
            e.schedule = b;
            a = {};
            e.gB = (a.notify = function() {
                return vqb(e)
            }, a.LF = function() {
                if (null !== e.Ns) {
                    if (w5) throw Error("Schedulers cannot synchronously execute watches while scheduling.");
                    e.Yl = !1;
                    if (!e.PX || Aqb(e)) {
                        e.PX = !0;
                        var f = wqb(e);
                        try {
                            e.Uy(), e.Uy = Cqb, e.Ns(d)
                        } finally {
                            zqb(e, f)
                        }
                    }
                }
            }, a.lmb = function() {
                return e.Uy()
            }, a.destroy = function() {
                if (null !== e.Ns || null !== e.schedule) {
                    x5(e);
                    if (xqb(e))
                        for (var f = 0; f < e.Gk.length; f++) yqb(e.Gk[f], e.Ar[f]);
                    e.Gk.length = e.cB.length = e.Ar.length = 0;
                    e.wk && (e.wk.length = e.uw.length = 0);
                    e.Uy();
                    e.Ns = null;
                    e.schedule = null;
                    e.Uy = Cqb
                }
            }, a[Dqb] = e, a);
            return e.gB
        },
        Cqb = function() {},
        Fqb = function(a) {
            return Object.create(Object.assign({}, y5, {
                oN: a
            }))
        },
        z5 = function(a, b) {
            a = v5(a);
            try {
                return b()
            } finally {
                v5(a)
            }
        },
        A5 = function(a) {
            var b = !!t5,
                c = Gqb(void 0 === b ? !0 : b);
            u5(c, function() {
                return void a(c)
            });
            return function() {
                return void Hqb(c)
            }
        },
        Gqb = function(a) {
            var b = {};
            (void 0 === a || a) && Iqb(b);
            return b
        },
        Iqb = function(a) {
            var b = t5;
            b && !b.isDisposed && (b.dF || (b.dF = []), b.dF.push(a))
        },
        Kqb = function(a) {
            var b;
            null == (b = a.dF) || b.forEach(Hqb);
            a.dF && (a.dF = []);
            a.XC && (z5(Jqb, function() {
                for (var c = g.u(a.XC), d = c.next(); !d.done; d = c.next()) d = d.value, d()
            }), a.XC = [])
        },
        Hqb = function(a) {
            if (!a.isDisposed) {
                a.isDisposed = !0;
                var b;
                null == (b = a.k$) || b.call(a);
                Kqb(a)
            }
        },
        Mqb = function(a) {
            var b = t5;
            b && b !== Lqb && (b.XC || (b.XC = []), b.XC.push(a))
        },
        B5 = function(a) {
            this.props = a;
            this.C = !1
        },
        Nqb = function() {
            if (C5 && C5.gw) throw Error("Reactive components are not allowed to use useState or other memoization based hooks.");
            return D5
        },
        Oqb = function(a) {
            C5 = (null == a ? void 0 : a.B) || null;
            D5 = a
        },
        E5 = function(a) {
            B5.call(this, a);
            var b = this;
            this.Nz = [];
            this.D = 0;
            this.G = A5(function(c) {
                b.HH = c;
                Mqb(function() {
                    Pqb(b, b.el)
                })
            })
        },
        Pqb = function(a, b) {
            if (!a.C && b) {
                a.C = !0;
                try {
                    a.CH()
                } catch (e) {
                    var c, d;
                    null == (d = F5.XD) || d.call(F5, null == (c = a.j) ? void 0 : c.Ou, e)
                }
                G5.CH(a);
                a.el = null;
                b.__instance && delete b.__instance
            }
        },
        Qqb = function(a) {
            if (a) {
                var b;
                null == (b = a._disposeRef) || b.call(a);
                var c;
                null == (c = a._disposeEffects) || c.call(a);
                a.__instance && (b = a.__instance, Pqb(b, a), b instanceof E5 && b.G());
                for (b = 0; b < a.childNodes.length; b++) Qqb(a.childNodes[b])
            }
        },
        Sqb = function(a) {
            1 === Rqb.push(a) && requestAnimationFrame(function() {
                setTimeout(function() {
                    var b = [].concat(g.pa(Rqb));
                    Rqb = [];
                    b = g.u(b);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        try {
                            for (var d = 0; d < c.length; d++) Qqb(c[d])
                        } catch (e) {
                            d = c = void 0, null == (d = (c = F5).XD) || d.call(c, "unknown", e)
                        }
                    }
                })
            })
        },
        Uqb = function(a, b) {
            var c = g.Ia.apply(2, arguments),
                d;
            b = null != (d = b) ? d : {};
            d = {};
            return d.type = a, d.props = b, d.children = c, d[Tqb] = !0, d
        },
        Vqb = function(a) {
            return a.children
        },
        I5 = function(a, b) {
            return H5.apply(null, [a,
                b
            ].concat(g.pa(g.Ia.apply(2, arguments))))
        },
        J5 = function(a, b) {
            var c = H5;
            H5 = a;
            try {
                return b()
            } finally {
                H5 = c
            }
        },
        K5 = function(a) {
            a = document.createTextNode(String(a));
            a._isSignalTextNode = !0;
            return a
        },
        L5 = function(a) {
            a = typeof a;
            return "string" === a || "number" === a || "boolean" === a
        },
        M5 = function(a) {
            return a instanceof g.be || a instanceof g.ge || a instanceof g.me || !1
        },
        Wqb = function(a, b) {
            a.parentElement && a.parentElement.replaceChild(b, a);
            return b
        },
        Xqb = function(a, b) {
            a.textContent !== String(b) && (a.textContent = String(b));
            return a
        },
        N5 = function(a, b) {
            var c = a[0].parentElement;
            if (c)
                if (a[0].previousSibling || a[a.length - 1].nextSibling) {
                    c.insertBefore(b, a[0]);
                    for (var d = a.length - 1; 0 <= d; d--) c.removeChild(a[d])
                } else c.textContent = "", c.appendChild(b);
            return b
        },
        Yqb = function(a, b) {
            if (a[0].parentElement)
                for (var c = a[0].parentElement, d = b.length, e = a.length, f = d, h = 0, l = 0, m = a[e - 1].nextSibling, n = null; h < e || l < f;)
                    if (a[h] === b[l]) h++, l++;
                    else {
                        for (; a[e - 1] === b[f - 1];) e--, f--;
                        if (e === h)
                            for (var p = f < d ? l ? b[l - 1].nextSibling : b[f - l] : m; l < f;) c.insertBefore(b[l++], p);
                        else if (f === l)
                            for (; h < e;) n && n.has(a[h]) || c.removeChild(a[h]), h++;
                        else if (a[h] === b[f - 1] && b[l] === a[e - 1]) p = a[--e].nextSibling, c.insertBefore(b[l++], a[h++].nextSibling), c.insertBefore(b[--f], p), a[e] = b[f];
                        else {
                            if (!n)
                                for (n = new Map, p = l; p < f;) n.set(b[p], p++);
                            p = n.get(a[h]);
                            if (null == p) c.removeChild(a[h]), h++;
                            else if (l < p && p < f) {
                                for (var q = h, r = 1, t = void 0; ++q < e && q < f && null != (t = n.get(a[q])) && t === p + r;) r++;
                                if (r > p - l)
                                    for (q = a[h]; l < p;) c.insertBefore(b[l++], q);
                                else c.replaceChild(b[l++], a[h++])
                            } else h++
                        }
                    }
            return b
        },
        O5 = function(a) {
            return g.bb(a) ? "nodeType" in a : !1
        },
        $qb = function(a) {
            a.isDisposed || Zqb.add(a)
        },
        arb = function(a) {
            a.isDisposed || (P5.add(a), 1 === P5.size && Promise.resolve().then(function() {
                for (var b = g.u(P5), c = b.next(); !c.done; c = b.next()) c = c.value, P5.delete(c), c.LF()
            }))
        },
        brb = function(a, b, c) {
            var d = Eqb(function() {
                var e = d;
                e.isDisposed || (Kqb(e), u5(e, b))
            }, a, void 0 === c ? !1 : c);
            Iqb(d);
            d.k$ = function() {
                d.destroy();
                Zqb.delete(d);
                Hqb(d)
            };
            return d
        },
        crb = function(a) {
            brb($qb, a).LF()
        },
        drb = function(a) {
            brb($qb, a, !0).LF()
        },
        frb = function(a) {
            var b = [];
            ({}.dmb ? drb : crb)(function() {
                var c = b[0],
                    d = b.Dq,
                    e = J5(Q5, a);
                c = erb(c, e, b);
                Array.isArray(c) || (b.Dq = [c]);
                e = b.Dq;
                if (d) {
                    d = Array.isArray(d) ? d[0] : d;
                    var f = d[R5],
                        h = d._disposeEffects;
                    d._disposeEffects = void 0;
                    d = Array.isArray(e) ? e[0] : e;
                    d[R5] = f;
                    d[R5] && (d[R5].jZ = d === e ? 1 : e.length);
                    d._disposeEffects = h
                }
                b[0] = c
            });
            return b
        },
        erb = function(a, b, c) {
            for (;
                "function" === typeof b;) b = b();
            if (null != b && b[Tqb]) {
                var d;
                throw Error("Encountered a VNode when only real nodes are expected. Tag name: " + (null == (d = b.type) ? void 0 : d.Ou));
            }
            if (null == a) return null == b ? document.createTextNode("") : L5(b) ? K5(b) : M5(b) ? K5(b.toString()) : O5(b) ? b : 0 === b.length ? document.createTextNode("") : grb(b, c);
            if (O5(a)) {
                if (null == b) return Wqb(a, document.createTextNode(""));
                if (L5(b)) return Xqb(a, b);
                if (M5(b)) return Xqb(a, b.toString());
                if (O5(b)) return Wqb(a, b);
                if (0 === b.length) return Wqb(a, document.createTextNode(""));
                b = grb(b,
                    c);
                Yqb([a], c.Dq);
                return b
            }
            a = hrb(a);
            if (null == b) return N5(a, document.createTextNode(""));
            if (L5(b)) return N5(a, K5(b));
            if (M5(b)) return N5(a, K5(b.toString()));
            if (O5(b)) return Yqb(a, [b])[0];
            if (0 === b.length) return N5(a, document.createTextNode(""));
            b = grb(b, c);
            Yqb(a, c.Dq);
            return b
        },
        hrb = function(a, b) {
            b = void 0 === b ? [] : b;
            return S5(a, b)
        },
        grb = function(a, b) {
            b.Dq = S5(a, [], !0);
            return a
        },
        S5 = function(a, b, c, d, e) {
            b = void 0 === b ? [] : b;
            c = void 0 === c ? !1 : c;
            e = void 0 === e ? -1 : e;
            if (null == a) return b;
            L5(a) && (a = K5(a), d && c && (d[e] = a));
            M5(a) && (a = K5(a.toString()), d && c && (d[e] = a));
            if (O5(a)) return irb(b, a);
            if (Array.isArray(a)) {
                for (d = 0; d < a.length; d++) S5(a[d], b, c, a, d);
                return b
            }
            if ("function" === typeof a) return a = frb(a)[0], d && c && (d[e] = a), irb(b, a);
            if (null != a && a[Tqb]) {
                var f = a;
                a = J5(Q5, function() {
                    return I5.apply(null, [f.type, f.props].concat(g.pa(f.children)))
                });
                return S5(a, b, c)
            }
            throw Error("Unrecognized JSXResult type in flattening.");
        },
        irb = function(a, b) {
            Array.isArray(a) ? a.push(b) : a.appendChild(b);
            return a
        },
        krb = function(a, b) {
            var c, d, e = C5;
            C5 = a;
            var f = A5(function(p) {
                    d = p;
                    c = J5(Q5, function() {
                        return z5(jrb, function() {
                            return a(b)
                        })
                    })
                }),
                h = null != c && c.Dq ? c.Dq : c,
                l = Array.isArray(h) ? h[0] : h,
                m, n = null != (m = null == b ? void 0 : b.idomKey) ? m : a;
            m = a.e1;
            l._disposeEffects = f;
            f = l[R5] || {};
            Object.assign(f, {
                key: n,
                props: m ? b : void 0,
                jZ: h !== l ? h.length : 1,
                owner: d,
                s8: !!l[R5]
            });
            l[R5] = f;
            u5(d, function() {});
            C5 = e;
            return c
        },
        nrb = function(a, b, c) {
            if (Object.hasOwnProperty.call(lrb, a) && (a = lrb[a], Object.hasOwnProperty.call(a, b) && (a = a[b], a instanceof Array))) {
                for (var d = null, e = !1, f = 0, h = a.length; f < h; ++f) {
                    var l = a[f],
                        m = l.Bi;
                    if (!m) return l.Gd;
                    null === d && (d = {});
                    m = Object.hasOwnProperty.call(d, m) ? d[m] : d[m] = c(m);
                    if (m === l.Ri) return l.Gd;
                    null == m && (e = !0)
                }
                if (e) return null
            }
            b = mrb[b];
            return "number" === typeof b ? b : null
        },
        prb = function(a, b, c) {
            if (null === c || void 0 === c) return c;
            var d = nrb(a.tagName.toLowerCase(), b, function() {
                throw Error("Contingent attribute/property lookups are not supported.");
            });
            if (null === d) return c;
            d = orb[d];
            var e;
            if (null == (e = d.Ct) ? 0 : e.call(d, c)) {
                if (d.Ur) return d.Ur(c);
                throw Error("Value Handler's unwrap function does not exist.");
            }
            return d.Cq ? d.Cq(a.tagName, b, String(c)) : c
        },
        T5 = function(a, b, c) {
            if (!1 === c && qrb.has(b)) dqb(a, b, null);
            else if ("idomKey" !== b && "skip" !== b && "skipchildren" !== b && "children" !== b && "el" !== b)
                if (b.startsWith("on"))
                    if (":" === b[2]) {
                        var d = c.n7(0),
                            e = b.slice(3);
                        if (C5 && C5.gw) a.addEventListener(e, d), Mqb(function() {
                            return void a.removeEventListener(e, d)
                        });
                        else {
                            if (rrb.includes(e)) throw Error("The on:" + e + " attribute is not supported in an IDOM component because Element#on" + (e + " is not a valid property."));
                            a["on" + e] = d
                        }
                    } else srb(a, b, c);
            else "function" !== typeof c || null != a._disposeEffects ? (F5.G6 && (c = prb(a, b, c)), "style" === b ? trb(a, b, c) : b.startsWith("prop:") ? a[b.slice(5)] = c : srb(a, b, c)) : (a._signalProps || (a._signalProps = []), a._signalValues || (a._signalValues = []), a._signalProps.push(b))
        },
        urb = function(a, b, c) {
            c = (void 0 === c ? {} : c).gw;
            if (null == b ? 0 : b.el) {
                var d = b.el;
                if ("function" === typeof d) d(a);
                else {
                    var e;
                    null == (e = d.qaa) || e.call(d, a);
                    a._disposeRef || (a._disposeRef = function() {
                        var f;
                        null == (f = d.lba) || f.call(d);
                        delete a._disposeRef
                    }, c && Mqb(function() {
                        var f;
                        return void(null == (f = a._disposeRef) ? void 0 : f.call(a))
                    }))
                }
            }
        },
        vrb = function(a, b) {
            null == a._disposeEffects && null != a._signalProps && (a._disposeEffects = A5(function() {
                crb(function() {
                    for (var c = a._signalProps, d = a._signalValues, e = 0; e < c.length; e++) {
                        var f = c[e],
                            h = b[f]();
                        d[e] !== h && (d[e] = h, T5(a, f, h))
                    }
                })
            }))
        },
        wrb = function(a, b) {
            a._disposeEffects = A5(function() {
                a._isSignalTextNode = !0;
                crb(function() {
                    var c = b();
                    null == c && (c = "");
                    var d = typeof c;
                    if ("object" === d || "function" === d) throw Error("Invalid text node kind: " + d + ". Text nodes must be primitives like numbers, strings, or null, but an object type was passed. See go/cow-errors#invalid-text-nodes for more information.");
                    a.textContent = String(c)
                })
            })
        },
        zrb = function(a, b) {
            var c = g.Ia.apply(2, arguments);
            if (a === Vqb) return c;
            if ("function" === typeof a) {
                var d = b;
                0 < c.length && (null != d || (d = {}), 1 === c.length ? d.children = c[0] : d.children = c);
                c = xrb(a, d);
                !1 === c && (c = yrb(a, d));
                return c
            }
            d = document.createElement(a);
            for (var e in b) T5(d, e, b[e]);
            vrb(d, b);
            hrb(c, d);
            urb(d, b, {
                gw: !0
            });
            return d
        },
        xrb = function(a, b) {
            if (a.Inb || a.gw) return !1;
            b || (b = {});
            var c = new E5(b);
            c.B = a;
            var d = z5(jrb, function() {
                return c.lx(b)
            });
            if (!(d instanceof HTMLElement)) return d;
            d.__instance = c;
            c.el = d;
            c.j = a;
            a.Ou = d.tagName.toLowerCase();
            G5.eD(c);
            return d
        },
        Arb = function(a) {
            a = brb(arb, a);
            arb(a)
        },
        Crb = function(a) {
            Arb(function() {
                z5(Brb, a)
            })
        },
        Drb = function(a) {
            var b = v5(Brb);
            try {
                return z5(Brb, a)
            } finally {
                v5(b)
            }
        },
        Erb = function(a) {
            var b = null,
                c;
            return {
                value: null,
                qaa: function(d) {
                    if (c && d !== c) {
                        var e;
                        null == (e = b) || e();
                        c._disposeRef = void 0
                    }
                    c = d;
                    b = a(d) || null
                },
                lba: function() {
                    var d;
                    null == (d = b) || d()
                }
            }
        },
        Frb = function(a) {
            var b = Nqb();
            if (null == b) throw Error("A valid hook context was not found. Please ensure you are using components from TSX and not invoking the component function directly");
            var c = b.D++;
            b.Nz || (b.Nz = []);
            var d = b.Nz;
            d[c] || (d[c] = {
                key: a,
                host: b
            });
            if (a !== d[c].key) {
                var e, f;
                a = (null == (e = b.j) ? void 0 : e.name) || (null == (f = b.B) ? void 0 : f.name);
                throw Error("Hook called out of order in " + a + ". Hooks must be invoked unconditionally and in the same order every render. This could happen if you conditionally invoke a hook.");
            }
            return d[c]
        },
        Grb = function(a, b) {
            return !a || a.length !== (null == b ? void 0 : b.length) || a.some(function(c, d) {
                return c !== b[d]
            })
        },
        Hrb = function(a, b) {
            var c = Frb("onChange"),
                d = Nqb();
            Grb(c.gh, b) && (c.gh = b, c.ZZ = a, d.Iy || (d.Iy = []), d.Iy.push(c))
        },
        U5 = function(a, b) {
            Hrb(function() {
                return Drb(a)
            }, b)
        },
        Irb = function(a) {
            C5 && C5.gw ? Crb(a) : Hrb(function() {
                return Drb(a)
            }, [])
        },
        Krb = function(a) {
            var b = [].concat(g.pa(a));
            a.length = 0;
            a = g.u(b);
            for (b = a.next(); !b.done; b = a.next()) {
                b = b.value;
                Jrb(b);
                var c = b.ZZ;
                b.ZZ = null;
                if (c = null == c ? void 0 : c()) b.YZ = c
            }
        },
        Jrb = function(a) {
            var b = a.YZ;
            a.YZ = null;
            null == b || b()
        },
        V5 = function(a) {
            var b = [];
            if (C5 && C5.gw) return a();
            var c = Frb("useMemoInternal");
            Grb(c.gh, b) && (c.gh = b, c.value = a());
            return c.value
        },
        W5 = function() {
            var a = V5(function() {
                return Erb(function(b) {
                    a.value = b;
                    return function() {
                        a.value = null
                    }
                })
            });
            return a
        },
        Lrb = function(a) {
            var b = t5;
            return {
                n7: function() {
                    return function(c) {
                        b.isDisposed || !0 !== a(c) && c.stopPropagation()
                    }
                }
            }
        },
        Mrb = function(a) {
            if ("function" === typeof a.children) return a.children(), null;
            a = g.u(a.children);
            for (var b = a.next(); !b.done; b = a.next()) b = b.value, b();
            return null
        },
        Prb = function(a, b, c) {
            ((void 0 === c ? 0 : c) ? Nrb : Orb)(a, function() {
                X5(b)
            })
        },
        X5 = function(a) {
            if (void 0 !== a && null !== a)
                if (Array.isArray(a)) {
                    a = g.u(a);
                    for (var b = a.next(); !b.done; b = a.next()) X5(b.value)
                } else if (a instanceof g.be || a instanceof g.ge || a instanceof g.me) sqb(a.toString());
            else if (O5(a)) {
                if (j5() !== a) throw Error("Encountered a real dom node where a vdom node was expected. Real dom nodes should only come from the reactive renderer, and they can't be passed in JSX expressions directly. Tag name: " + a.tagName);
                m5 = j5()
            } else {
                var c = typeof a;
                if ("boolean" === c || "number" === c || "string" === c) sqb(a);
                else if ("function" === typeof a) {
                    b = i5;
                    var d = j5();
                    if (!d ||
                        !d._isSignalTextNode) {
                        var e = b.insertBefore,
                            f = document.createTextNode("");
                        wrb(f, a);
                        e.call(b, f, d)
                    }
                    m5 = j5()
                } else {
                    if ("string" === typeof a.type) {
                        a.uq || oqb(a.type, a.props.idomKey);
                        d = i5;
                        for (var h in a.props) a.props[h] !== Qrb && (e = a.props[h], f = q5, f.push(h), f.push(e));
                        e = F5.attributes;
                        e = void 0 === e ? Rrb : e;
                        f = i5;
                        var l = h5(f),
                            m = e;
                        e = q5;
                        l = l.j || (l.j = cqb(e.length));
                        for (var n = !l.length || !1, p = 0; p < e.length; p += 2) {
                            h = e[p];
                            if (n) l[p] = h;
                            else if (l[p] !== h) break;
                            var q = e[p + 1];
                            if (n || l[p + 1] !== q) l[p + 1] = q, rqb(f, h, q, m)
                        }
                        if (p < e.length || p < l.length) {
                            for (p =
                                n = p; p < l.length; p += 2) Y5[l[p]] = l[p + 1];
                            for (p = n; p < e.length; p += 2) n = e[p], h = e[p + 1], Y5[n] !== h && rqb(f, n, h, m), l[p] = n, l[p + 1] = h, delete Y5[n];
                            g5(l, e.length);
                            for (b in Y5) rqb(f, b, void 0, m), delete Y5[b]
                        }
                        b = Srb;
                        Srb = f = s5.length;
                        for (m = b; m < f; m += 5)(0, s5[m])(s5[m + 1], s5[m + 2], s5[m + 3], s5[m + 4]);
                        Srb = b;
                        g5(s5, b);
                        g5(e, 0);
                        vrb(d, a.props);
                        (a.props.skip || a.props.skipchildren) && i5.hasChildNodes() ? m5 = i5.lastChild : X5(a.children);
                        l5(null);
                        m5 = i5;
                        i5 = i5.parentNode;
                        a.uq && (a.uq = !1);
                        urb(d, a.props);
                        return d
                    }
                    if (a.type === Vqb) X5(a.children);
                    else if (!Trb(a)) {
                        try {
                            f =
                                a.type;
                            var r = f.Ou;
                            if (f === Mrb) a.props.children = a.children, f(a.props);
                            else {
                                0 < a.children.length && (a.props.children = a.children);
                                var t;
                                (t = a.props).idomKey || (t.idomKey = f);
                                b = !1;
                                if (r) {
                                    var v = oqb(r, a.props.idomKey);
                                    a.uq = !0;
                                    m = v.__instance
                                }
                                if (!m) {
                                    b = !0;
                                    var x = a.props,
                                        A;
                                    if (void 0 === (null == (A = f.prototype) ? void 0 : A.lx)) {
                                        var E = new E5(x);
                                        E.B = f
                                    } else E = new f(x);
                                    E.j = f;
                                    E.wM = {
                                        YP: E.state,
                                        hP: !1
                                    };
                                    m = E;
                                    m.props = null;
                                    v && (v.__instance = m, m.el = v)
                                }
                                var F, G = null != (F = m.wM) ? F : {
                                        YP: m.state,
                                        hP: !1
                                    },
                                    L = G.hP,
                                    Q = G.YP;
                                m.wM = void 0;
                                f.k7 && (Q = f.k7(a.props,
                                    Q));
                                b = !b && !L && !1;
                                m.props = a.props;
                                m.state = Q;
                                if (b) m5 = i5.lastChild;
                                else {
                                    b = m;
                                    G5.FV(b);
                                    var R = b.lx(b.props);
                                    R ? (b.props.idomKey && (R.props.idomKey = b.props.idomKey), q = R) : q = void 0;
                                    if (b = q)
                                        if (b.uq = a.uq, l = X5(b), a.uq = b.uq, !f.Ou)
                                            if (l) f.Ou = l.tagName.toLowerCase(), l.__instance = m, m.el = l;
                                            else if (null == (p = m.Nz) ? 0 : p.length) null == (n = F5.XD) || n.call(F5, "unknown", Error("A component used hooks, but failed to return a host element"));
                                    m.eD();
                                    G5.eD(m)
                                }
                            }
                        } catch (aa) {
                            b = aa, null == (e = F5.XD) || e.call(F5, null == (d = a.type) ? void 0 : d.Ou, b)
                        }
                        a.uq &&
                            (l5(null), m5 = i5, i5 = i5.parentNode, a.uq = !1)
                    }
                }
            }
        },
        Trb = function(a) {
            var b = a.type;
            if (!b.gw) return !1;
            a.props.children = 1 < a.children.length ? a.children : a.children[0];
            var c, d = null != (c = a.props.idomKey) ? c : a.type,
                e;
            if (j5() && (null == (e = j5()[R5]) ? void 0 : e.key) === d) {
                d = j5();
                c = d[R5];
                if (!c) throw Error("Reactive data has been lost on node. Tag name: " + d.tagName);
                if (!b.e1) {
                    for (b = 0; b < c.jZ; b++) m5 = j5();
                    var f;
                    null == (f = c.jpb) || f.call(c, a.props);
                    return !0
                }
                f = t5;
                b = b.e1(a.props, c.props, null !== f ? f : c.owner, c.s8);
                a = a.props;
                if (c = c.props) c.children = a.children, c.F6 = a.F6, c.fallback = a.fallback;
                X5(b);
                return !0
            }
            a =
                krb(a.type, a.props);
            a = null != a && a.Dq ? a.Dq : a;
            a = Array.isArray(a) ? a : [a];
            a = g.u(a);
            for (b = a.next(); !b.done; b = a.next()) i5.insertBefore(b.value, j5()), m5 = j5();
            return !0
        },
        Urb = function(a) {
            var b = Nqb(),
                c = V5(function() {
                    return {
                        value: "function" === typeof a ? a() : a
                    }
                });
            return [c.value, function(d) {
                if (null !== D5) throw Error("Can't set state during rendering");
                c.value = "function" === typeof d ? d(c.value) : d;
                b.wM = {
                    YP: b.state,
                    hP: !0
                };
                u5(b.HH, function() {
                    J5(Uqb, function() {
                        if (b.el) {
                            var e, f = {
                                props: b.props,
                                type: b.j,
                                children: null != (e = b.props.children) ? e : []
                            };
                            try {
                                Prb(b.el, f, !0)
                            } catch (m) {
                                var h, l;
                                null == (l = F5.XD) || l.call(F5, null == (h = b.j) ? void 0 : h.Ou, m)
                            }
                        }
                    })
                })
            }]
        },
        Vrb = function() {
            return V5(function() {
                return {
                    value: null
                }
            })
        },
        Zrb = function(a) {
            var b = Wrb;
            Xrb.push(a);
            Yrb || (b(function() {
                for (var c = g.u(Xrb), d = c.next(); !d.done; d = c.next()) d = d.value, d();
                Xrb.length = 0;
                Yrb = !1
            }), Yrb = !0)
        },
        Wrb = function(a) {
            Promise.resolve().then(a)
        },
        $rb = function(a) {
            a = g.u(Urb(a));
            var b = a.next().value,
                c = a.next().value;
            return [b, function(d) {
                Zrb(function() {
                    c(d)
                })
            }]
        },
        asb = function(a) {
            function b() {
                var l = a.J.md() ? "Hide more shorts" : "Hide more videos";
                e(l)
            }
            var c = g.u(Urb("Hide more videos")),
                d = c.next().value,
                e = c.next().value;
            U5(function() {
                var l = a.J;
                l.addEventListener("videodatachange", b);
                return function() {
                    l.removeEventListener("videodatachange", b)
                }
            }, [a.J]);
            var f = V5(function() {
                    return (new g.LF(g.YF())).element
                }),
                h = W5();
            Irb(function() {
                h.value.appendChild(f)
            });
            return I5("button", {
                class: "ytp-button ytp-collapse",
                "aria-label": d,
                "on:click": Lrb(function() {
                    a.action && a.action()
                })
            }, I5("div", {
                class: "ytp-collapse-icon",
                el: h,
                skip: !0
            }))
        },
        bsb = function(a) {
            function b() {
                var h = a.J.md() ? "More shorts" : "More videos";
                e(h)
            }
            var c = g.u($rb("More videos")),
                d = c.next().value,
                e = c.next().value,
                f = W5();
            U5(function() {
                a.gB && (a.gB.value = f.value)
            }, [a.gB]);
            U5(function() {
                var h = a.J;
                h.addEventListener("videodatachange", b);
                return function() {
                    h.removeEventListener("videodatachange", b)
                }
            }, [a.J]);
            return I5("button", {
                el: f,
                class: "ytp-button ytp-expand",
                "on:click": Lrb(function() {
                    a.action && a.action()
                })
            }, d)
        },
        csb = function(a, b) {
            var c = Vrb();
            U5(function() {
                var d = new g.n2(a);
                d.B = !0;
                c.value = d;
                return function() {
                    var e;
                    null == (e = c.value) || e.dispose()
                }
            }, [a,
                b
            ]);
            return c
        },
        dsb = function(a) {
            function b(x) {
                a: {
                    var A = g.u([1,
                        16, 32
                    ]);
                    for (var E = A.next(); !E.done; E = A.next())
                        if (g.DG(x, E.value)) {
                            A = !0;
                            break a
                        }
                    A = !1
                }
                if (!A) {
                    var F;
                    null != (F = p.value) && F.bE() && h(g.DG(x, 4) && !g.DG(x, 2) && !g.DG(x, 1024))
                }
            }

            function c() {
                b(a.J.Xb())
            }

            function d(x) {
                b(x.state)
            }
            var e = g.u($rb(!1)),
                f = e.next().value,
                h = e.next().value,
                l = g.u($rb(!1));
            e = l.next().value;
            var m = l.next().value,
                n = W5(),
                p = csb(a.J, a.df),
                q = W5();
            l = Vrb();
            var r = Vrb();
            U5(function() {
                var x = a.J,
                    A = x.md() ? 157212 : 172777;
                r.value = new g.I;
                x.createClientVe(q.value, r.value, A);
                x.addEventListener("presentingplayerstatechange", d);
                x.addEventListener("videodatachange", c);
                A = "0" === x.U().controlsType;
                g.dv(x.getRootNode(), "ytp-pause-overlay-controls-hidden", A);
                return function() {
                    x.removeEventListener("videodatachange", c);
                    x.removeEventListener("presentingplayerstatechange",
                        d);
                    var E;
                    null == (E = r.value) || E.dispose()
                }
            }, [a.J]);
            U5(function() {
                var x;
                null == (x = p.value) || x.Ja(n.value)
            }, [p]);
            var t = a.J;
            if (f)
                if (g.dv(t.getRootNode(), "ytp-expand-pause-overlay", !e), e) l.value.focus();
                else {
                    var v = p.value;
                    g.o2(v);
                    v.show();
                    q.value.focus()
                }
            q.value && t.logVisibility(q.value, f && !e);
            return I5("ytp-pause-overlay", {
                el: q,
                class: "ytp-pause-overlay",
                "aria-hidden": !f
            }, I5(asb, {
                J: a.J,
                df: a.df,
                action: function() {
                    m(!0)
                }
            }), I5(bsb, {
                J: a.J,
                df: a.df,
                action: function() {
                    m(!1)
                },
                gB: l
            }), I5("div", {
                el: n,
                skip: !0
            }))
        },
        esb = function(a) {
            g.V.call(this, {
                I: "div",
                S: "ytp-related-on-error-overlay"
            });
            var b = this;
            this.api = a;
            this.K = this.B = 0;
            this.G = new g.CK(this);
            this.j = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.V({
                I: "h2",
                S: "ytp-related-title",
                ya: "{{title}}"
            });
            this.previous = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-previous"],
                X: {
                    "aria-label": "Show previous suggested videos"
                },
                V: [g.UF()]
            });
            this.ma = new g.m2(function(f) {
                b.suggestions.element.scrollLeft = -f
            });
            this.D = this.C = 0;
            this.N = !0;
            this.next = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-next"],
                X: {
                    "aria-label": "Show more suggested videos"
                },
                V: [g.VF()]
            });
            g.N(this, this.G);
            a = a.U();
            this.api.L("embeds_web_enable_pause_overlay_rounding") && g.$u(this.element, "ytp-error-overlay-round-corners");
            this.Y = a.D;
            g.N(this, this.title);
            this.title.Ja(this.element);
            this.suggestions = new g.V({
                I: "div",
                S: "ytp-suggestions"
            });
            g.N(this, this.suggestions);
            this.suggestions.Ja(this.element);
            g.N(this, this.previous);
            this.previous.Ja(this.element);
            this.previous.Ta("click", this.J2, this);
            g.N(this, this.ma);
            for (var c = {
                    Rz: 0
                }; 16 > c.Rz; c = {
                    Rz: c.Rz
                }, c.Rz++) {
                var d = new g.V({
                    I: "a",
                    S: "ytp-suggestion-link",
                    X: {
                        href: "{{link}}",
                        target: a.Y,
                        "aria-label": "{{aria_label}}"
                    },
                    V: [{
                        I: "div",
                        S: "ytp-suggestion-image",
                        V: [{
                            I: "div",
                            X: {
                                "data-is-live": "{{is_live}}"
                            },
                            S: "ytp-suggestion-duration",
                            ya: "{{duration}}"
                        }]
                    }, {
                        I: "div",
                        S: "ytp-suggestion-title",
                        X: {
                            title: "{{hover_title}}"
                        },
                        ya: "{{title}}"
                    }, {
                        I: "div",
                        S: "ytp-suggestion-author",
                        ya: "{{views_or_author}}"
                    }]
                });
                g.N(this, d);
                d.Ja(this.suggestions.element);
                var e = d.Ga("ytp-suggestion-link");
                g.ms(e, "transitionDelay", c.Rz / 20 + "s");
                this.G.T(e, "click", function(f) {
                    return function(h) {
                        var l = f.Rz,
                            m = b.suggestionData[l],
                            n = m.sessionData;
                        g.PR(b.api.U()) && b.api.L("web_player_log_click_before_generating_ve_conversion_params") ? (b.api.logClick(b.j[l].element), l = m.Uk(), m = {}, g.QUa(b.api, m, "emb_rel_err"), l = g.cn(l, m), g.UU(l, b.api, h)) : g.TU(h, b.api, b.Y, n || void 0) && b.api.Mo(m.videoId, n, m.playlistId)
                    }
                }(c));
                this.j.push(d)
            }
            g.N(this, this.next);
            this.next.Ja(this.element);
            this.next.Ta("click", this.I2, this);
            this.G.T(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.qb().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        fsb = function(a, b) {
            if (a.api.U().L("web_player_log_click_before_generating_ve_conversion_params"))
                for (var c = Math.floor(-a.C / (a.D + a.B)), d = Math.min(c + a.columns, a.suggestionData.length) - 1; c <= d; c++) a.api.logVisibility(a.j[c].element, b)
        },
        gsb = function(a) {
            a.next.element.style.bottom =
                a.K + "px";
            a.previous.element.style.bottom = a.K + "px";
            var b = a.C,
                c = a.containerWidth - a.suggestionData.length * (a.D + a.B);
            g.dv(a.element, "ytp-scroll-min", 0 <= b);
            g.dv(a.element, "ytp-scroll-max", b <= c)
        },
        hsb = function(a) {
            for (var b = 0; b < a.suggestionData.length; b++) {
                var c = a.suggestionData[b],
                    d = a.j[b],
                    e = c.shortViewCount ? c.shortViewCount : c.author,
                    f = c.Uk(),
                    h = a.api.U();
                if (g.PR(h) && !h.L("web_player_log_click_before_generating_ve_conversion_params")) {
                    var l = {};
                    g.RT(a.api, "addEmbedsConversionTrackingParams", [l]);
                    f = g.cn(f, g.kP(l, "emb_rel_err"))
                }
                d.element.style.display = "";
                l = d.Ga("ytp-suggestion-title");
                g.pv.test(c.title) ? l.dir = "rtl" : g.zib.test(c.title) && (l.dir = "ltr");
                l = d.Ga("ytp-suggestion-author");
                g.pv.test(e) ? l.dir = "rtl" : g.zib.test(e) && (l.dir = "ltr");
                d.update({
                    views_or_author: e,
                    duration: c.isLivePlayback ? "Live" : c.lengthSeconds ? g.NG(c.lengthSeconds) : "",
                    link: f,
                    hover_title: c.title,
                    title: c.title,
                    aria_label: c.ariaLabel || null,
                    is_live: c.isLivePlayback
                });
                e = d.Ga("ytp-suggestion-image");
                f = c.ih();
                e.style.backgroundImage = f ? "url(" + f + ")" : "";
                h.L("web_player_log_click_before_generating_ve_conversion_params") && (a.api.createServerVe(d.element, d), (c = (c = c.sessionData) && c.itct) && a.api.setTrackingParams(d.element, c))
            }
            for (; b < a.j.length; b++) a.j[b].element.style.display = "none";
            gsb(a)
        },
        Z5 = function(a) {
            g.fW.call(this, a);
            var b = this;
            this.j = null;
            var c = a.U(),
                d = {
                    target: c.Y
                },
                e = ["ytp-small-redirect"];
            c.C ? e.push("no-link") : (c = g.mS(c), d.href = c, d["aria-label"] = "Visit YouTube to search for more videos");
            var f = new g.V({
                I: "a",
                La: e,
                X: d,
                V: [{
                    I: "svg",
                    X: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    V: [{
                        I: "path",
                        X: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        I: "path",
                        X: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            f.Ja(this.element);
            a.createClientVe(f.element, this, 178053);
            this.T(f.element, "click", function(h) {
                isb(b, h, f.element)
            });
            g.N(this, f);
            a.U().C || (this.j = new esb(a), this.j.Ja(this.element), g.N(this, this.j));
            this.T(a, "videodatachange", function() {
                b.show()
            });
            this.resize(this.api.qb().getPlayerSize())
        },
        isb = function(a, b, c) {
            b.preventDefault();
            a.api.logClick(c);
            b = c.getAttribute("href");
            c = {};
            g.RT(a.api, "addEmbedsConversionTrackingParams", [c]);
            b = g.md(c) ? b : g.cn(b, c);
            g.Ue(b)
        },
        jsb = function(a, b) {
            a.Ga("ytp-error-content").style.paddingTop = "0px";
            var c = a.Ga("ytp-error-content"),
                d = c.clientHeight;
            a.j && a.j.resize(b, b.height - d);
            c.style.paddingTop = (b.height - (a.j ? a.j.element.clientHeight : 0)) / 2 - d / 2 + "px"
        },
        msb = function(a, b) {
            var c = a.api.U(),
                d;
            b.reason && (ksb(b.reason) ? d = g.TF(b.reason) : d = g.gW(g.SF(b.reason)), a.Vd(d, "content"));
            var e;
            b.subreason && (ksb(b.subreason) ? e = g.TF(b.subreason) : e = g.gW(g.SF(b.subreason)), a.Vd(e, "subreason"));
            if (b.proceedButton && b.proceedButton.buttonRenderer) {
                d = a.Ga("ytp-error-content-wrap-subreason");
                b = b.proceedButton.buttonRenderer;
                var f = g.If("A");
                if (b.text && b.text.simpleText && (e = b.text.simpleText, f.textContent = e, !lsb(d, e) && (!c.C || c.embedsErrorLinks))) {
                    var h;
                    c = null == (h = g.U(null == b ? void 0 : b.navigationEndpoint, g.dG)) ?
                        void 0 : h.url;
                    var l;
                    h = null == (l = g.U(null == b ? void 0 : b.navigationEndpoint, g.dG)) ? void 0 : l.target;
                    c && (f.setAttribute("href", c), a.api.createClientVe(f, a, 178424), a.T(f, "click", function(m) {
                        isb(a, m, f)
                    }));
                    h && f.setAttribute("target", h);
                    l = g.If("DIV");
                    l.appendChild(f);
                    d.appendChild(l)
                }
            }
        },
        ksb = function(a) {
            if (a.runs)
                for (var b = 0; b < a.runs.length; b++)
                    if (a.runs[b].navigationEndpoint) return !0;
            return !1
        },
        lsb = function(a, b) {
            a = g.xf("A", a);
            for (var c = 0; c < a.length; c++)
                if (a[c].textContent === b) return !0;
            return !1
        },
        $5 = function(a, b) {
            g.V.call(this, {
                I: "a",
                La: ["ytp-impression-link"],
                X: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                V: [{
                    I: "div",
                    S: "ytp-impression-link-content",
                    X: {
                        "aria-hidden": "true"
                    },
                    V: [{
                        I: "div",
                        S: "ytp-impression-link-text",
                        ya: "Watch on"
                    }, {
                        I: "div",
                        S: "ytp-impression-link-logo",
                        V: [aqb()]
                    }]
                }]
            });
            this.api = a;
            this.df = b;
            this.updateValue("target", a.U().Y);
            this.api.createClientVe(this.element, this, 96714);
            this.T(this.api, "presentingplayerstatechange", this.Dk);
            this.T(this.api, "videoplayerreset", this.j);
            this.T(this.element, "click",
                this.onClick);
            this.j()
        },
        nsb = function(a) {
            var b = {};
            g.RT(a.api, "addEmbedsConversionTrackingParams", [b]);
            return g.cn(a.api.getVideoUrl(), g.kP(b, "emb_imp_woyt"))
        },
        a6 = function(a) {
            g.V.call(this, {
                I: "div",
                La: ["ytp-mobile-a11y-hidden-seek-button"],
                V: [{
                    I: "button",
                    La: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    X: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    I: "button",
                    La: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    X: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = a;
            this.j = this.Ga("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.Ga("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.j, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.T(this.api, "presentingplayerstatechange", this.Dk);
            this.T(this.j, "click", this.B);
            this.T(this.forwardButton, "click", this.C);
            this.Dk()
        },
        b6 = function(a) {
            g.V.call(this, {
                I: "div",
                S: "ytp-muted-autoplay-endscreen-overlay",
                V: [{
                    I: "div",
                    S: "ytp-muted-autoplay-end-panel",
                    V: [{
                        I: "button",
                        La: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        ya: "{{text}}"
                    }]
                }]
            });
            this.api = a;
            this.D = this.Ga("ytp-muted-autoplay-end-panel");
            this.B = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.T(this.api, "presentingplayerstatechange", this.C);
            this.T(a, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.Ta("click", this.onClick);
            this.hide()
        },
        c6 = function(a) {
            var b = a.U();
            g.V.call(this, {
                I: "a",
                La: ["ytp-watermark", "yt-uix-sessionlink"],
                X: {
                    target: b.Y,
                    href: "{{url}}",
                    "aria-label": g.VJ("Watch on $WEBSITE", {
                        WEBSITE: g.bS(b)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                V: [aqb()]
            });
            this.api = a;
            this.j = null;
            this.B = !1;
            this.state = a.Xb();
            a.createClientVe(this.element, this, 76758);
            this.T(a, "videodatachange", this.m1);
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.T(a, "presentingplayerstatechange", this.onStateChange);
            this.T(a, "appresize", this.Yb);
            this.Hc(this.state);
            this.onVideoDataChange();
            this.Yb(a.qb().getPlayerSize())
        },
        qsb = function(a) {
            g.V.call(this, {
                I: "div",
                S: "ytp-muted-autoplay-overlay",
                V: [{
                    I: "div",
                    S: "ytp-muted-autoplay-bottom-buttons",
                    V: [{
                        I: "button",
                        La: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        X: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        V: [{
                            I: "div",
                            La: ["ytp-muted-autoplay-equalizer-icon"],
                            V: [{
                                I: "svg",
                                X: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                V: [{
                                    I: "g",
                                    X: {
                                        fill: "#fff"
                                    },
                                    V: [{
                                            I: "rect",
                                            S: "ytp-equalizer-bar-left",
                                            X: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            I: "rect",
                                            S: "ytp-equalizer-bar-middle",
                                            X: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            I: "rect",
                                            S: "ytp-equalizer-bar-right",
                                            X: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var b = this;
            this.api = a;
            this.bottomButtons = this.Ga("ytp-muted-autoplay-bottom-buttons");
            this.Ga("ytp-muted-autoplay-equalizer");
            this.C = new g.Su(this.r8, 4E3, this);
            this.B = !1;
            a.createClientVe(this.element, this, 39306);
            this.T(a, "presentingplayerstatechange", this.JL);
            this.T(a, "onMutedAutoplayStarts", function() {
                osb(b);
                b.JL();
                psb(b);
                b.B = !1
            });
            this.T(a, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.Ta("click", this.onClick);
            this.T(a, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            g.VT(a.app) && (osb(this), this.JL(), psb(this));
            g.N(this, this.C)
        },
        psb = function(a) {
            a.Jb && a.j && (a.j.show(), a.C.start())
        },
        osb = function(a) {
            a.watermark || (a.watermark = new c6(a.api), g.N(a, a.watermark), a.watermark.Ja(a.bottomButtons, 0), g.dv(a.watermark.element, "ytp-muted-autoplay-watermark", !0), a.j = new g.wG(a.watermark, 0, !0, 100), g.N(a, a.j))
        },
        d6 = function(a) {
            g.V.call(this, {
                I: "div",
                S: "ytp-pause-overlay",
                X: {
                    tabIndex: "-1"
                }
            });
            var b = this;
            this.api = a;
            this.C = new g.CK(this);
            this.D = new g.wG(this, 1E3, !1, 100, function() {
                b.j.B = !1
            }, function() {
                b.j.B = !0
            });
            this.B = !1;
            this.expandButton = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-expand"],
                ya: this.api.md() ? "More shorts" : "More videos"
            });
            "0" === a.U().controlsType && g.$u(a.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.L("embeds_web_enable_pause_overlay_rounding") && g.$u(this.element, "ytp-pause-overlay-round-corners");
            g.N(this, this.C);
            g.N(this, this.D);
            var c = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-collapse"],
                X: {
                    "aria-label": this.api.md() ? "Hide more shorts" : "Hide more videos"
                },
                V: [{
                    I: "div",
                    S: "ytp-collapse-icon",
                    V: [g.YF()]
                }]
            });
            g.N(this, c);
            c.Ja(this.element);
            c.Ta("click", this.G, this);
            g.N(this, this.expandButton);
            this.expandButton.Ja(this.element);
            this.expandButton.Ta("click", this.K, this);
            this.j = new g.n2(a);
            g.N(this, this.j);
            this.j.B = !1;
            this.j.Ja(this.element);
            this.api.md() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.C.T(this.api, "presentingplayerstatechange", this.Sa);
            this.C.T(this.api, "videodatachange", this.Sa);
            this.hide()
        },
        e6 = function(a) {
            g.V.call(this, {
                I: "div",
                La: ["ytp-player-content", "ytp-iv-player-content"],
                V: [{
                    I: "div",
                    S: "ytp-countdown-timer",
                    V: [{
                        I: "svg",
                        X: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        V: [{
                            I: "circle",
                            S: "ytp-svg-countdown-timer-ring",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            I: "circle",
                            S: "ytp-svg-countdown-timer-background",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        I: "span",
                        S: "ytp-countdown-timer-time",
                        ya: "{{duration}}"
                    }]
                }]
            });
            this.api = a;
            this.K = this.Ga("ytp-svg-countdown-timer-ring");
            this.j = null;
            this.D = this.C = 0;
            this.B = !1;
            this.G = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        ssb = function(a) {
            a.j || (a.C = 5E3, a.D = (0, g.jD)(), a.j = new g.Qu(function() {
                rsb(a)
            }, null), rsb(a))
        },
        rsb = function(a) {
            if (!a.B) {
                var b = Math.min((0, g.jD)() - a.D, a.C);
                var c = a.C - b;
                b = 0 === a.C ? 0 : Math.max(c / a.C, 0);
                c = Math.round(c / 1E3);
                a.K.setAttribute("stroke-dashoffset", "" + -211 * (b + 1));
                a.updateValue("duration", c);
                0 >= b && a.j ? f6(a) : a.j && a.j.start()
            }
        },
        f6 = function(a) {
            a.j && (a.j.dispose(), a.j = null, a.B = !1)
        },
        usb = function(a) {
            g.KV.call(this, a);
            this.J = a;
            this.j = new g.CK(this);
            this.B = null;
            this.N = !1;
            this.countdownTimer = null;
            this.Y = !1;
            tsb(this);
            g.N(this, this.j);
            this.load()
        },
        wsb = function(a) {
            var b = g.Sgb(a.J);
            if (b !== a.Y && (a.Y = b, a.G && (a.G.dispose(), a.G = null), a.C && (a.C.dispose(), a.C = null), a.D && (a.D.dispose(), a.D = null), a.B && (a.B.stop(), a.B.dispose(), a.B = null), b)) {
                var c = g.XT(a.J);
                a.J.md() && (a.D = new g.V({
                    I: "div",
                    S: "ytp-pause-overlay-backdrop",
                    X: {
                        tabIndex: "-1"
                    }
                }), g.N(a, a.D), g.jU(a.J, a.D.element, 4), a.B = new g.wG(a.D, 1E3, !1, 100), g.N(a, a.B), a.D.hide());
                a.G = new g.V({
                    I: "div",
                    S: "ytp-pause-overlay-container",
                    X: {
                        tabIndex: "-1"
                    }
                });
                g.N(a, a.G);
                a.J.L("embeds_web_enable_keto_pause_overlay") ? (b = a.G.element, c = I5(dsb, {
                    J: a.J,
                    df: c
                }), Prb(b, c, !1)) : (a.C = new d6(a.J, c), g.N(a, a.C), a.C.Ja(a.G.element));
                g.jU(a.J, a.G.element, 4);
                vsb(a, a.J.Xb())
            }
        },
        vsb = function(a, b) {
            a.B && (!g.DG(b, 4) && !g.DG(b, 2) || g.DG(b, 1024) ? a.B.hide() : a.B.show())
        },
        tsb = function(a) {
            var b = a.J;
            a = !!b.md();
            g.dv(b.getRootNode(), "ytp-shorts-mode", a);
            if (b = b.getVideoData()) b.UU = a
        },
        g6 = function(a, b) {
            var c = a.J.U();
            a = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: 0 === a.J.getCurrentTime() ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : 0 === a.J.getPlayerState() ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.Hfa(a.J.U().loaderUrl),
                eventType: b,
                youtubeHost: g.Xm(a.J.U().Ea) || ""
            };
            a.embeddedPlayerMode = c.Ia;
            g.WC("embedsAdEvent", a)
        };
    var C5 = null;
    var eqb = Object.prototype.hasOwnProperty;
    bqb.prototype = Object.create(null);
    var Rrb = hqb();
    var r5 = null;
    var pqb = "undefined" !== typeof Node && Node.prototype.getRootNode || function() {
        for (var a = this, b = a; a;) b = a, a = a.parentNode;
        return b
    };
    var k5 = null,
        m5 = null,
        i5 = null,
        o5 = null,
        p5 = [],
        n5 = mqb,
        q5 = [],
        Orb = function(a) {
            return qqb(function(b, c, d) {
                i5 = m5 = b;
                m5 = null;
                c(d);
                l5(null);
                m5 = i5;
                i5 = i5.parentNode;
                return b
            }, a)
        }(),
        Nrb = function(a) {
            return qqb(function(b, c, d) {
                var e = {
                    nextSibling: b
                };
                m5 = e;
                c(d);
                i5 && l5(b.nextSibling);
                return e === m5 ? null : m5
            }, a)
        }();
    var s5 = [],
        Srb = 0;
    var Y5 = new bqb;
    var F5 = {
        attributes: hqb(),
        XD: function(a, b) {
            throw b;
        },
        G6: !0
    };
    var G5 = {
        amb: function() {},
        lob: function() {},
        fmb: function() {},
        FV: function() {},
        bmb: function() {},
        v6: function() {},
        eD: function() {},
        CH: function() {},
        w6: function() {}
    };
    var t5 = null;
    var uqb = null,
        w5 = !1,
        Dqb = Symbol("SIGNAL"),
        y5 = {
            version: 0,
            sY: 0,
            Yl: !1,
            Gk: void 0,
            cB: void 0,
            Ar: void 0,
            XP: 0,
            wk: void 0,
            uw: void 0,
            oN: !1,
            cW: !1,
            t_: function() {
                return !1
            },
            u_: function() {},
            dW: function() {},
            rmb: function() {}
        };
    var xsb = Symbol("UNSET"),
        ysb = Symbol("COMPUTING"),
        zsb = Symbol("ERRORED");
    Object.assign({}, y5, {
        value: xsb,
        Yl: !0,
        error: null,
        zW: tqb,
        t_: function(a) {
            return a.value === xsb || a.value === ysb
        },
        u_: function(a) {
            if (a.value === ysb) throw Error("Detected cycle in computations.");
            var b = a.value;
            a.value = ysb;
            var c = wqb(a);
            try {
                var d = a.pmb()
            } catch (e) {
                d = zsb, a.error = e
            } finally {
                zqb(a, c)
            }
            b !== xsb && b !== zsb && d !== zsb && a.zW(b, d) ? a.value = b : (a.value = d, a.version++)
        }
    });
    Object.assign({}, y5, {
        zW: tqb,
        value: void 0
    });
    var Bqb = Object.assign({}, y5, {
        cW: !0,
        oN: !1,
        dW: function(a) {
            null !== a.schedule && a.schedule(a.gB)
        },
        PX: !1,
        Uy: Cqb
    });
    var Jqb = Fqb(!1);
    var jrb = Fqb(!0);
    var Lqb = {};
    var Tqb = Symbol("IS_VNODE");
    B5.prototype.eD = function() {};
    B5.prototype.v6 = function() {};
    B5.prototype.CH = function() {};
    B5.prototype.w6 = function() {};
    var D5 = null;
    g.w(E5, B5);
    E5.prototype.lx = function(a) {
        var b = this,
            c = D5;
        Oqb(this);
        this.D = 0;
        try {
            return z5(jrb, function() {
                return u5(b.HH, function() {
                    return b.B(a)
                })
            })
        } finally {
            Oqb(c)
        }
    };
    var Rqb = [];
    (function() {
        var a = r5;
        r5 = function(b) {
            null == a || a(b);
            Sqb(b)
        }
    })();
    var H5 = Uqb;
    var Q5;
    var Qrb = Symbol("ATTR_TAG_VALUE");
    var R5 = Symbol("reactiveData");
    var Zqb = new Set,
        P5 = new Set;
    var yrb = krb;
    var qrb = new Set("allowfullscreen async autofocus autoplay checked controls default defer disabled formnovalidate hidden ismap itemscope jsshadow jsslot loop multiple muted novalidate open playsinline readonly required reversed scoped seamless selected spellcheck sortable typemustmatch".split(" "));
    var mrb = {
            align: 1,
            alt: 1,
            "aria-activedescendant": 10,
            "aria-atomic": 1,
            "aria-autocomplete": 1,
            "aria-busy": 1,
            "aria-checked": 1,
            "aria-controls": 10,
            "aria-current": 1,
            "aria-disabled": 1,
            "aria-dropeffect": 1,
            "aria-expanded": 1,
            "aria-haspopup": 1,
            "aria-hidden": 1,
            "aria-invalid": 1,
            "aria-label": 1,
            "aria-labelledby": 10,
            "aria-level": 1,
            "aria-live": 1,
            "aria-multiline": 1,
            "aria-multiselectable": 1,
            "aria-orientation": 1,
            "aria-owns": 10,
            "aria-posinset": 1,
            "aria-pressed": 1,
            "aria-readonly": 1,
            "aria-relevant": 1,
            "aria-required": 1,
            "aria-selected": 1,
            "aria-setsize": 1,
            "aria-sort": 1,
            "aria-valuemax": 1,
            "aria-valuemin": 1,
            "aria-valuenow": 1,
            "aria-valuetext": 1,
            async: 8,
            autocapitalize: 1,
            autocomplete: 1,
            autocorrect: 1,
            autofocus: 1,
            autoplay: 1,
            bgcolor: 1,
            border: 1,
            cellpadding: 1,
            cellspacing: 1,
            checked: 1,
            cite: 3,
            "class": 1,
            color: 1,
            cols: 1,
            colspan: 1,
            contenteditable: 1,
            controls: 1,
            datetime: 1,
            dir: 8,
            disabled: 1,
            download: 1,
            draggable: 1,
            enctype: 1,
            face: 1,
            "for": 10,
            formenctype: 1,
            frameborder: 1,
            height: 1,
            hidden: 1,
            href: 4,
            hreflang: 1,
            id: 10,
            ismap: 1,
            itemid: 1,
            itemprop: 1,
            itemref: 1,
            itemscope: 1,
            itemtype: 1,
            label: 1,
            lang: 1,
            list: 10,
            loading: 8,
            loop: 1,
            max: 1,
            maxlength: 1,
            media: 1,
            min: 1,
            minlength: 1,
            multiple: 1,
            muted: 1,
            name: 10,
            nonce: 1,
            open: 1,
            placeholder: 1,
            poster: 3,
            preload: 1,
            rel: 1,
            required: 1,
            reversed: 1,
            role: 1,
            rows: 1,
            rowspan: 1,
            selected: 1,
            shape: 1,
            size: 1,
            sizes: 1,
            slot: 1,
            span: 1,
            spellcheck: 1,
            src: 4,
            srcset: 11,
            start: 1,
            step: 1,
            style: 5,
            summary: 1,
            tabindex: 1,
            target: 8,
            title: 1,
            translate: 1,
            type: 1,
            valign: 1,
            value: 1,
            width: 1,
            wrap: 1
        },
        lrb = {
            a: {
                href: [{
                    Gd: 3
                }]
            },
            area: {
                href: [{
                    Gd: 3
                }]
            },
            audio: {
                src: [{
                    Gd: 3
                }]
            },
            button: {
                formaction: [{
                    Gd: 3
                }],
                formmethod: [{
                    Gd: 1
                }]
            },
            form: {
                action: [{
                    Gd: 3
                }],
                method: [{
                    Gd: 1
                }]
            },
            iframe: {
                srcdoc: [{
                    Gd: 2
                }]
            },
            img: {
                src: [{
                    Gd: 3
                }]
            },
            input: {
                accept: [{
                    Gd: 1
                }],
                formaction: [{
                    Gd: 3
                }],
                formmethod: [{
                    Gd: 1
                }],
                pattern: [{
                    Gd: 1
                }],
                readonly: [{
                    Gd: 1
                }],
                src: [{
                    Gd: 3
                }]
            },
            link: {
                href: [{
                        Gd: 3,
                        Bi: "rel",
                        Ri: "alternate"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "author"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "bookmark"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "canonical"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "cite"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "help"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "icon"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "license"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "next"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "prefetch"
                    },
                    {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "dns-prefetch"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "prerender"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "preconnect"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "preload"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "prev"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "search"
                    }, {
                        Gd: 3,
                        Bi: "rel",
                        Ri: "subresource"
                    }
                ]
            },
            script: {
                defer: [{
                    Gd: 1
                }]
            },
            source: {
                src: [{
                    Gd: 3
                }]
            },
            textarea: {
                readonly: [{
                    Gd: 1
                }]
            },
            video: {
                src: [{
                    Gd: 3
                }]
            }
        };
    g.Vv.getInstance();
    var Asb = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        h6 = {},
        orb = (h6[1] = {
            Cq: null,
            Ct: null,
            Ur: null
        }, h6[2] = {
            Cq: function() {
                return g.xe.toString()
            },
            Ct: function(a) {
                return a instanceof g.oe
            },
            Ur: function(a) {
                return g.pe(a)
            }
        }, h6[3] = {
            Cq: function(a, b, c) {
                return Asb.test(c) ? c : g.xe.toString()
            },
            Ct: function(a) {
                return a instanceof g.ge
            },
            Ur: function(a) {
                return g.he(a)
            }
        }, h6[4] = {
            Cq: function() {
                return g.xe.toString()
            },
            Ct: function(a) {
                return a instanceof g.be
            },
            Ur: function(a) {
                return g.ce(a)
            }
        }, h6[5] = {
            Cq: null,
            Ct: function(a) {
                return a instanceof g.me
            },
            Ur: function(a) {
                return a.toString()
            }
        }, h6[7] = {
            Cq: null,
            Ct: null,
            Ur: null
        }, h6[8] = {
            Cq: null,
            Ct: null,
            Ur: null
        }, h6[10] = {
            Cq: null,
            Ct: function(a) {
                return a instanceof g.Zd
            },
            Ur: function(a) {
                return a.toString()
            }
        }, h6);
    var Bsb = hqb(),
        srb = Bsb.__default,
        trb = Bsb.style,
        rrb = ["focusin", "focusout"];
    var Brb = Fqb(!0);
    Q5 = zrb;
    (function(a) {
        var b = {},
            c;
        for (c in a) b = {
            m_: void 0,
            cZ: void 0
        }, b.m_ = G5[c], b.cZ = a[c], G5[c] = function(d) {
            return function() {
                var e = g.Ia.apply(0, arguments);
                d.m_.apply(null, g.pa(e));
                d.cZ.apply(null, g.pa(e))
            }
        }(b)
    })({
        FV: function(a) {
            u5(a.HH, function() {
                var b;
                (null == (b = a.Iy) ? 0 : b.length) && Krb(a.Iy)
            })
        },
        eD: function(a) {
            u5(a.HH, function() {
                var b;
                (null == (b = a.Iy) ? 0 : b.length) && Krb(a.Iy)
            })
        },
        CH: function(a) {
            var b;
            (null == (b = a.Nz) ? 0 : b.length) && a.Nz.forEach(Jrb)
        }
    });
    Q5 = zrb;
    var Csb = {},
        Dsb = (Csb.__default = function() {
            return T5
        }, Csb.style = function() {
            return T5
        }, Csb),
        i6;
    for (i6 in Dsb) F5.attributes[i6] = Dsb[i6](F5.attributes[i6]);
    var Xrb = [],
        Yrb = !1;
    g.w(esb, g.V);
    g.k = esb.prototype;
    g.k.hide = function() {
        this.N = !0;
        g.V.prototype.hide.call(this);
        fsb(this, !1)
    };
    g.k.show = function() {
        this.N = !1;
        g.V.prototype.show.call(this);
        fsb(this, !0)
    };
    g.k.isHidden = function() {
        return this.N
    };
    g.k.I2 = function() {
        this.scrollTo(this.C - this.containerWidth)
    };
    g.k.J2 = function() {
        this.scrollTo(this.C + this.containerWidth)
    };
    g.k.resize = function(a, b) {
        var c = this.api.U(),
            d = 16 / 9,
            e = 650 <= a.width,
            f = 480 > a.width || 290 > a.height,
            h = Math.min(this.suggestionData.length, this.j.length);
        if (150 >= Math.min(a.width, a.height) || 0 === h || !c.Yd) this.hide();
        else {
            var l;
            if (e) {
                var m = l = 28;
                this.B = 16
            } else this.B = m = l = 8;
            if (f) {
                var n = 6;
                e = 14;
                var p = 12;
                f = 24;
                c = 12
            } else n = 8, e = 18, p = 16, f = 36, c = 16;
            a = a.width - (48 + l + m);
            l = Math.ceil(a / 150);
            l = Math.min(3, l);
            m = a / l - this.B;
            var q = Math.floor(m / d);
            b && q + 100 > b && 50 < m && (q = Math.max(b, 50 / d), l = Math.ceil(a / (d * (q - 100) + this.B)), m = a / l - this.B,
                q = Math.floor(m / d));
            50 > m || g.gU(this.api) ? this.hide() : this.show();
            for (b = 0; b < h; b++) {
                d = this.j[b];
                var r = d.Ga("ytp-suggestion-image");
                r.style.width = m + "px";
                r.style.height = q + "px";
                d.Ga("ytp-suggestion-title").style.width = m + "px";
                d.Ga("ytp-suggestion-author").style.width = m + "px";
                d = d.Ga("ytp-suggestion-duration");
                d.style.display = d && 100 > m ? "none" : ""
            }
            h = e + n + p + 4;
            this.K = h + c + (q - f) / 2;
            this.suggestions.element.style.height = q + h + "px";
            this.D = m;
            this.containerWidth = a;
            this.columns = l;
            this.C = 0;
            this.suggestions.element.scrollLeft = -0;
            gsb(this)
        }
    };
    g.k.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = this.api.U();
        this.Y = a.Pf ? !1 : b.D;
        a.suggestions ? this.suggestionData = g.qt(a.suggestions, function(c) {
            return c && !c.playlistId
        }) : this.suggestionData.length = 0;
        hsb(this);
        a.Pf ? this.title.update({
            title: g.VJ("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: a.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.k.scrollTo = function(a) {
        a = g.He(a, this.containerWidth - this.suggestionData.length * (this.D + this.B), 0);
        this.ma.start(this.C, a, 1E3);
        this.C = a;
        gsb(this);
        fsb(this, !0)
    };
    g.w(Z5, g.fW);
    Z5.prototype.show = function() {
        g.fW.prototype.show.call(this);
        jsb(this, this.api.qb().getPlayerSize())
    };
    Z5.prototype.resize = function(a) {
        g.fW.prototype.resize.call(this, a);
        this.j && (jsb(this, a), g.dv(this.element, "related-on-error-overlay-visible", !this.j.isHidden()))
    };
    Z5.prototype.B = function(a) {
        g.fW.prototype.B.call(this, a);
        var b = this.api.getVideoData();
        if (b.tC || b.playerErrorMessageRenderer)(a = b.tC) ? msb(this, a) : b.playerErrorMessageRenderer && msb(this, b.playerErrorMessageRenderer);
        else {
            var c;
            a.xn && (b.py ? ksb(b.py) ? c = g.TF(b.py) : c = g.gW(g.SF(b.py)) : c = g.gW(a.xn), this.Vd(c, "subreason"))
        }
    };
    g.w($5, g.V);
    $5.prototype.Dk = function() {
        this.api.Xb().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    $5.prototype.j = function() {
        var a = this.api.getVideoData(),
            b = this.api.U(),
            c = this.api.getVideoData().Pf,
            d = b.Ge,
            e = !b.Yd,
            f = this.df.Wg();
        b = b.C;
        d || f || c || e || b || this.api.md() || !a.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (a = nsb(this), this.updateValue("url", a), this.show())
    };
    $5.prototype.onClick = function(a) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var b = nsb(this);
        g.UU(b, this.api, a);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    $5.prototype.show = function() {
        this.api.Xb().isCued() && (g.V.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.w(a6, g.V);
    a6.prototype.Dk = function() {
        var a = this.api.Xb();
        !this.api.Wh() || g.DG(a, 2) && g.dU(this.api) || g.DG(a, 64) ? (this.api.logVisibility(this.j, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.j, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    a6.prototype.B = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.j)
    };
    a6.prototype.C = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.w(b6, g.V);
    b6.prototype.C = function() {
        var a = this.api.Xb(),
            b = this.api.getVideoData();
        this.api.U().L("embeds_enable_muted_autoplay") && b.mutedAutoplay && (g.DG(a, 2) && !this.Jb ? (this.show(), this.j || (this.j = new g.dW(this.api), g.N(this, this.j), this.j.Ja(this.D, 0), this.j.show()), a = this.api.getVideoData(), this.updateValue("text", a.G1), g.dv(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element, this.Jb), this.api.Ac("onMutedAutoplayEnds")) : this.hide())
    };
    b6.prototype.onClick = function() {
        if (!this.B) {
            this.j && (this.j.xa(), this.j = null);
            g.dv(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var a = this.api.getVideoData(),
                b = this.api.getCurrentTime();
            $pb(a);
            this.api.loadVideoById(a.videoId, b);
            this.api.qA();
            this.api.logClick(this.element);
            this.hide();
            this.B = !0
        }
    };
    b6.prototype.onMutedAutoplayStarts = function() {
        this.B = !1;
        this.j && (this.j.xa(), this.j = null)
    };
    g.w(c6, g.V);
    g.k = c6.prototype;
    g.k.m1 = function() {
        var a = this.api.getVideoData(),
            b = this.api.U().Ge && !g.DG(this.state, 2) && !g.LT(this.api.getVideoData(1));
        a.mutedAutoplay || g.OF(this, b);
        this.api.logVisibility(this.element, b)
    };
    g.k.onStateChange = function(a) {
        this.Hc(a.state)
    };
    g.k.Hc = function(a) {
        this.state !== a && (this.state = a);
        this.m1()
    };
    g.k.onVideoDataChange = function() {
        var a = this.api.U();
        a.C && g.$u(this.element, "ytp-no-hover");
        this.api.getVideoData().videoId && !a.C ? (a = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", a), this.j || (this.j = this.Ta("click", this.onClick))) : this.j && (this.updateValue("url", null), this.Tc(this.j), this.j = null)
    };
    g.k.onClick = function(a) {
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var b = this.api.getVideoUrl(!g.OG(a), !1, !0, !0);
        if (this.api.L("web_player_log_click_before_generating_ve_conversion_params")) {
            var c = {};
            g.RT(this.api, "addEmbedsConversionTrackingParams", [c]);
            b = g.cn(b, g.kP(c, "emb_yt_watermark"))
        }
        g.UU(b, this.api, a);
        this.api.L("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.k.Yb = function(a) {
        if ((a = 480 > a.width) && !this.B || !a && this.B) {
            var b = new g.V(aqb()),
                c = this.Ga("ytp-watermark");
            g.dv(c, "ytp-watermark-small", a);
            g.Pf(c);
            b.Ja(c);
            this.B = a
        }
    };
    g.w(qsb, g.V);
    g.k = qsb.prototype;
    g.k.JL = function() {
        var a = this.api.Xb(),
            b = this.api.getVideoData();
        this.api.U().L("embeds_enable_muted_autoplay") && b.mutedAutoplay && !g.DG(a, 2) ? this.Jb || (g.V.prototype.show.call(this), this.api.logVisibility(this.element, this.Jb)) : this.hide()
    };
    g.k.r8 = function() {
        this.j && this.j.hide()
    };
    g.k.onAutoplayBlocked = function() {
        this.hide();
        $pb(this.api.getVideoData())
    };
    g.k.onClick = function() {
        if (!this.B) {
            g.dv(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var a = this.api.getVideoData(),
                b = this.api.getCurrentTime();
            $pb(a);
            this.api.loadVideoById(a.videoId, b);
            this.api.qA();
            this.api.logClick(this.element);
            this.api.Ac("onMutedAutoplayEnds");
            this.B = !0
        }
    };
    g.k.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.xa(), this.watermark = null)
    };
    g.w(d6, g.V);
    d6.prototype.hide = function() {
        g.bv(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.V.prototype.hide.call(this)
    };
    d6.prototype.G = function() {
        this.B = !0;
        g.bv(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.md() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    d6.prototype.K = function() {
        this.B = !1;
        g.$u(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.md() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    d6.prototype.Sa = function() {
        var a = this.api.Xb();
        g.DG(a, 1) || g.DG(a, 16) || g.DG(a, 32) || (!g.DG(a, 4) || g.DG(a, 2) || g.DG(a, 1024) ? (this.B || this.api.logVisibility(this.element, !1), this.D.hide()) : this.j.bE() && (this.B || (g.$u(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.o2(this.j), this.j.show(), this.api.logVisibility(this.element, !0)), this.D.show()))
    };
    g.w(e6, g.V);
    e6.prototype.show = function() {
        g.V.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    e6.prototype.xa = function() {
        f6(this);
        g.V.prototype.xa.call(this)
    };
    g.w(usb, g.KV);
    g.k = usb.prototype;
    g.k.yl = function() {
        return !1
    };
    g.k.create = function() {
        var a = this.J.U(),
            b = g.XT(this.J),
            c, d = null == (c = this.J.getVideoData()) ? void 0 : c.clientPlaybackNonce;
        d && g.KH({
            clientPlaybackNonce: d
        });
        a.Za && wsb(this);
        a.L("embeds_enable_muted_autoplay") && (this.Z = new qsb(this.J), g.N(this, this.Z), g.jU(this.J, this.Z.element, 4), this.va = new b6(this.J), g.N(this, this.va), g.jU(this.J, this.va.element, 4));
        a.Ge && (this.watermark = new c6(this.J), g.N(this, this.watermark), g.jU(this.J, this.watermark.element, 8));
        b && (this.K = new $5(this.J, b), g.N(this, this.K), g.jU(this.J,
            this.K.element, 8), g.VT(this.J.app) && (this.onMutedAutoplayStarts(), this.K.hide()));
        a.B && (this.ma = new a6(this.J), g.N(this, this.ma), g.jU(this.J, this.ma.element, 4));
        this.j.T(this.J, "appresize", this.Yb);
        this.j.T(this.J, "presentingplayerstatechange", this.Dk);
        this.j.T(this.J, "videodatachange", this.onVideoDataChange);
        this.j.T(this.J, "videoplayerreset", this.Qw);
        this.j.T(this.J, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
        this.j.T(this.J, "onAdStart", this.onAdStart);
        this.j.T(this.J, "onAdComplete", this.onAdComplete);
        this.j.T(this.J, "onAdSkip", this.onAdSkip);
        this.j.T(this.J, "onAdStateChange", this.onAdStateChange);
        if (this.N = g.kC(g.YR(a))) this.countdownTimer = new e6(this.J), g.N(this, this.countdownTimer), g.jU(this.J, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.j.T(this.J, g.PJ("embeds"), this.onCueRangeEnter), this.j.T(this.J, g.QJ("embeds"), this.onCueRangeExit);
        this.Gc(this.J.Xb());
        this.player.Og("embed");
        var e, f;
        (null == (e = this.J.U().getWebPlayerContextConfig()) ? 0 : null == (f = e.embedsHostFlags) ? 0 : f.allowOverridingVisitorDataPlayerVars) &&
        (a = g.lB("IDENTITY_MEMENTO")) && this.J.Em("onMementoChange", a)
    };
    g.k.onCueRangeEnter = function(a) {
        "countdown timer" === a.getId() && this.countdownTimer && (this.countdownTimer.show(), ssb(this.countdownTimer))
    };
    g.k.onCueRangeExit = function(a) {
        "countdown timer" === a.getId() && this.countdownTimer && (f6(this.countdownTimer), this.countdownTimer.hide())
    };
    g.k.Yb = function() {
        var a = this.J.qb().getPlayerSize();
        this.Fg && this.Fg.resize(a)
    };
    g.k.Qw = function() {
        tsb(this)
    };
    g.k.Dk = function(a) {
        this.Gc(a.state)
    };
    g.k.Gc = function(a) {
        g.DG(a, 128) ? (this.Fg || (this.Fg = new Z5(this.J), g.N(this, this.Fg), g.jU(this.J, this.Fg.element, 4)), this.Fg.B(a.Ug), this.Fg.show(), g.$u(this.J.getRootNode(), "ytp-embed-error")) : this.Fg && (this.Fg.dispose(), this.Fg = null, g.bv(this.J.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.j)
            if (g.DG(a, 64)) this.countdownTimer.hide(), f6(this.countdownTimer);
            else if (a.isPaused()) {
            var b = this.countdownTimer;
            b.B || (b.B = !0, b.G = (0, g.jD)())
        } else a.isPlaying() && this.countdownTimer.B &&
            (b = this.countdownTimer, b.B && (b.D += (0, g.jD)() - b.G, b.B = !1, rsb(b)));
        vsb(this, a)
    };
    g.k.onMutedAutoplayStarts = function() {
        this.J.getVideoData().mutedAutoplay && this.Z && g.dv(this.J.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.k.onVideoDataChange = function(a, b) {
        var c = this.uE !== b.videoId;
        a = !c && "dataloaded" === a;
        var d = {
            isShortsModeEnabled: !!this.J.md()
        };
        g.WC("embedsVideoDataDidChange", {
            clientPlaybackNonce: b.clientPlaybackNonce,
            isReload: a,
            runtimeEnabledFeatures: d
        });
        c && (this.uE = b.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.N && (this.J.Ff("embeds"), b.isAd() || 5 > b.limitedPlaybackDurationInSeconds || g.gU(this.J) || (b = Math.max(1E3 * (b.startSeconds + b.limitedPlaybackDurationInSeconds - 5), 0),
            b = new g.OJ(b, b + 5E3, {
                id: "countdown timer",
                namespace: "embeds"
            }), this.J.Af([b]))), this.J.U().Za && (tsb(this), wsb(this)));
        this.J.U().C && this.C && this.C.detach()
    };
    g.k.onAdStart = function() {
        g6(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.k.onAdComplete = function() {
        g6(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.k.onAdSkip = function() {
        g6(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.k.onAdStateChange = function(a) {
        2 === a && g6(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.JV("embed", usb);
})(_yt_player);