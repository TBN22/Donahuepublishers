(function(g) {
    var window = this;
    'use strict';
    var Esb = function(a, b) {
            a.ob("onAutonavCoundownStarted", b)
        },
        j6 = function(a, b, c) {
            g.dv(a.element, "ytp-suggestion-set", !!b.videoId);
            var d = b.playlistId;
            c = b.ih(c ? c : "mqdefault.jpg");
            var e = null,
                f = null;
            b instanceof g.DS && (b.lengthText ? (e = b.lengthText || null, f = b.pw || null) : b.lengthSeconds && (e = g.NG(b.lengthSeconds), f = g.NG(b.lengthSeconds, !0)));
            var h = !!d;
            d = h && "RD" === g.xSa(d).type;
            var l = b instanceof g.DS ? b.isLivePlayback : null,
                m = b instanceof g.DS ? b.isUpcoming : null,
                n = b.author,
                p = b.shortViewCount,
                q = b.publishedTimeText,
                r = [],
                t = [];
            n && r.push(n);
            p && (r.push(p), t.push(p));
            q && t.push(q);
            c = {
                title: b.title,
                author: n,
                author_and_views: r.join(" \u2022 "),
                aria_label: b.ariaLabel ||
                    g.VJ("Watch $TITLE", {
                        TITLE: b.title
                    }),
                duration: e,
                timestamp: f,
                url: b.Uk(),
                is_live: l,
                is_upcoming: m,
                is_list: h,
                is_mix: d,
                background: c ? "background-image: url(" + c + ")" : "",
                views_and_publish_time: t.join(" \u2022 "),
                autoplayAlternativeHeader: b.xs
            };
            b instanceof g.CS && (c.playlist_length = b.playlistLength);
            a.update(c)
        },
        k6 = function(a) {
            var b = a.U(),
                c = b.D;
            g.V.call(this, {
                I: "a",
                S: "ytp-autonav-suggestion-card",
                X: {
                    href: "{{url}}",
                    target: c ? b.Y : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                V: [{
                    I: "div",
                    La: ["ytp-autonav-endscreen-upnext-thumbnail", "ytp-autonav-thumbnail-small"],
                    X: {
                        style: "{{background}}"
                    },
                    V: [{
                        I: "div",
                        X: {
                            "aria-label": "{{timestamp}}"
                        },
                        La: ["ytp-autonav-timestamp"],
                        ya: "{{duration}}"
                    }, {
                        I: "div",
                        La: ["ytp-autonav-live-stamp"],
                        ya: "Live"
                    }, {
                        I: "div",
                        La: ["ytp-autonav-upcoming-stamp"],
                        ya: "Upcoming"
                    }, {
                        I: "div",
                        S: "ytp-autonav-list-overlay",
                        V: [{
                            I: "div",
                            S: "ytp-autonav-mix-text",
                            ya: "Mix"
                        }, {
                            I: "div",
                            S: "ytp-autonav-mix-icon"
                        }]
                    }]
                }, {
                    I: "div",
                    La: ["ytp-autonav-endscreen-upnext-title", "ytp-autonav-title-card"],
                    ya: "{{title}}"
                }, {
                    I: "div",
                    La: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-author-card"],
                    ya: "{{author}}"
                }, {
                    I: "div",
                    La: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-view-and-date-card"],
                    ya: "{{views_and_publish_time}}"
                }]
            });
            this.J = a;
            this.suggestion =
                null;
            this.j = c;
            this.Ta("click", this.onClick);
            this.Ta("keypress", this.onKeyPress)
        },
        l6 = function(a, b) {
            b = void 0 === b ? !1 : b;
            g.V.call(this, {
                I: "div",
                S: "ytp-autonav-endscreen-countdown-overlay"
            });
            var c = this;
            this.N = b;
            this.G = this.K = void 0;
            this.C = 0;
            this.container = new g.V({
                I: "div",
                S: "ytp-autonav-endscreen-countdown-container"
            });
            g.N(this, this.container);
            this.container.Ja(this.element);
            b = a.U();
            var d = b.D;
            this.J = a;
            this.suggestion = null;
            this.onVideoDataChange("newdata", this.J.getVideoData());
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.j = new g.V({
                I: "div",
                S: "ytp-autonav-endscreen-upnext-container",
                X: {
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                V: [{
                    I: "div",
                    S: "ytp-autonav-endscreen-upnext-header"
                }, {
                    I: "div",
                    S: "ytp-autonav-endscreen-upnext-alternative-header",
                    ya: "{{autoplayAlternativeHeader}}"
                }, {
                    I: "a",
                    S: "ytp-autonav-endscreen-link-container",
                    X: {
                        href: "{{url}}",
                        target: d ? b.Y : ""
                    },
                    V: [{
                        I: "div",
                        S: "ytp-autonav-endscreen-upnext-thumbnail",
                        X: {
                            style: "{{background}}"
                        },
                        V: [{
                            I: "div",
                            X: {
                                "aria-label": "{{timestamp}}"
                            },
                            La: ["ytp-autonav-timestamp"],
                            ya: "{{duration}}"
                        }, {
                            I: "div",
                            La: ["ytp-autonav-live-stamp"],
                            ya: "Live"
                        }, {
                            I: "div",
                            La: ["ytp-autonav-upcoming-stamp"],
                            ya: "Upcoming"
                        }]
                    }, {
                        I: "div",
                        S: "ytp-autonav-endscreen-video-info",
                        V: [{
                            I: "div",
                            S: "ytp-autonav-endscreen-premium-badge"
                        }, {
                            I: "div",
                            S: "ytp-autonav-endscreen-upnext-title",
                            ya: "{{title}}"
                        }, {
                            I: "div",
                            S: "ytp-autonav-endscreen-upnext-author",
                            ya: "{{author}}"
                        }, {
                            I: "div",
                            S: "ytp-autonav-view-and-date",
                            ya: "{{views_and_publish_time}}"
                        }, {
                            I: "div",
                            S: "ytp-autonav-author-and-view",
                            ya: "{{author_and_views}}"
                        }]
                    }]
                }]
            });
            g.N(this, this.j);
            this.j.Ja(this.container.element);
            d || this.T(this.j.Ga("ytp-autonav-endscreen-link-container"), "click", this.jT);
            this.J.createClientVe(this.container.element, this, 115127);
            this.J.createClientVe(this.j.Ga("ytp-autonav-endscreen-link-container"), this, 115128);
            this.overlay = new g.V({
                I: "div",
                S: "ytp-autonav-overlay"
            });
            g.N(this, this.overlay);
            this.overlay.Ja(this.container.element);
            this.B = new g.V({
                I: "div",
                S: "ytp-autonav-endscreen-button-container"
            });
            g.N(this, this.B);
            this.B.Ja(this.container.element);
            this.cancelButton = new g.V({
                I: "button",
                La: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-cancel-button", b.L("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""],
                X: {
                    "aria-label": "Cancel autoplay"
                },
                ya: "Cancel"
            });
            g.N(this, this.cancelButton);
            this.cancelButton.Ja(this.B.element);
            this.cancelButton.Ta("click", this.L2, this);
            this.J.createClientVe(this.cancelButton.element, this, 115129);
            this.playButton = new g.V({
                I: "a",
                La: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-play-button",
                    b.L("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""
                ],
                X: {
                    href: "{{url}}",
                    role: "button",
                    "aria-label": "Play next video"
                },
                ya: "Play Now"
            });
            g.N(this, this.playButton);
            this.playButton.Ja(this.B.element);
            this.playButton.Ta("click", this.jT, this);
            this.J.L("web_player_autonav_next_button_renderer") ? (this.J.createServerVe(this.playButton.element, this.playButton, !0), (b = this.J.getVideoData()) && Fsb(this, b)) : this.J.createClientVe(this.playButton.element, this, 115130);
            this.D = new g.Su(function() {
                    Gsb(c)
                },
                500);
            g.N(this, this.D);
            this.iT();
            this.T(a, "autonavvisibility", this.iT);
            this.J.L("web_autonav_color_transition") && (this.T(a, "autonavchange", this.K2), this.T(a, "onAutonavCoundownStarted", this.S9))
        },
        m6 = function(a) {
            var b = a.J.Dn(!0, a.J.isFullscreen());
            g.dv(a.container.element, "ytp-autonav-endscreen-small-mode", a.Wg(b));
            g.dv(a.container.element, "ytp-autonav-endscreen-is-premium", !!a.suggestion && !!a.suggestion.SK);
            g.dv(a.J.getRootNode(), "ytp-autonav-endscreen-cancelled-state", !a.J.Nf());
            g.dv(a.J.getRootNode(), "countdown-running", a.Yk());
            g.dv(a.container.element, "ytp-player-content", a.J.Nf());
            g.ms(a.overlay.element, {
                width: b.width + "px"
            });
            if (!a.Yk()) {
                a.J.Nf() ? Hsb(a, Math.round(Isb(a) / 1E3)) : Hsb(a);
                b = !!a.suggestion && !!a.suggestion.xs;
                var c = a.J.Nf() || !b;
                g.dv(a.container.element, "ytp-autonav-endscreen-upnext-alternative-header-only", !c && b);
                g.dv(a.container.element, "ytp-autonav-endscreen-upnext-no-alternative-header", c && !b);
                g.OF(a.B, a.J.Nf());
                g.dv(a.element, "ytp-enable-w2w-color-transitions", Jsb(a))
            }
        },
        Gsb = function(a) {
            var b = Isb(a),
                c = Math,
                d = c.min;
            var e = a.C ? Date.now() - a.C : 0;
            c = d.call(c, e, b);
            Hsb(a, Math.ceil((b - c) / 1E3));
            500 >= b - c && a.Yk() ? a.select(!0) : a.Yk() && a.D.start()
        },
        Isb = function(a) {
            if (a.J.isFullscreen()) {
                var b;
                a = null == (b = a.J.getVideoData()) ? void 0 : b.WB;
                return -1 === a || void 0 === a ? 8E3 : a
            }
            return 0 <= a.J.Qs() ? a.J.Qs() : g.fJ(a.J.U().experiments, "autoplay_time") || 1E4
        },
        Fsb = function(a, b) {
            a.J.L("web_player_autonav_next_button_renderer");
            b = b.U6;
            a.K = null == b ? void 0 : b.navigationEndpoint;
            b = null == b ? void 0 : b.trackingParams;
            a.playButton && b && a.J.setTrackingParams(a.playButton.element, b)
        },
        Jsb = function(a) {
            var b;
            return !(null == (b = a.J.getVideoData()) || !b.watchToWatchTransitionRenderer)
        },
        Hsb = function(a, b) {
            b = void 0 === b ? -1 : b;
            a = a.j.Ga("ytp-autonav-endscreen-upnext-header");
            g.Pf(a);
            if (0 <= b) {
                b = String(b);
                var c = "Up next in $SECONDS".match(RegExp("\\$SECONDS", "gi"))[0],
                    d = "Up next in $SECONDS".indexOf(c);
                if (0 <= d) {
                    a.appendChild(g.Jf("Up next in $SECONDS".slice(0, d)));
                    var e = g.If("span");
                    g.Yu(e, "ytp-autonav-endscreen-upnext-header-countdown-number");
                    g.Vf(e, b);
                    a.appendChild(e);
                    a.appendChild(g.Jf("Up next in $SECONDS".slice(d + c.length)));
                    return
                }
            }
            g.Vf(a, "Up next")
        },
        n6 = function(a, b) {
            g.V.call(this, {
                I: "div",
                La: ["html5-endscreen", "ytp-player-content", b || "base-endscreen"]
            });
            this.created = !1;
            this.player = a
        },
        o6 = function(a) {
            g.V.call(this, {
                I: "div",
                La: ["ytp-upnext", "ytp-player-content"],
                X: {
                    "aria-label": "{{aria_label}}"
                },
                V: [{
                    I: "div",
                    S: "ytp-cued-thumbnail-overlay-image",
                    X: {
                        style: "{{background}}"
                    }
                }, {
                    I: "span",
                    S: "ytp-upnext-top",
                    V: [{
                        I: "span",
                        S: "ytp-upnext-header",
                        ya: "Up Next"
                    }, {
                        I: "span",
                        S: "ytp-upnext-title",
                        ya: "{{title}}"
                    }, {
                        I: "span",
                        S: "ytp-upnext-author",
                        ya: "{{author}}"
                    }]
                }, {
                    I: "a",
                    S: "ytp-upnext-autoplay-icon",
                    X: {
                        role: "button",
                        href: "{{url}}",
                        "aria-label": "Play next video"
                    },
                    V: [{
                        I: "svg",
                        X: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        V: [{
                            I: "circle",
                            S: "ytp-svg-autoplay-circle",
                            X: {
                                cx: "36",
                                cy: "36",
                                fill: "#fff",
                                "fill-opacity": "0.3",
                                r: "31.5"
                            }
                        }, {
                            I: "circle",
                            S: "ytp-svg-autoplay-ring",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            I: "path",
                            S: "ytp-svg-fill",
                            X: {
                                d: "M 24,48 41,36 24,24 V 48 z M 44,24 v 24 h 4 V 24 h -4 z"
                            }
                        }]
                    }]
                }, {
                    I: "span",
                    S: "ytp-upnext-bottom",
                    V: [{
                        I: "span",
                        S: "ytp-upnext-cancel"
                    }, {
                        I: "span",
                        S: "ytp-upnext-paused",
                        ya: "Autoplay is paused"
                    }]
                }]
            });
            this.api = a;
            this.cancelButton = null;
            this.G = this.Ga("ytp-svg-autoplay-ring");
            this.C = this.notification = this.j = this.suggestion = null;
            this.D = new g.Su(this.sH, 5E3, this);
            this.B = 0;
            var b = this.Ga("ytp-upnext-cancel");
            this.cancelButton = new g.V({
                I: "button",
                La: ["ytp-upnext-cancel-button", "ytp-button"],
                X: {
                    tabindex: "0",
                    "aria-label": "Cancel autoplay"
                },
                ya: "Cancel"
            });
            g.N(this, this.cancelButton);
            this.cancelButton.Ta("click", this.M2, this);
            this.cancelButton.Ja(b);
            this.cancelButton && this.api.createClientVe(this.cancelButton.element,
                this, 115129);
            g.N(this, this.D);
            this.api.createClientVe(this.element, this, 18788);
            b = this.Ga("ytp-upnext-autoplay-icon");
            this.T(b, "click", this.N2);
            this.api.createClientVe(b, this, 115130);
            this.kT();
            this.T(a, "autonavvisibility", this.kT);
            this.T(a, "mdxnowautoplaying", this.D$);
            this.T(a, "mdxautoplaycanceled", this.E$);
            g.dv(this.element, "ytp-upnext-mobile", this.api.U().B)
        },
        Ksb = function(a, b) {
            if (b) return b;
            if (a.api.isFullscreen()) {
                var c;
                a = null == (c = a.api.getVideoData()) ? void 0 : c.WB;
                return -1 === a || void 0 === a ? 8E3 : a
            }
            return 0 <= a.api.Qs() ? a.api.Qs() : g.fJ(a.api.U().experiments, "autoplay_time") || 1E4
        },
        Lsb = function(a, b) {
            b = Ksb(a, b);
            var c = Math,
                d = c.min;
            var e = (0, g.jD)() - a.B;
            c = d.call(c, e, b);
            b = 0 === b ? 1 : Math.min(c / b, 1);
            a.G.setAttribute("stroke-dashoffset", "" + -211 * (b + 1));
            1 <= b && a.Yk() && 3 !== a.api.getPresentingPlayerType() ? a.select(!0) : a.Yk() && a.j.start()
        },
        p6 = function(a) {
            n6.call(this, a, "autonav-endscreen");
            this.overlay = this.videoData = null;
            this.table = new g.V({
                I: "div",
                S: "ytp-suggestion-panel",
                V: [{
                    I: "div",
                    La: ["ytp-autonav-endscreen-upnext-header", "ytp-autonav-endscreen-more-videos"],
                    ya: "More videos"
                }]
            });
            this.N = new g.V({
                I: "div",
                S: "ytp-suggestions-container"
            });
            this.videos = [];
            this.C = null;
            this.G = this.K = !1;
            this.B = new l6(this.player);
            g.N(this, this.B);
            this.B.Ja(this.element);
            a.getVideoData().Yf ? this.j = this.B : (this.j = new o6(a), g.jU(this.player, this.j.element, 4), g.N(this, this.j));
            this.overlay = new g.V({
                I: "div",
                S: "ytp-autonav-overlay-cancelled-state"
            });
            g.N(this, this.overlay);
            this.overlay.Ja(this.element);
            this.D = new g.CK(this);
            g.N(this, this.D);
            g.N(this, this.table);
            this.table.Ja(this.element);
            this.table.show();
            g.N(this, this.N);
            this.N.Ja(this.table.element);
            this.hide()
        },
        q6 = function(a) {
            var b = a.Nf();
            b !== a.G && (a.G = b, a.player.ra("autonavvisibility"), a.G ? (a.B !== a.j && a.B.hide(), a.table.hide()) : (a.B !== a.j && a.B.show(), a.table.show()))
        },
        r6 = function(a, b) {
            g.V.call(this, {
                I: "button",
                La: ["ytp-watch-on-youtube-button", "ytp-button"],
                ya: "{{content}}"
            });
            this.J = a;
            this.buttonType = this.buttonType = b;
            this.Z_();
            2 === this.buttonType && g.$u(this.element, "ytp-continue-watching-button");
            this.Ta("click", this.onClick);
            this.Ta("videodatachange", this.Z_);
            g.OF(this, !0)
        },
        s6 = function(a, b) {
            n6.call(this, a, "embeds-lite-endscreen");
            this.J = a;
            this.df = b;
            this.J.createClientVe(this.element, this, 156943);
            this.watchButton = new r6(a, 2);
            g.N(this, this.watchButton);
            this.watchButton.Ja(this.element);
            this.hide()
        },
        Msb = function(a) {
            n6.call(this, a, "subscribecard-endscreen");
            this.j = new g.V({
                I: "div",
                S: "ytp-subscribe-card",
                V: [{
                    I: "img",
                    S: "ytp-author-image",
                    X: {
                        src: "{{profilePicture}}"
                    }
                }, {
                    I: "div",
                    S: "ytp-subscribe-card-right",
                    V: [{
                        I: "div",
                        S: "ytp-author-name",
                        ya: "{{author}}"
                    }, {
                        I: "div",
                        S: "html5-subscribe-button-container"
                    }]
                }]
            });
            g.N(this, this.j);
            this.j.Ja(this.element);
            var b = a.getVideoData();
            this.subscribeButton = new g.sW("Subscribe", null, "Unsubscribe", null, !0, !1, b.Hl, b.subscribed, "trailer-endscreen", null, a, !1);
            g.N(this, this.subscribeButton);
            this.subscribeButton.Ja(this.j.Ga("html5-subscribe-button-container"));
            this.T(a, "videodatachange", this.Sa);
            this.Sa();
            this.hide()
        },
        t6 = function(a) {
            var b = a.U(),
                c = g.AK || g.OR ? {
                    style: "will-change: opacity"
                } : void 0,
                d = b.D,
                e = ["ytp-videowall-still"];
            b.B && e.push("ytp-videowall-show-text");
            g.V.call(this, {
                I: "a",
                La: e,
                X: {
                    href: "{{url}}",
                    target: d ? b.Y : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                V: [{
                    I: "div",
                    S: "ytp-videowall-still-image",
                    X: {
                        style: "{{background}}"
                    }
                }, {
                    I: "span",
                    S: "ytp-videowall-still-info",
                    X: {
                        "aria-hidden": "true"
                    },
                    V: [{
                        I: "span",
                        S: "ytp-videowall-still-info-bg",
                        V: [{
                            I: "span",
                            S: "ytp-videowall-still-info-content",
                            X: c,
                            V: [{
                                    I: "span",
                                    S: "ytp-videowall-still-info-title",
                                    ya: "{{title}}"
                                },
                                {
                                    I: "span",
                                    S: "ytp-videowall-still-info-author",
                                    ya: "{{author_and_views}}"
                                }, {
                                    I: "span",
                                    S: "ytp-videowall-still-info-live",
                                    ya: "Live"
                                }, {
                                    I: "span",
                                    S: "ytp-videowall-still-info-duration",
                                    ya: "{{duration}}"
                                }
                            ]
                        }]
                    }]
                }, {
                    I: "span",
                    La: ["ytp-videowall-still-listlabel-regular", "ytp-videowall-still-listlabel"],
                    X: {
                        "aria-hidden": "true"
                    },
                    V: [{
                        I: "span",
                        S: "ytp-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        I: "span",
                        S: "ytp-videowall-still-listlabel-length",
                        V: [" (", {
                            I: "span",
                            ya: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    I: "span",
                    La: ["ytp-videowall-still-listlabel-mix",
                        "ytp-videowall-still-listlabel"
                    ],
                    X: {
                        "aria-hidden": "true"
                    },
                    V: [{
                        I: "span",
                        S: "ytp-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        I: "span",
                        S: "ytp-videowall-still-listlabel-length",
                        ya: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.B = d;
            this.api = a;
            this.j = new g.CK(this);
            g.N(this, this.j);
            this.Ta("click", this.onClick);
            this.Ta("keypress", this.onKeyPress);
            this.j.T(a, "videodatachange", this.onVideoDataChange);
            a.createServerVe(this.element, this);
            this.onVideoDataChange()
        },
        u6 = function(a) {
            n6.call(this, a, "videowall-endscreen");
            var b = this;
            this.J = a;
            this.C = 0;
            this.stills = [];
            this.D = this.videoData = null;
            this.G = this.N = !1;
            this.Y = null;
            this.B = new g.CK(this);
            g.N(this, this.B);
            this.K = new g.Su(function() {
                g.$u(b.element, "ytp-show-tiles")
            }, 0);
            g.N(this, this.K);
            var c = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-endscreen-previous"],
                X: {
                    "aria-label": "Previous"
                },
                V: [g.UF()]
            });
            g.N(this, c);
            c.Ja(this.element);
            c.Ta("click", this.R2, this);
            this.table = new g.LF({
                I: "div",
                S: "ytp-endscreen-content"
            });
            g.N(this, this.table);
            this.table.Ja(this.element);
            c = new g.V({
                I: "button",
                La: ["ytp-button", "ytp-endscreen-next"],
                X: {
                    "aria-label": "Next"
                },
                V: [g.VF()]
            });
            g.N(this, c);
            c.Ja(this.element);
            c.Ta("click", this.Q2, this);
            a.getVideoData().Yf ? this.j = new l6(a, !0) : this.j = new o6(a);
            g.N(this, this.j);
            g.jU(this.player, this.j.element, 4);
            a.createClientVe(this.element, this, 158789);
            this.hide()
        },
        v6 = function(a) {
            return g.kU(a.player) && a.RC() && !a.D
        },
        w6 = function(a) {
            var b = a.Nf();
            b !== a.N && (a.N = b, a.player.ra("autonavvisibility"))
        },
        x6 = function(a) {
            n6.call(this, a, "watch-again-on-youtube-endscreen");
            this.watchButton = new r6(a, 1);
            g.N(this, this.watchButton);
            this.watchButton.Ja(this.element);
            g.Sgb(a) && (this.j = new g.n2(a), g.N(this, this.j), this.B = new g.V({
                I: "div",
                La: ["ytp-watch-again-on-youtube-endscreen-more-videos-container"],
                X: {
                    tabIndex: "-1"
                },
                V: [this.j]
            }), g.N(this, this.B), this.j.Ja(this.B.element), this.B.Ja(this.element));
            a.createClientVe(this.element, this, 156914);
            this.hide()
        },
        Qsb = function(a) {
            g.KV.call(this, a);
            var b = this;
            this.endScreen = null;
            this.B = this.j = this.C = this.D = !1;
            this.listeners = new g.CK(this);
            g.N(this, this.listeners);
            var c = a.U(),
                d = a.getVideoData();
            d = d && 0 !== d.limitedPlaybackDurationInSeconds;
            g.kC(g.YR(c)) && d && !g.gU(a) ? (this.B = !0, this.endScreen = new s6(a, g.XT(a))) : a.md() ? this.endScreen = new x6(a) : Nsb(a) ? (this.D = !0, Osb(this), this.j ? this.endScreen = new p6(a) : this.endScreen = new u6(a)) : c.Zg ? this.endScreen = new Msb(a) : this.endScreen = new n6(a);
            g.N(this, this.endScreen);
            g.jU(a, this.endScreen.element, 4);
            Psb(this);
            this.listeners.T(a, "videodatachange", this.onVideoDataChange, this);
            this.listeners.T(a, g.PJ("endscreen"), function(e) {
                b.onCueRangeEnter(e)
            });
            this.listeners.T(a, g.QJ("endscreen"), function(e) {
                b.onCueRangeExit(e)
            })
        },
        Osb = function(a) {
            var b = a.player.getVideoData();
            if (!b || a.j === b.Ll && a.C === b.Yf) return !1;
            a.j = b.Ll;
            a.C = b.Yf;
            return !0
        },
        Nsb = function(a) {
            a = a.U();
            return a.Yd && !a.Zg
        },
        Psb = function(a) {
            a.player.Ff("endscreen");
            var b = a.player.getVideoData();
            b = new g.OJ(Math.max(1E3 * (b.lengthSeconds - 10), 0), 0x8000000000000, {
                id: "preload",
                namespace: "endscreen"
            });
            var c = new g.OJ(0x8000000000000, 0x8000000000000, {
                id: "load",
                priority: 8,
                namespace: "endscreen"
            });
            a.player.Af([b, c])
        };
    g.cU.prototype.Qs = g.fa(16, function() {
        return this.app.Qs()
    });
    g.R0.prototype.Qs = g.fa(15, function() {
        return this.getVideoData().bV
    });
    g.ZT.prototype.Hr = g.fa(14, function(a) {
        this.Fi().Hr(a)
    });
    g.TW.prototype.Hr = g.fa(13, function(a) {
        this.j !== a && (this.j = a, this.Sa())
    });
    g.aY.prototype.Hr = g.fa(12, function(a) {
        this.overflowButton && this.overflowButton.Hr(a)
    });
    g.ZT.prototype.Ir = g.fa(11, function(a) {
        this.Fi().Ir(a)
    });
    g.YW.prototype.Ir = g.fa(10, function(a) {
        this.j !== a && (this.j = a, this.Sa())
    });
    g.aY.prototype.Ir = g.fa(9, function(a) {
        this.shareButton && this.shareButton.Ir(a)
    });
    g.ZT.prototype.uB = g.fa(8, function(a) {
        this.Fi().uB(a)
    });
    g.lW.prototype.uB = g.fa(7, function(a) {
        this.TQ !== a && (this.TQ = a, this.hq())
    });
    g.ZT.prototype.tB = g.fa(6, function(a) {
        this.Fi().tB(a)
    });
    g.aY.prototype.tB = g.fa(5, function(a) {
        this.SQ !== a && (this.SQ = a, this.gq())
    });
    g.w(k6, g.V);
    k6.prototype.select = function() {
        this.J.Mo(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.nD || void 0) && this.J.logClick(this.element)
    };
    k6.prototype.onClick = function(a) {
        g.TU(a, this.J, this.j, this.suggestion.sessionData || void 0) && this.select()
    };
    k6.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                a.defaultPrevented || (this.select(), a.preventDefault())
        }
    };
    g.w(l6, g.V);
    g.k = l6.prototype;
    g.k.FG = function(a) {
        this.suggestion !== a && (this.suggestion = a, j6(this.j, a), this.playButton.updateValue("url", this.suggestion.Uk()), m6(this))
    };
    g.k.Yk = function() {
        return 0 < this.C
    };
    g.k.CB = function() {
        this.Yk() || (this.C = Date.now(), Gsb(this), Esb(this.J, Isb(this)), g.dv(this.J.getRootNode(), "countdown-running", this.Yk()))
    };
    g.k.Xw = function() {
        this.bq();
        Gsb(this);
        var a = this.j.Ga("ytp-autonav-endscreen-upnext-header");
        a && g.Vf(a, "Up next")
    };
    g.k.bq = function() {
        this.Yk() && (this.D.stop(), this.C = 0)
    };
    g.k.select = function(a) {
        this.J.nextVideo(!1, void 0 === a ? !1 : a);
        this.bq()
    };
    g.k.jT = function(a) {
        g.TU(a, this.J) && (a.currentTarget === this.playButton.element ? this.J.logClick(this.playButton.element) : a.currentTarget === this.j.Ga("ytp-autonav-endscreen-link-container") && (a = this.j.Ga("ytp-autonav-endscreen-link-container"), this.J.logVisibility(a, !0), this.J.logClick(a)), this.J.L("web_player_autonav_next_button_renderer") && this.K ? (this.J.ob("innertubeCommand", this.K), this.bq()) : this.select())
    };
    g.k.L2 = function() {
        this.J.logClick(this.cancelButton.element);
        g.eU(this.J, !0);
        this.G && this.J.ob("innertubeCommand", this.G)
    };
    g.k.onVideoDataChange = function(a, b) {
        this.J.L("web_player_autonav_next_button_renderer") && Fsb(this, b);
        var c;
        this.G = null == (c = b.C6) ? void 0 : c.command
    };
    g.k.S9 = function(a) {
        if (Jsb(this)) {
            var b = this.J.getVideoData().watchToWatchTransitionRenderer,
                c = null == b ? void 0 : b.fromColorPaletteDark;
            b = null == b ? void 0 : b.toColorPaletteDark;
            if (c && b) {
                var d = this.element;
                d.style.setProperty("--w2w-start-background-color", g.VG(c.surgeColor));
                d.style.setProperty("--w2w-start-primary-text-color", g.VG(c.primaryTitleColor));
                d.style.setProperty("--w2w-start-secondary-text-color", g.VG(c.secondaryTitleColor));
                d.style.setProperty("--w2w-end-background-color", g.VG(b.surgeColor));
                d.style.setProperty("--w2w-end-primary-text-color", g.VG(b.primaryTitleColor));
                d.style.setProperty("--w2w-end-secondary-text-color", g.VG(b.secondaryTitleColor));
                d.style.setProperty("--w2w-animation-duration", a + "ms")
            }
            g.dv(this.element, "ytp-w2w-animate", !0)
        }
    };
    g.k.K2 = function(a) {
        this.J.L("web_autonav_color_transition") && 2 !== a && g.dv(this.element, "ytp-w2w-animate", !1)
    };
    g.k.iT = function() {
        var a = this.J.Nf();
        this.N && this.Jb !== a && g.OF(this, a);
        m6(this);
        this.J.logVisibility(this.container.element, a);
        this.J.logVisibility(this.cancelButton.element, a);
        this.J.logVisibility(this.j.Ga("ytp-autonav-endscreen-link-container"), a);
        this.J.logVisibility(this.playButton.element, a)
    };
    g.k.Wg = function(a) {
        return 400 > a.width || 459 > a.height
    };
    g.w(n6, g.V);
    g.k = n6.prototype;
    g.k.create = function() {
        this.created = !0
    };
    g.k.destroy = function() {
        this.created = !1
    };
    g.k.RC = function() {
        return !1
    };
    g.k.Nf = function() {
        return !1
    };
    g.k.oY = function() {
        return !1
    };
    g.w(o6, g.V);
    g.k = o6.prototype;
    g.k.sH = function() {
        this.notification && (this.D.stop(), this.Tc(this.C), this.C = null, this.notification.close(), this.notification = null)
    };
    g.k.FG = function(a) {
        this.suggestion = a;
        j6(this, a, "hqdefault.jpg")
    };
    g.k.kT = function() {
        g.OF(this, this.api.Nf());
        this.api.logVisibility(this.element, this.api.Nf());
        this.api.logVisibility(this.Ga("ytp-upnext-autoplay-icon"), this.api.Nf());
        this.cancelButton && this.api.logVisibility(this.cancelButton.element, this.api.Nf())
    };
    g.k.M$ = function() {
        window.focus();
        this.sH()
    };
    g.k.CB = function(a) {
        var b = this;
        this.Yk() || (g.tE("a11y-announce", "Up Next " + this.suggestion.title), this.B = (0, g.jD)(), this.j = new g.Su(function() {
            Lsb(b, a)
        }, 25), Lsb(this, a), Esb(this.api, Ksb(this, a)));
        g.bv(this.element, "ytp-upnext-autoplay-paused")
    };
    g.k.hide = function() {
        g.V.prototype.hide.call(this)
    };
    g.k.Yk = function() {
        return !!this.j
    };
    g.k.Xw = function() {
        this.bq();
        this.B = (0, g.jD)();
        Lsb(this);
        g.$u(this.element, "ytp-upnext-autoplay-paused")
    };
    g.k.bq = function() {
        this.Yk() && (this.j.dispose(), this.j = null)
    };
    g.k.select = function(a) {
        a = void 0 === a ? !1 : a;
        if (this.api.U().L("autonav_notifications") && a && window.Notification && "function" === typeof document.hasFocus) {
            var b = Notification.permission;
            "default" === b ? Notification.requestPermission() : "granted" !== b || document.hasFocus() || (this.sH(), this.notification = new Notification("Up Next", {
                body: this.suggestion.title,
                icon: this.suggestion.ih()
            }), this.C = this.T(this.notification, "click", this.M$), this.D.start())
        }
        this.bq();
        this.api.nextVideo(!1, a)
    };
    g.k.N2 = function(a) {
        !g.Tf(this.cancelButton.element, a.target) && g.TU(a, this.api) && (this.api.Nf() && this.api.logClick(this.Ga("ytp-upnext-autoplay-icon")), this.select())
    };
    g.k.M2 = function() {
        this.api.Nf() && this.cancelButton && this.api.logClick(this.cancelButton.element);
        g.eU(this.api, !0)
    };
    g.k.D$ = function(a) {
        this.api.getPresentingPlayerType();
        this.show();
        this.CB(a)
    };
    g.k.E$ = function() {
        this.api.getPresentingPlayerType();
        this.bq();
        this.hide()
    };
    g.k.xa = function() {
        this.bq();
        this.sH();
        g.V.prototype.xa.call(this)
    };
    g.w(p6, n6);
    g.k = p6.prototype;
    g.k.create = function() {
        n6.prototype.create.call(this);
        this.D.T(this.player, "appresize", this.eC);
        this.D.T(this.player, "onVideoAreaChange", this.eC);
        this.D.T(this.player, "videodatachange", this.onVideoDataChange);
        this.D.T(this.player, "autonavchange", this.lT);
        this.D.T(this.player, "onAutonavCancelled", this.O2);
        this.onVideoDataChange()
    };
    g.k.show = function() {
        n6.prototype.show.call(this);
        (this.K || this.C && this.C !== this.videoData.clientPlaybackNonce) && g.eU(this.player, !1);
        g.kU(this.player) && this.RC() && !this.C ? (q6(this), 2 === this.videoData.autonavState ? 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.CB() : 3 === this.videoData.autonavState && this.j.Xw()) : (g.eU(this.player, !0), q6(this));
        this.eC()
    };
    g.k.hide = function() {
        n6.prototype.hide.call(this);
        this.j.Xw();
        q6(this)
    };
    g.k.eC = function() {
        var a = this.player.Dn(!0, this.player.isFullscreen());
        q6(this);
        m6(this.B);
        g.dv(this.element, "ytp-autonav-cancelled-small-mode", this.Wg(a));
        g.dv(this.element, "ytp-autonav-cancelled-tiny-mode", this.TI(a));
        g.dv(this.element, "ytp-autonav-cancelled-mini-mode", 400 >= a.width || 360 >= a.height);
        this.overlay && g.ms(this.overlay.element, {
            width: a.width + "px"
        });
        if (!this.G)
            for (a = 0; a < this.videos.length; a++) g.dv(this.videos[a].element, "ytp-suggestion-card-with-margin", 1 === a % 2)
    };
    g.k.onVideoDataChange = function() {
        var a = this.player.getVideoData();
        if (this.videoData !== a && a) {
            this.videoData = a;
            if ((a = this.videoData.suggestions) && a.length || this.player.L("web_player_autonav_empty_suggestions_fix")) {
                var b = g.dT(this.videoData);
                b && (this.j.FG(b), this.j !== this.B && this.B.FG(b))
            }
            if (a && a.length)
                for (b = 0; b < Rsb.length; ++b) {
                    var c = Rsb[b];
                    if (a && a[c]) {
                        this.videos[b] = new k6(this.player);
                        var d = this.videos[b];
                        c = a[c];
                        d.suggestion !== c && (d.suggestion = c, j6(d, c));
                        g.N(this, this.videos[b]);
                        this.videos[b].Ja(this.N.element)
                    }
                }
            this.eC()
        }
    };
    g.k.lT = function(a) {
        1 === a ? (this.K = !1, this.C = this.videoData.clientPlaybackNonce, this.j.bq(), this.Jb && this.eC()) : (this.K = !0, this.Nf() && (2 === a ? this.j.CB() : 3 === a && this.j.Xw()))
    };
    g.k.O2 = function(a) {
        a ? this.lT(1) : (this.C = null, this.K = !1)
    };
    g.k.RC = function() {
        return 1 !== this.videoData.autonavState
    };
    g.k.Wg = function(a) {
        return (910 > a.width || 459 > a.height) && !this.TI(a) && !(400 >= a.width || 360 >= a.height)
    };
    g.k.TI = function(a) {
        return 800 > a.width && !(400 >= a.width || 360 >= a.height)
    };
    g.k.Nf = function() {
        return this.Jb && g.kU(this.player) && this.RC() && !this.C
    };
    var Rsb = [1, 3, 2, 4];
    g.w(r6, g.V);
    g.k = r6.prototype;
    g.k.Z_ = function() {
        switch (this.buttonType) {
            case 1:
                var a = "Watch again on YouTube";
                var b = 156915;
                break;
            case 2:
                a = "Continue watching on YouTube";
                b = 156942;
                break;
            default:
                a = "Continue watching on YouTube", b = 156942
        }
        this.update({
            content: a
        });
        this.J.hasVe(this.element) && this.J.destroyVe(this.element);
        this.J.createClientVe(this.element, this, b)
    };
    g.k.onClick = function(a) {
        this.J.L("web_player_log_click_before_generating_ve_conversion_params") && this.J.logClick(this.element);
        g.UU(this.getVideoUrl(), this.J, a);
        this.J.L("web_player_log_click_before_generating_ve_conversion_params") || this.J.logClick(this.element)
    };
    g.k.getVideoUrl = function() {
        var a = !0;
        switch (this.buttonType) {
            case 1:
                a = !0;
                break;
            case 2:
                a = !1
        }
        a = this.J.getVideoUrl(a, !1, !1, !0);
        var b = this.J.U();
        if (g.PR(b)) {
            var c = {};
            g.PR(b) && g.RT(this.J, "addEmbedsConversionTrackingParams", [c]);
            a: {
                switch (this.buttonType) {
                    case 2:
                        b = "emb_ytp_continue_watching";
                        break a
                }
                b = "emb_ytp_watch_again"
            }
            g.kP(c, b);
            a = g.cn(a, c)
        }
        return a
    };
    g.k.logVisibility = function() {
        this.J.logVisibility(this.element, this.Jb && this.Z)
    };
    g.k.show = function() {
        g.V.prototype.show.call(this);
        this.logVisibility()
    };
    g.k.hide = function() {
        g.V.prototype.hide.call(this);
        this.logVisibility()
    };
    g.k.Nc = function(a) {
        g.V.prototype.Nc.call(this, a);
        this.logVisibility()
    };
    g.w(s6, n6);
    s6.prototype.show = function() {
        3 !== this.player.getPlayerState() && (n6.prototype.show.call(this), this.df.tB(!0), this.df.Ir(!0), this.J.U().Fe || this.df.Hr(!0), this.J.logVisibility(this.element, !0), this.watchButton.Nc(!0))
    };
    s6.prototype.hide = function() {
        n6.prototype.hide.call(this);
        this.df.tB(!1);
        this.df.Ir(!1);
        this.df.Hr(!1);
        this.J.logVisibility(this.element, !1);
        this.watchButton.Nc(!1)
    };
    g.w(Msb, n6);
    Msb.prototype.Sa = function() {
        var a = this.player.getVideoData();
        this.j.update({
            profilePicture: a.profilePicture,
            author: a.author
        });
        this.subscribeButton.channelId = a.Hl;
        var b = this.subscribeButton;
        a.subscribed ? b.j() : b.B()
    };
    g.w(t6, g.V);
    t6.prototype.select = function() {
        this.api.Mo(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.nD || void 0) && this.api.logClick(this.element)
    };
    t6.prototype.onClick = function(a) {
        if (g.PR(this.api.U()) && this.api.L("web_player_log_click_before_generating_ve_conversion_params")) {
            this.api.logClick(this.element);
            var b = this.suggestion.Uk(),
                c = {};
            g.QUa(this.api, c, "emb_rel_end");
            b = g.cn(b, c);
            g.UU(b, this.api, a)
        } else g.TU(a, this.api, this.B, this.suggestion.sessionData || void 0) && this.select()
    };
    t6.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                a.defaultPrevented || (this.select(), a.preventDefault())
        }
    };
    t6.prototype.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = this.api.U();
        this.B = a.Pf ? !1 : b.D
    };
    g.w(u6, n6);
    g.k = u6.prototype;
    g.k.create = function() {
        n6.prototype.create.call(this);
        var a = this.player.getVideoData();
        a && (this.videoData = a);
        this.lq();
        this.B.T(this.player, "appresize", this.lq);
        this.B.T(this.player, "onVideoAreaChange", this.lq);
        this.B.T(this.player, "videodatachange", this.onVideoDataChange);
        this.B.T(this.player, "autonavchange", this.KL);
        this.B.T(this.player, "onAutonavCancelled", this.P2);
        a = this.videoData.autonavState;
        a !== this.Y && this.KL(a);
        this.B.T(this.element, "transitionend", this.eba)
    };
    g.k.destroy = function() {
        g.zC(this.B);
        g.xb(this.stills);
        this.stills = [];
        n6.prototype.destroy.call(this);
        g.bv(this.element, "ytp-show-tiles");
        this.K.stop();
        this.Y = this.videoData.autonavState
    };
    g.k.RC = function() {
        return 1 !== this.videoData.autonavState
    };
    g.k.show = function() {
        var a = this.Jb;
        n6.prototype.show.call(this);
        g.bv(this.element, "ytp-show-tiles");
        this.player.U().B ? g.Uu(this.K) : this.K.start();
        (this.G || this.D && this.D !== this.videoData.clientPlaybackNonce) && g.eU(this.player, !1);
        v6(this) ? (w6(this), 2 === this.videoData.autonavState ? 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.CB() : 3 === this.videoData.autonavState && this.j.Xw()) : (g.eU(this.player, !0), w6(this));
        a !== this.Jb && this.player.logVisibility(this.element, !0)
    };
    g.k.hide = function() {
        var a = this.Jb;
        n6.prototype.hide.call(this);
        this.j.Xw();
        w6(this);
        a !== this.Jb && this.player.logVisibility(this.element, !1)
    };
    g.k.eba = function(a) {
        a.target === this.element && this.lq()
    };
    g.k.lq = function() {
        var a, b, c, d;
        var e = (null == (a = this.videoData) ? 0 : null == (b = a.suggestions) ? 0 : b.length) ? null == (c = this.videoData) ? void 0 : c.suggestions : [null == (d = this.videoData) ? void 0 : g.dT(d)];
        if (e.length) {
            g.$u(this.element, "ytp-endscreen-paginate");
            var f = this.J.Dn(!0, this.J.isFullscreen());
            if (a = g.XT(this.J)) a = a.Eh() ? 48 : 32, f.width -= 2 * a;
            var h = f.width / f.height;
            d = 96 / 54;
            b = a = 2;
            var l = Math.max(f.width / 96, 2),
                m = Math.max(f.height / 54, 2);
            c = e.length;
            var n = Math.pow(2, 2);
            var p = c * n + (Math.pow(2, 2) - n);
            p += Math.pow(2, 2) -
                n;
            for (p -= n; 0 < p && (a < l || b < m);) {
                var q = a / 2,
                    r = b / 2,
                    t = a <= l - 2 && p >= r * n,
                    v = b <= m - 2 && p >= q * n;
                if ((q + 1) / r * d / h > h / (q / (r + 1) * d) && v) p -= q * n, b += 2;
                else if (t) p -= r * n, a += 2;
                else if (v) p -= q * n, b += 2;
                else break
            }
            d = !1;
            p >= 3 * n && 6 >= c * n - p && (4 <= b || 4 <= a) && (d = !0);
            n = 96 * a;
            p = 54 * b;
            h = n / p < h ? f.height / p : f.width / n;
            h = Math.min(h, 2);
            n = Math.floor(Math.min(f.width, n * h));
            p = Math.floor(Math.min(f.height, p * h));
            f = this.table.element;
            f.ariaLive = "polite";
            g.xs(f, n, p);
            g.ms(f, {
                marginLeft: n / -2 + "px",
                marginTop: p / -2 + "px"
            });
            this.j.FG(g.dT(this.videoData));
            this.j instanceof
            l6 && m6(this.j);
            g.dv(this.element, "ytp-endscreen-takeover", v6(this));
            w6(this);
            n += 4;
            p += 4;
            h = 0;
            f.ariaBusy = "true";
            for (l = 0; l < a; l++)
                for (m = 0; m < b; m++)
                    if (q = h, t = 0, d && l >= a - 2 && m >= b - 2 ? t = 1 : 0 === m % 2 && 0 === l % 2 && (2 > m && 2 > l ? 0 === m && 0 === l && (t = 2) : t = 2), q = g.Ie(q + this.C, c), 0 !== t) {
                        r = this.stills[h];
                        r || (r = new t6(this.player), this.stills[h] = r, f.appendChild(r.element));
                        v = Math.floor(p * m / b);
                        var x = Math.floor(n * l / a),
                            A = Math.floor(p * (m + t) / b) - v - 4,
                            E = Math.floor(n * (l + t) / a) - x - 4;
                        g.ts(r.element, x, v);
                        g.xs(r.element, E, A);
                        g.ms(r.element, "transitionDelay",
                            (m + l) / 20 + "s");
                        g.dv(r.element, "ytp-videowall-still-mini", 1 === t);
                        g.dv(r.element, "ytp-videowall-still-large", 2 < t);
                        t = Math.max(E, A);
                        g.dv(r.element, "ytp-videowall-still-round-large", 256 <= t);
                        g.dv(r.element, "ytp-videowall-still-round-medium", 96 < t && 256 > t);
                        g.dv(r.element, "ytp-videowall-still-round-small", 96 >= t);
                        q = e[q];
                        r.suggestion !== q && (r.suggestion = q, t = r.api.U(), v = g.Zu(r.element, "ytp-videowall-still-large") ? "hqdefault.jpg" : "mqdefault.jpg", j6(r, q, v), g.PR(t) && !r.api.L("web_player_log_click_before_generating_ve_conversion_params") &&
                            (t = q.Uk(), v = {}, g.RT(r.api, "addEmbedsConversionTrackingParams", [v]), t = g.cn(t, g.kP(v, "emb_rel_end")), r.updateValue("url", t)), (q = (q = q.sessionData) && q.itct) && r.api.setTrackingParams(r.element, q));
                        h++
                    }
            f.ariaBusy = "false";
            g.dv(this.element, "ytp-endscreen-paginate", h < c);
            for (e = this.stills.length - 1; e >= h; e--) a = this.stills[e], g.Rf(a.element), g.vb(a);
            this.stills.length = h
        }
    };
    g.k.onVideoDataChange = function() {
        var a, b = (null == (a = this.player.U()) ? 0 : a.L("html5_ignore_null_autonav_suggestion")) ? this.player.getVideoData(1) : this.player.getVideoData();
        if (this.videoData !== b) {
            var c;
            null == (c = this.player.U()) || !c.L("html5_ignore_null_autonav_suggestion") || null != b && g.dT(b) ? (this.C = 0, this.videoData = b, this.lq()) : this.player.qa("missg", {
                vid: (null == b ? void 0 : b.videoId) || "",
                cpn: (null == b ? void 0 : b.clientPlaybackNonce) || ""
            })
        }
    };
    g.k.Q2 = function() {
        this.C += this.stills.length;
        this.lq()
    };
    g.k.R2 = function() {
        this.C -= this.stills.length;
        this.lq()
    };
    g.k.oY = function() {
        return this.j.Yk()
    };
    g.k.KL = function(a) {
        1 === a ? (this.G = !1, this.D = this.videoData.clientPlaybackNonce, this.j.bq(), this.Jb && this.lq()) : (this.G = !0, this.Jb && v6(this) && (2 === a ? this.j.CB() : 3 === a && this.j.Xw()))
    };
    g.k.P2 = function(a) {
        if (a) {
            for (a = 0; a < this.stills.length; a++) this.J.logVisibility(this.stills[a].element, !0);
            this.KL(1)
        } else this.D = null, this.G = !1;
        this.lq()
    };
    g.k.Nf = function() {
        return this.Jb && v6(this)
    };
    g.w(x6, n6);
    x6.prototype.bE = function() {
        var a;
        return null == (a = this.j) ? void 0 : a.bE()
    };
    x6.prototype.show = function() {
        if (3 !== this.player.getPlayerState()) {
            n6.prototype.show.call(this);
            var a = this.B;
            if (a) {
                var b = this.j.bE();
                g.dv(this.element, "ytp-shorts-branded-ui", b);
                b ? a.show() : a.hide()
            }
            var c;
            null == (c = g.XT(this.player)) || c.uB(!0);
            this.player.logVisibility(this.element, !0);
            this.watchButton.Nc(!0)
        }
    };
    x6.prototype.hide = function() {
        n6.prototype.hide.call(this);
        var a;
        null == (a = g.XT(this.player)) || a.uB(!1);
        this.player.logVisibility(this.element, !1);
        this.watchButton.Nc(!1)
    };
    g.w(Qsb, g.KV);
    g.k = Qsb.prototype;
    g.k.au = function() {
        var a = this.player.getVideoData(),
            b = a.mutedAutoplay;
        if ((this.player.md() || this.B) && !b) return !0;
        var c;
        var d = !!((null == a ? 0 : g.dT(a)) || (null == a ? 0 : null == (c = a.suggestions) ? 0 : c.length));
        d = !Nsb(this.player) || d;
        a = a.Ak;
        c = this.player.AD();
        return d && !a && !c && !b
    };
    g.k.Nf = function() {
        return this.endScreen.Nf()
    };
    g.k.E8 = function() {
        return this.Nf() ? this.endScreen.oY() : !1
    };
    g.k.xa = function() {
        this.player.Ff("endscreen");
        g.KV.prototype.xa.call(this)
    };
    g.k.load = function() {
        var a = this.player.getVideoData();
        var b = a.transitionEndpointAtEndOfStream;
        if (b && b.videoId) {
            var c = this.player.Bb().Ne.get("heartbeat"),
                d = g.dT(a);
            !d || b.videoId !== d.videoId || a.XS ? (this.player.Mo(b.videoId, void 0, void 0, !0, !0, b), c && c.gJ("HEARTBEAT_ACTION_TRIGGER_AT_STREAM_END", "HEARTBEAT_ACTION_TRANSITION_REASON_HAS_NEW_STREAM_TRANSITION_ENDPOINT"), a = !0) : a = !1
        } else a = !1;
        a || (g.KV.prototype.load.call(this), this.endScreen.show())
    };
    g.k.unload = function() {
        g.KV.prototype.unload.call(this);
        this.endScreen.hide();
        this.endScreen.destroy()
    };
    g.k.onCueRangeEnter = function(a) {
        this.au() && (this.endScreen.created || this.endScreen.create(), "load" === a.getId() && this.load())
    };
    g.k.onCueRangeExit = function(a) {
        "load" === a.getId() && this.loaded && this.unload()
    };
    g.k.onVideoDataChange = function() {
        Psb(this);
        this.D && Osb(this) && (this.endScreen && (this.endScreen.hide(), this.endScreen.created && this.endScreen.destroy(), this.endScreen.dispose()), this.j ? this.endScreen = new p6(this.player) : this.endScreen = new u6(this.player), g.N(this, this.endScreen), g.jU(this.player, this.endScreen.element, 4))
    };
    g.JV("endscreen", Qsb);
})(_yt_player);